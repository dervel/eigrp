#include <stdbool.h>

#include "eigrp_structs.h"
#include "collection.h"

#define EIGRP_PROT_NUM 88

struct eigrp_proccess *get_eigrp_proccess(int id);
hash_collection *get_interfaces();
hash_collection *get_proccesses();
interface *get_interface(int index);
int count_feasible_successors(struct topology_route *tr);
struct topology_route* get_topology_network(struct eigrp_proccess* proc, int dest,int prefix);
void handle_route_changes(struct topology_route* tr, route *new_route, int opcode, struct eigrp_proccess *proc);
void add_route_record(struct topology_route* tr, route *new_route, struct eigrp_proccess *proc);
void remove_route_record(struct topology_route* tr, route *remove);
void calculate_changes_if_needed(struct eigrp_proccess* proc);
void remove_and_recalculate_routes(neighbour *n);
unsigned long calculate_classic_metric(struct eigrp_proccess *proc,unsigned int bandwidth,int delay,int mtu ,int load,int rel);
void calculate_classic_route_metric(struct eigrp_proccess *proc, route *newroute);
bool all_end_of_table_received(struct eigrp_proccess *proc);
void init_calculate_routes(struct eigrp_proccess *proc);
void interface_up(int index);
void interface_down(int index);
void set_route_to_active(struct topology_route *tr, int flag);
void *stuck_in_active(void *ptr);
void proccess_active_state_route(struct topology_route *tr);
globals *get_global_vars();
void pre_init();
void post_init();
//INIT FUNCTIONS
int init_telnet_server();
void init_proccess_hashtable(int num);
void init_interface_vector();
int init_interface(interface *iff);
int init_eigrp_proccess(proccess *proc);
void start_interface_state_listener();

bool is_initialized_eigrp(int i);
void shutdown_eigrp(void);
void free_neighbour(neighbour *n);
void free_array(void);

//TEST FUNCTION
void send_query();
