
#include "hashtable.h"

#ifndef COLLECTION_H_
#define COLLECTION_H_

typedef struct collection{
	int table_index;
	list_t *current;
	hash_table_t *table;
} hash_collection;

#endif

void *next(hash_collection* collection);
hash_collection *prepare(hash_table_t *table);
