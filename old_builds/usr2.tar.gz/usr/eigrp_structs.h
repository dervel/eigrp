#include <stdbool.h>
#include <pthread.h>
#include <sys/types.h>
#include <asm/byteorder.h>
#include <netinet/ip.h>

#include "vector.h"
#include "hashtable.h"
#include "linkedlist.h"

#define PASSIVE_STATE 1 //forwards packets
#define ACTIVE_STATE 2	//router is computing a successor

#define PENDING_STATE 	1
#define UP_STATE 	2

#ifndef EIGRPSTRUCT_H_
#define EIGRPSTRUCT_H_

struct neighbour_;

struct topology_table{
	
};

//Is used at command parsing for information holding
typedef struct proccess_{
	int id;
	vector passive_ifs;
	vector advertised_networks;
}proccess;

typedef struct network_info_{
	in_addr_t network;
	int prefix;
}net_info;

typedef struct interface_{

	struct sockaddr_in *ifa_addr_ip4;
	struct sockaddr_in *ifa_netmask_ip4;

	struct sockaddr_in6 *ifa_addr_ip6;
	struct sockaddr_in6 *ifa_netmask_ip6;

	int index;

	int socket4;
	int socket6;
	char *name;
	pthread_t packet_listener4;
	pthread_t packet_listener6;

	//At interface_metric_changed the value_index refers to the variables below
	//mtu = 0, bandwidth = 1, delay = 2, load = 3, reliability = 4
	unsigned int mtu;
	unsigned int bandwidth;
	unsigned int delay;
	unsigned int load;
	unsigned int reliability;

	bool running;
	bool is_up;

	//This is ONLY used for directly connected routes to pull information
	//It's prbly a bad idea but for now it will work
	struct neighbour_ *self; 
}interface;

typedef struct neighbour_{
	__u32 address; //used as an identifier for the neighbour
	interface *interface; //the interface this neighbour was found
	struct eigrp_proccess *proc; //the proccess number this neighbour is
	struct sockaddr_in sin; //socket info
	vector routes; //routes learned from the neightbour
	int os_version;
	int eigrp_version;	
	linkedlist packet_queue;
	int pending_ack; //The last seq_num we received from the neighbour
	int last_ack_sent; //The last acknolegement we have sended
	long long last_packet_sent; //Last time we sended a packet
	long long holdtime; //Holdtime before considering neighour offline/inactive - in milliseconds
	long long last_response; //Time lat packet received
	bool is_active;
	bool send_next_packet; //Used to skip the waiting time for the next packet - turns to true when a new packet is received
	
	int state; //Pending or Up state for initialization
	int init_seq; //Used for the above state change

	bool eot; //End of table - Used for start up
	bool cr;
} neighbour;

typedef struct route_{
	int dest;
	unsigned int prefix;

	long delay; //Accumulative - Is still scaled
	long bandwidth; //Minimum - Is still scaled
	int mtu; //Minimum
	int hop; //Accumulative
	int reliability; //Minimum
	int load; //Maximun

	unsigned int reported_distance;
	unsigned int feasible_distance;

	neighbour *sender;

	int route_tag;

	bool is_proccess_generated; //If it's an advertized entry - from the process
	int index; //The interface index this route refers to
	int rijk;

}route;

struct topology_route{
	int dest;
	int prefix;

	struct eigrp_proccess *proc;
	route *successor;

	unsigned int feasible_distance;
	int ioj;

	int route_state;
	bool was_changed;

	vector routes;
};

struct topology_support{
	//Do not use/call this - Look at egrip_base for the faction to get a topology_route
	//This structures identifies the networks - search destination by network
	//The below hashtable holds the mask prefix - searches by prefix in the above network
	hash_table_t *topology_route;
};

struct eigrp_proccess{

	bool running;
	pthread_t hello_sender;

	hash_table_t *neighbours; //neighbour table
	hash_table_t *topology_support; //topology table

	int proccess_id;
	int router_id;

	vector ifs; //Active interfaces on the proccess
	vector connected_routes; //routes the proccess is advertizing only

	pthread_t packet_sender;
	linkedlist multicast_queue; //queue used for multicast packets

	int seq_num; //Next Seq to send - init at 1 cause 0 means no ack - Packets i am sending

	int k1,k2,k3,k4,k5,k6;
	int holdtime;
	int hello_interval;
};

struct eigrphdr{
	__u8 version;
	__u8 opcode;
	__u16 checksum;
	__u32 flags;
	__u32 seqnum;
	__u32 acknum;
	__u16 router_id;
	__u16 autonomous_sys_number;
};

struct tlv_parameter_type{
	__u16 type;
	__u16 length;
	__u8 k1;
	__u8 k2;
	__u8 k3;
	__u8 k4;
	__u8 k5;
	__u8 k6;
	__u16 holdtime;
};

struct tlv_version_type{
	__u16 type;
	__u16 length;
	__u16 os_version; //os version
	__u16 eigrp_version; //eigrp version - tlv version
};

//tlv_sequence_type is a higly varriable lenght tlv so we will just read it from the buffer

typedef struct tlv_ip4_internal_{
	__u16 type;
	__u16 length;
	__u32 nexthop;
	__u32 scaled_delay;
	__u32 scaled_bw;
	__u8  mtu_1;
	__u8  mtu_2;
	__u8  mtu_3;
	__u8  hop_count;
	__u8  reliability;
	__u8  load;
	__u8  route_tag;
	__u8  flags;
	__u8  prefix;
	__u8  pnt_var_addr1;
	__u8  pnt_var_addr2;
	__u8  pnt_var_addr3;
	__u8  pnt_var_addr4;
} tlv_ip4_internal;

struct tlv_ip4_external{
	__u16 type;
	__u16 length;
	__u32 nexthop;
	__u32 origin_router;
	__u32 origin_as;
	__u32 admin_tag;
	__u32 extern_metric;
	__u16 reserved;
	__u8  extern_protocol;
	__u8  extern_flags;
	__u32 scaled_delay;
	__u32 scaled_bw;
	__u16 mtu_high;
	__u8  mtu_low;
	__u8  hop_count;
	__u8  reliability;
	__u8  load;
	__u8  route_tag;
	__u8  flags;
	__u8  prefix;
	__u8  pnt_var_addr;
};

typedef struct outgoing_packetv4_param_{
	char* buffer;
	int buffer_len;
	int flags;
	int seq_num;
	int opcode;
	struct sockaddr_in sin; //When sending multicast it doesn't matter what this field contains
} packetv4_param;
#endif
