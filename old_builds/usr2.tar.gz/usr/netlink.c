#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <sys/types.h>
#include <asm/types.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <netinet/ip.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <net/if.h>

#include "libnetlink.h"
#include "netlink.h"
#include "config.h"
#include "vector.h"

#define RTNLGRP_MSGS (RTNLGRP_IPV4_IFADDR|RTNLGRP_IPV4_ROUTE|RTNLGRP_IPV6_IFADDR|RTNLGRP_IPV6_ROUTE)

// This function forms the netlink packet to add a route to the kernel routing
// table
int route_add(__u32* destination, __u32* gateway,int prefix,__u32* metric){
	struct rtnl_handle rth;

	// structure of the netlink packet. 
	struct{
		struct nlmsghdr n;
		struct rtmsg r;
		char buf[1024];
	} req;

	char mxbuf[256];
	struct rtattr * mxrta = (void*)mxbuf;
	unsigned mxlock = 0;
	memset(&req, 0, sizeof(req));

	// Initialisation of a few parameters 
	req.n.nlmsg_len = NLMSG_LENGTH(sizeof(struct rtmsg));
	req.n.nlmsg_flags = NLM_F_REQUEST|NLM_F_CREATE;
	req.n.nlmsg_type = RTM_NEWROUTE;
	req.r.rtm_family = AF_INET;
	req.r.rtm_table = EIGRP_ROUTING_TABLE;
	req.r.rtm_dst_len = prefix;
	req.r.rtm_protocol = RTPROT_EIGRP;
	req.r.rtm_scope = RT_SCOPE_UNIVERSE;
	req.r.rtm_type = RTN_UNICAST;
	mxrta->rta_type = RTA_METRICS;
	mxrta->rta_len = RTA_LENGTH(0);
	
	// RTA_DST and RTA_GW are the two esential parameters for adding a route,
	// there are other parameters too which are not discussed here. For ipv4,
	// the length of the address is 4 bytes.
	addattr_l(&req.n, sizeof(req), RTA_DST, destination, 4);
	addattr_l(&req.n, sizeof(req), RTA_GATEWAY, gateway, 4);
	addattr_l(&req.n, sizeof(req), RTA_PRIORITY, metric, 4);

	int status = 0;

	// opening the netlink socket to communicate with the kernel
	if (rtnl_open(&rth, 0) < 0){
		printf("cannot open rtnetlink\n");
		return -1;
	}

	// sending the packet to the kernel.
	status = rtnl_talk(&rth, &req.n, 0, 0, NULL);
	if (status < 0)
		return status;
	
	rtnl_close(&rth);
	return 0;
}

int route_del(__u32* destination, __u32* gateway,int prefix,__u32* metric){
	struct rtnl_handle rth;

	// structure of the netlink packet. 
	struct{
		struct nlmsghdr n;
		struct rtmsg r;
		char buf[1024];
	} req;

	char mxbuf[256];
	struct rtattr * mxrta = (void*)mxbuf;
	unsigned mxlock = 0;
	memset(&req, 0, sizeof(req));

	// Initialisation of a few parameters 
	req.n.nlmsg_len = NLMSG_LENGTH(sizeof(struct rtmsg));
	req.n.nlmsg_flags = NLM_F_REQUEST|NLM_F_CREATE;
	req.n.nlmsg_type = RTM_DELROUTE;
	req.r.rtm_family = AF_INET;
	req.r.rtm_table = EIGRP_ROUTING_TABLE;
	req.r.rtm_dst_len = prefix;
	req.r.rtm_protocol = RTPROT_EIGRP;
	req.r.rtm_scope = RT_SCOPE_UNIVERSE;
	req.r.rtm_type = RTN_UNICAST;
	mxrta->rta_type = RTA_METRICS;
	mxrta->rta_len = RTA_LENGTH(0);
	
	// RTA_DST and RTA_GW are the two esential parameters for adding a route,
	// there are other parameters too which are not discussed here. For ipv4,
	// the length of the address is 4 bytes.
	addattr_l(&req.n, sizeof(req), RTA_DST, destination, 4);
	addattr_l(&req.n, sizeof(req), RTA_GATEWAY, gateway, 4);
	addattr_l(&req.n, sizeof(req), RTA_PRIORITY, metric, 4);

	int status = 0;

	// opening the netlink socket to communicate with the kernel
	if (rtnl_open(&rth, 0) < 0){
		printf("cannot open rtnetlink\n");
		return -1;
	}

	// sending the packet to the kernel.
	status = rtnl_talk(&rth, &req.n, 0, 0, NULL);
	if (status < 0)
		return status;
	
	rtnl_close(&rth);
	return 0;
}

vector get_routes_by_protocol(int rtm_prot){

	vector routes;
	vector_init(&routes);

	struct{
		struct nlmsghdr n;
		struct rtmsg r;
		char buf[1024];
	}route_req;

	memset(&route_req, 0, sizeof(route_req));

	struct rtnl_handle rth;
    	if (rtnl_open(&rth, 0) < 0){
		printf("cannot open rtnetlink\n");
		return routes;
	}

	route_req.n.nlmsg_len = NLMSG_LENGTH(sizeof(struct rtmsg));
	route_req.n.nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
	route_req.n.nlmsg_type = RTM_GETROUTE;

	route_req.r.rtm_family = AF_INET;
	route_req.r.rtm_table = EIGRP_ROUTING_TABLE;
	route_req.r.rtm_dst_len = 0;
	route_req.r.rtm_src_len = 0;

	int ret,nbytes=0,reply_len=0,count=0;
	ssize_t counter = 5000;
	char reply_ptr[5000];
	char* buf = reply_ptr;
	struct nlmsghdr *nlp;
	struct rtmsg *rtp;
	struct rtattr *rtap;
	int rtl;
	unsigned long bufsize ;

	nlp = malloc(sizeof(struct nlmsghdr));
	memset(nlp, 0, sizeof(struct nlmsghdr));
	
	int sended = rtnl_dump_request(&rth,RTM_GETROUTE,&route_req,sizeof(route_req));

	for(;;){
		if( counter < sizeof(struct nlmsghdr)){
			printf("Routing table is bigger than %d\n", sizeof(reply_ptr));
			vector_free(&routes);
			return routes;
		}

		nbytes = recv(rth.fd, &reply_ptr[reply_len], counter, 0);

		if(nbytes < 0 ){
			printf("Error in recv\n");
			break;
		}
		
		if(nbytes == 0)
			printf("EOF in netlink\n");
	
		nlp = (struct nlmsghdr*)(&reply_ptr[reply_len]);
	
		if (nlp->nlmsg_type == NLMSG_DONE){
			// All data has been received.
			// Truncate the reply to exclude this message,
			// i.e. do not increase reply_len.
			break;
		}

		if (nlp->nlmsg_type == NLMSG_ERROR){
			printf("Error in msg\n");
			vector_free(&routes);
			return routes;
	}

		reply_len += nbytes;
		counter -= nbytes;
	}

	bufsize = reply_len;
	nlp = (struct nlmsghdr*)buf;
	
    	for (;NLMSG_OK(nlp, bufsize); nlp = NLMSG_NEXT(nlp, bufsize)){
		
		/* Get the route data */
        	rtp = (struct rtmsg *) NLMSG_DATA(nlp);

		/* We only need route from the specific protocol*/
		if (rtp->rtm_protocol != rtm_prot)
			continue;
	
        	/* Get attributes of route_entry */
        	rtap = (struct rtattr *) RTM_RTA(rtp);

        	/* Get the route atttibutes len */
        	rtl = RTM_PAYLOAD(nlp);
        	/* Loop through all attributes */

		struct netlink_route route;
		route.proto = rtp->rtm_protocol;
		route.prefix = rtp->rtm_dst_len;

        	for ( ; RTA_OK(rtap, rtl);rtap = RTA_NEXT(rtap, rtl)){
			
			if(rtap->rta_type == RTA_DST){
				route.dest = *(unsigned long *) RTA_DATA(rtap);
			}
			if(rtap->rta_type == RTA_GATEWAY){
				route.gateway = *(unsigned long *) RTA_DATA(rtap);
			}
			if(rtap->rta_type == RTA_PRIORITY){
				route.metric = *(unsigned long *) RTA_DATA(rtap);
			}

        	}

		vector_add(&routes,&route);

    	}

	rtnl_close(&rth);

	return routes;
}

vector get_routes_by_table(int table){

	vector routes;
	vector_init(&routes);

	struct{
		struct nlmsghdr n;
		struct rtmsg r;
		char buf[1024];
	}route_req;

	memset(&route_req, 0, sizeof(route_req));

	struct rtnl_handle rth;
    	if (rtnl_open(&rth, 0) < 0){
		printf("cannot open rtnetlink\n");
		return routes;
	}

	route_req.n.nlmsg_len = NLMSG_LENGTH(sizeof(struct rtmsg));
	route_req.n.nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
	route_req.n.nlmsg_type = RTM_GETROUTE;

	route_req.r.rtm_family = AF_INET;
	route_req.r.rtm_table = table;
	route_req.r.rtm_dst_len = 0;
	route_req.r.rtm_src_len = 0;

	int ret,nbytes=0,reply_len=0,count=0;
	ssize_t counter = 5000;
	char reply_ptr[5000];
	char* buf = reply_ptr;
	struct nlmsghdr *nlp;
	struct rtmsg *rtp;
	struct rtattr *rtap;
	int rtl;
	unsigned long bufsize ;

	nlp = malloc(sizeof(struct nlmsghdr));
	memset(nlp, 0, sizeof(struct nlmsghdr));
	
	int sended = rtnl_dump_request(&rth,RTM_GETROUTE,&route_req,sizeof(route_req));

	for(;;){
		if( counter < sizeof(struct nlmsghdr)){
			printf("Routing table is bigger than %d\n", sizeof(reply_ptr));
			vector_free(&routes);
			return routes;
		}

		nbytes = recv(rth.fd, &reply_ptr[reply_len], counter, 0);

		if(nbytes < 0 ){
			printf("Error in recv\n");
			break;
		}
		
		if(nbytes == 0)
			printf("EOF in netlink\n");
	
		nlp = (struct nlmsghdr*)(&reply_ptr[reply_len]);
	
		if (nlp->nlmsg_type == NLMSG_DONE){
			// All data has been received.
			// Truncate the reply to exclude this message,
			// i.e. do not increase reply_len.
			break;
		}

		if (nlp->nlmsg_type == NLMSG_ERROR){
			printf("Error in msg\n");
			vector_free(&routes);
			return routes;
	}

		reply_len += nbytes;
		counter -= nbytes;
	}

	bufsize = reply_len;
	nlp = (struct nlmsghdr*)buf;
	
    	for (;NLMSG_OK(nlp, bufsize); nlp = NLMSG_NEXT(nlp, bufsize)){
		
		/* Get the route data */
        	rtp = (struct rtmsg *) NLMSG_DATA(nlp);

		/* We only need route from the specific protocol*/
		if (rtp->rtm_table != table)
			continue;
	
        	/* Get attributes of route_entry */
        	rtap = (struct rtattr *) RTM_RTA(rtp);

        	/* Get the route atttibutes len */
        	rtl = RTM_PAYLOAD(nlp);
        	/* Loop through all attributes */

		struct netlink_route route;
		route.proto = rtp->rtm_protocol;
		route.prefix = rtp->rtm_dst_len;

        	for ( ; RTA_OK(rtap, rtl);rtap = RTA_NEXT(rtap, rtl)){
			
			if(rtap->rta_type == RTA_DST){
				route.dest = *(unsigned long *) RTA_DATA(rtap);
			}
			if(rtap->rta_type == RTA_GATEWAY){
				route.gateway = *(unsigned long *) RTA_DATA(rtap);
			}
			if(rtap->rta_type == RTA_PRIORITY){
				route.metric = *(unsigned long *) RTA_DATA(rtap);
			}

        	}

		vector_add(&routes,&route);

    	}

	rtnl_close(&rth);

	return routes;
}

int remove_routes_by_protocol(int protocol){
	vector routes = get_routes_by_protocol(protocol);

	int i;
	for(i=0;i<routes.size; i++){
		struct netlink_route *route;
		route = vector_get(&routes,i);
		
		__u32 dest = (int)route->dest;
		__u32 gateway = (int)route->gateway;
		__u32 metric = (int)route->metric;

		route_del(&dest, &gateway,(int)route->prefix,&metric);
	}

	vector_free(&routes);

	return i;
}

//Interface up/down state check
static bool running = true;
int handle(const struct sockaddr_nl *who, struct nlmsghdr *n, void *arg){
	struct ifinfomsg *iface;
	struct rtattr *attribute;
	char *ifname;

	switch(n->nlmsg_type){
		case RTM_NEWLINK:

			iface = NLMSG_DATA(n);

			int len = n->nlmsg_len - NLMSG_LENGTH(sizeof(*iface));

			int index = iface->ifi_index;

			if(iface->ifi_flags & IFF_RUNNING)
				interface_up(index);
			if(!(iface->ifi_flags & IFF_RUNNING ))
				interface_down(index);
			
			break;
		case RTM_DELLINK:
			printf("Interface Down\n");
			break;
		
	}
	
	if(running){
		return 0;
	}else{
		return -1;
	}
}

int look_interface_changes(){

	struct rtnl_handle rth;
	if (rtnl_open(&rth, RTNLGRP_LINK) < 0){
		printf("cannot open rtnetlink\n");
		return -1;
	}
	
	int status = rtnl_listen(&rth,handle,0);

	rtnl_close(&rth);
	return status;
}

void stop_interface_state_listener(){
	running = false;
}

//TEST FUNCTIONS
static int counter = 5;
int test_handle(const struct sockaddr_nl *who, struct nlmsghdr *n, void *arg){
	struct ifinfomsg *iface;
	struct rtattr *attribute;
	char *ifname;

	switch(n->nlmsg_type){
		case RTM_NEWLINK:

			iface = NLMSG_DATA(n);

			int len = n->nlmsg_len - NLMSG_LENGTH(sizeof(*iface));

			for(attribute = IFLA_RTA(iface);RTA_OK(attribute,len);attribute = RTA_NEXT(attribute,len)){
				switch(attribute->rta_type){
					case IFLA_IFNAME:
						ifname = RTA_DATA(attribute);
					break;
				}
						
			}

			if(iface->ifi_flags & IFF_RUNNING)
				printf("Interface %s is UP\n",ifname);
			if(!(iface->ifi_flags & IFF_RUNNING ))
				printf("Interface %s is DOWN\n",ifname);
			
			break;
		case RTM_DELLINK:
			printf("Interface Down\n");
			break;
		default:
			printf("ID:%d\n",n->nlmsg_type);
		
	}
	counter--;
	return counter;
}

int test_look_interface_changes(){

	struct rtnl_handle rth;
	if (rtnl_open(&rth, RTNLGRP_LINK) < 0){
		printf("cannot open rtnetlink\n");
		return -1;
	}
	
	int status = rtnl_listen(&rth,test_handle,0);

	rtnl_close(&rth);
	return status;
}
