#include <stdbool.h>
#include <linux/kernel.h>
#include <asm/byteorder.h>
#include <sys/types.h>

bool compare(char *s1, char *s2);
long long current_timestamp();
int sleep_millis(long long milliseconds);
__u16 checksum(char *buffer,int len);
int subnet_to_prefix(unsigned int subnet_mask);
int wildcard_to_prefix(char *ch);
unsigned int ip4_toint(char *ip);
char *ip4_tochar(unsigned int ip);
