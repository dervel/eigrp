#include "eigrp_structs.h"

#define PACKET_LENGTH 	2046

#define OS_VERSION 	0x0C04
#define EIGRP_VERSION 	0x0102

#define OPCODE_UPDATE	1
#define OPCODE_QUERY	3
#define OPCODE_REPLY	4
#define OPCODE_HELLO	5

#define FLAG_INIT 	0x01
#define FLAG_CR		0x02
#define FLAG_ENDOFTABLE 0x08

#define VERSION 	2

#define LEAST_MTU	500

#ifndef PACKETFACTORY_H_
#define PACKETFACTORY_H_

static char *string_codes[] = {"NONE","UPDATE","NONE","QUERY","REPLY","HELLO"};

#define to_string(x)	string_codes[x]

#endif
int fill_sequence_tlv(char *buffer, struct eigrp_proccess *proc);
tlv_ip4_internal *create_interal_route_tlv(route *r, int flags);
void auto_packet_split(neighbour *n,vector *tvls,int opcode,int flags);
void addtlv(packetv4_param *packet, void* tlv,int len);
packetv4_param *create_empty_packet(int opcode,int flags, struct sockaddr_in sin);
void create_eigrp_header(char* buffer, int packet_len, int opcode, int auto_sys_number, int seqnum, int acknum, int flags);
char *create_hello_packet(int* packet_len, struct eigrp_proccess *proc);
void send_update_all(struct eigrp_proccess *proc, vector tlvs, route *r);

void add_update_tlv_all(route *r);
void add_query_tlv_all(route *r);
void add_reply_tlv_neighbour(neighbour *n,route *r);
