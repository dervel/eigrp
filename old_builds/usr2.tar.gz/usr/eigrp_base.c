#define _GNU_SOURCE
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <ifaddrs.h>
#include <netdb.h>
#include <pthread.h>
#include <net/if.h>
#include <sys/ioctl.h>

#include "config.h"
#include "eigrp_base.h"
#include "eigrp_prot.h"
#include "vector.h"
#include "utils.h"
#include "hashtable.h"
#include "eigrp_structs.h"
#include "packet_factory.h"
#include "collection.h"
#include "netlink.h"

#define EIGRP_PROT_NUM 88
#define DEFAULT_NEIGHBOURS_HASHTABLE_SIZE 40
#define CONNECTED_ROUTE 999


static hash_table_t *proccesses;
static hash_table_t *interfaces;
static pthread_t interface_state_listener;

hash_collection *get_interfaces(){
	return prepare(interfaces);
}

interface *get_interface(int index){
	return hashtable_getitem(interfaces,index);
}

void init_proccess_hashtable(int num){
	proccesses = create_hash_table(num);
}

struct eigrp_proccess *get_eigrp_proccess(int id){

	struct eigrp_proccess *proc = hashtable_getitem(proccesses,id);
	if(proc == NULL)
		printf("BASE:Requested a NULL proccess.\n");

	return proc;
}

void init_interfaces_hashtable(){
	interfaces = create_hash_table(50);
}

unsigned long calculate_classic_metric(struct eigrp_proccess *proc,unsigned int bandwidth,int delay,int mtu ,int load,int rel){
	if(delay == EIGRP_UNREACHABLE)
		return EIGRP_INACCESSIBLE;

	int reliability = 1;
	unsigned int bw = (256 * (unsigned long)EIGRP_BANDWIDTH / bandwidth);

	if(proc->k5 != 0){
		reliability = (proc->k5 / (rel + proc->k4 ));
	}

	unsigned long metric = (
			proc->k1 * bw + 
			((proc->k2 * bw)/(256-load)) +
			(proc->k3 * delay)
		     ) * reliability;

	return metric;
}

void calculate_classic_route_metric(struct eigrp_proccess *proc, route *newroute){
	unsigned long metric = calculate_classic_metric(proc,newroute->bandwidth,newroute->delay,newroute->mtu,newroute->load,newroute->reliability);	
	//Reported Distance
	newroute->reported_distance = metric;
	//Feasible Distance
	//Bandwidth
	int if_bw = newroute->sender->interface->bandwidth;		
	int min_bw = newroute->bandwidth < if_bw ? newroute->bandwidth : if_bw;
	//Delay
	unsigned long if_delay = newroute->sender->interface->delay;
	unsigned long acc_delay=0;
	if(if_delay == EIGRP_UNREACHABLE || newroute->delay == EIGRP_UNREACHABLE){
		acc_delay = EIGRP_UNREACHABLE;
	}else{
		acc_delay = if_delay + newroute->delay;
	}
	//Mtu
	int if_mtu = newroute->sender->interface->mtu;
	int min_mtu = newroute->mtu < if_mtu ? newroute->mtu : if_mtu;
	//Load
	int if_load = newroute->sender->interface->load;
	int max_load = newroute->load > if_load ? newroute->load : if_load;
	//Reliability
	int if_rel = newroute->sender->interface->reliability;
	int min_rel = newroute->reliability < if_rel ? newroute->reliability : if_rel;

	unsigned long feasible_distance = calculate_classic_metric(proc,min_bw,acc_delay,min_mtu ,max_load,min_rel);
	newroute->feasible_distance = feasible_distance;
}

//The idea behind this is to use the network as an identifier, however we can have the
//same network with different prefixes. So we use 2 hashtables to find the route
//One searches the network and the other searches the prefix
struct topology_route* get_topology_network(struct eigrp_proccess* proc, int dest,int prefix){
	struct topology_support* network_table = hashtable_getitem(proc->topology_support, dest);
	if(network_table == NULL){
		printf("Creatng network table\n");
		struct topology_support* new_network_table = malloc(sizeof (struct topology_support));
		new_network_table->topology_route = create_hash_table(32);
		hashtable_additem(proc->topology_support, new_network_table , dest);
		network_table = new_network_table;
	}
	struct topology_route *prefix_route = hashtable_getitem(network_table->topology_route, prefix);
	if(prefix_route == NULL){
		printf("Creatng prefix table\n");
		struct topology_route *new_route = malloc(sizeof(struct topology_route));
		
		//Init topology_route
		vector_init(&new_route->routes);
		new_route->feasible_distance = 0xFFFFFFFF; //set the metric to infinate
		new_route->dest = dest;
		new_route->prefix = prefix;
		new_route->proc = proc;
		new_route->route_state = ACTIVE_STATE;
		new_route->successor = NULL;
		new_route->ioj = -1;
		//end topology_route init

		hashtable_additem(network_table->topology_route, new_route, prefix);
		prefix_route = new_route;
	}
	return prefix_route;
}

void set_new_successor(struct topology_route *tr, route *new_successor){

	printf("Neightbour Address:%d\n",new_successor->sender->address);
	//Remove the old entry from the routing table
	if(tr->successor != NULL && tr->successor->sender->address != 0)
		route_del(&tr->dest,&tr->successor->sender->address,tr->prefix,&tr->successor->feasible_distance);	
		
	tr->successor = new_successor;
	//Add the new entry
	if(tr->successor->sender->address != 0)
		route_add(&tr->dest,&tr->successor->sender->address,tr->prefix,&tr->successor->feasible_distance);
}

route *find_new_successor(struct topology_route *tr){
	route *new_successor = NULL;
	int lowest_distance = 0xFFFFFFFF;
	int i;
	for(i=0;i<tr->routes.size;i++){
		route *r = vector_get(&tr->routes,i);
		calculate_classic_route_metric(tr->proc,r);
		printf("Reported distance: %d\n", r->reported_distance);
		if(r->reported_distance < tr->feasible_distance && r->feasible_distance < lowest_distance){
			lowest_distance = r->feasible_distance;
			new_successor = r;
		}
	}

	return new_successor;
}

unsigned int get_least_feasible_distance(struct topology_route *tr){
	int i;
	unsigned int least_router_distance = 0xFFFFFFFF; //Least distance of this router to the destination

	for(i=0;i<tr->routes.size;i++){
		route *record = vector_get(&tr->routes, i);
		calculate_classic_route_metric(tr->proc,record);
		if(record->feasible_distance < least_router_distance)
			least_router_distance = record->feasible_distance;
	}

	return least_router_distance;
	
}


void set_waiting_for_reply(struct topology_route *tr){
	int i;
	for(i=0;i<tr->routes.size;i++){
		route *r = vector_get(&tr->routes,i);
		if(r->sender->address == 0 || !r->sender->interface->is_up || r->sender->state == PENDING_STATE)
			r->rijk = 0; //FSM(8)
		else 
			r->rijk =1;
	}
}

void init_calculate_routes(struct eigrp_proccess *proc){
	hash_collection *col, *col2;
	struct topology_route *prefix_route;
	struct topology_support* support;
	route *new_successor;	

	//Foreach topology route
	col = prepare(proc->topology_support);	
	//Network
	while((support=next(col)) != NULL){
		//Prefix
		col2 = prepare(support->topology_route);
		while((prefix_route=next(col2)) != NULL){
			printf("Route:%s\n",ip4_tochar(prefix_route->dest));
			prefix_route->feasible_distance = get_least_feasible_distance(prefix_route);
			printf("Router feasible distance: %d\n", prefix_route->feasible_distance);
			new_successor = find_new_successor(prefix_route);
			if(new_successor == NULL){
				printf("No successor found, smth went wrong.\n");
			}else{
				set_new_successor(prefix_route,new_successor);
				prefix_route->route_state = PASSIVE_STATE;
			}		
		}
	}
}

void proccess_active_state_route(struct topology_route *tr){
	route *new_successor;

	if(tr->ioj == 0){
		new_successor = find_new_successor(tr);
		if(new_successor == NULL){
			//FSM(11)
			//No successor was found
			tr->route_state = ACTIVE_STATE;
			//Set the flags
			tr->ioj = 1;
			set_waiting_for_reply(tr);
			//Send query to all neighbours
			add_query_tlv_all(tr->successor);
			
		}else{
			//FSM(14)
			tr->route_state = ACTIVE_STATE;
			tr->ioj = -1;
			//We don't send a reply
			//Set the new_successor
			set_new_successor(tr, new_successor);

		}
	}else if(tr->ioj == 1){
		tr->feasible_distance = get_least_feasible_distance(tr);
		new_successor = find_new_successor(tr);
		if(new_successor == NULL){
			//TODO: remove the route completely no successor found
		}else{
			//FSM(15)
			tr->route_state = PASSIVE_STATE;
			tr->ioj = -1;
			set_new_successor(tr, new_successor);
		}
	}else if(tr->ioj == 2){
		new_successor = find_new_successor(tr);
		if(new_successor == NULL){
			//FSM(12)
			//No successor was found
			tr->route_state = ACTIVE_STATE;
			//Set the flags
			tr->ioj = 3;
			set_waiting_for_reply(tr);
			//Send query to all neighbours
			add_query_tlv_all(tr->successor);
		}else{
			//FSM(16)
			tr->route_state = PASSIVE_STATE;
			tr->ioj = -1;
			//Send the reply at our previous successor
			add_reply_tlv_neighbour(tr->successor->sender,new_successor);
			//Set the new_successor
			set_new_successor(tr, new_successor);
		}
	}else if(tr->ioj == 3){
		new_successor = find_new_successor(tr);
		if(new_successor == NULL){
			//TODO: remove the route completely no successor found
		}else{
			//FSM(13)
			tr->route_state = PASSIVE_STATE;
			tr->ioj = -1;
			//Send the reply at our previous successor
			add_reply_tlv_neighbour(tr->successor->sender,new_successor);
			//Set the new_successor
			set_new_successor(tr, new_successor);
		}
	}else{
		printf("I fucked up the flag.\n");
	}
}

bool all_end_of_table_received(struct eigrp_proccess *proc){
	hash_collection *col;
	neighbour *n = NULL;

	col = prepare(proc->neighbours);
	while( (n = next(col)) != NULL){
		if(n->eot == false)return false;
	}

	return true;
}

bool if_all_replies_received(struct topology_route *tr){
	
	int i;
	for(i=0;i<tr->routes.size;i++){
		route *r = vector_get(&tr->routes,i);
		if(r->rijk == 1) return false;
	}
	return true;
}

void reply_received(struct topology_route *tr, neighbour *n){
	int i;
	for(i=0;i<tr->routes.size;i++){
		route *r = vector_get(&tr->routes,i);
		if(r->sender->address == n->address){
			r->rijk = 0;
			return;
		}
	}
}

void reply_received_link_down(struct topology_route *tr, int index){
	int i;
	for(i=0;i<tr->routes.size;i++){
		route *r = vector_get(&tr->routes,i);
		if(r->sender->interface->index == index){
			r->rijk = 0;
		}
	}
}

/*
	This functions adds/changes the routes that we receive from packets. As so we will use it to handle the route
	state.

	Also FSM(x) indicator references the http:/tools.ietf.org/html/draft-savage-eigrp-02 page 13 state transition events
*/

void handle_route_changes(struct topology_route* tr, route *new_route, int opcode, struct eigrp_proccess *proc){
	printf("Handling Packet\n");
	if(opcode == CONNECTED_ROUTE){
		add_route_record(tr,new_route,proc);
	}

	if(opcode == OPCODE_QUERY){
		printf("Query Packet\n");
		add_route_record(tr,new_route,proc);
		printf("Recorded\n");
		if(tr->route_state == PASSIVE_STATE){
			printf("Route is Passive\n");
			//FSM(1)
			//If is not the successor
			if(tr->successor->sender->address != new_route->sender->address){
				//Send the reply
				queue_reply_packet(new_route->sender,0,tr->successor);
				//Run FC to check changes on current successor
				if(new_route->feasible_distance < tr->feasible_distance)
					//Think i am missing something here
					tr->feasible_distance = new_route->feasible_distance;

				return; //Return so that we don't send a reply since it has already been sended
			}else{ //Is the successor
				//FSM(2)
				printf("FSM(2)-QUERY\n");
				if(new_route->delay == EIGRP_UNREACHABLE || new_route->reported_distance > tr->feasible_distance){
					route *successor = find_new_successor(tr);
					if(successor != NULL){
						set_new_successor(tr, successor);
						//New successor send info
						add_update_tlv_all(successor);			
					}else{
						//FSM(3)
						tr->route_state = ACTIVE_STATE;
						//Set the flags
						tr->ioj = 3;
						set_waiting_for_reply(tr);
						//Send query to all neighbours
						add_query_tlv_all(new_route);
						return; //Route entered active state return so we that we don't send a query
					}
				}else{
				//We still have the old successor but the metrics changed so we send the ones
				add_update_tlv_all(tr->successor);
				}
			}
			//We send a reply since this is a query
			add_reply_tlv_neighbour(new_route->sender,tr->successor);
		}else{ //Route is in active state
			//Is the successor
			//FSM(5)
			if(tr->successor->sender->address == new_route->sender->address){
				if(tr->ioj == 0 || tr->ioj == 1)
					tr->ioj == 2;
			}else{ //Is not the successor
				//FSM(6)
				add_reply_tlv_neighbour(new_route->sender,new_route);
			}

		}
	}

	if(opcode == OPCODE_UPDATE){
		add_route_record(tr,new_route,proc);
		if(tr->route_state == PASSIVE_STATE){
			//FSM(2)
			printf("FSM(2)-UPDATE\n");
			if(tr->successor->sender->address == new_route->sender->address){
				if(new_route->delay == EIGRP_UNREACHABLE || new_route->reported_distance > tr->feasible_distance){
					route *successor = find_new_successor(tr);
					if(successor != NULL){
						set_new_successor(tr, successor);
						//New successor send info
						add_update_tlv_all(successor);
						return;				
					}else{
						//FSM(4)
						tr->route_state = ACTIVE_STATE;
						//Set the flags
						tr->ioj = 1;
						set_waiting_for_reply(tr);
						//Send query to all neighbours
						add_query_tlv_all(new_route);
						return;
					}
				}
			}
		}else{
			//FSM(7)
			//The changes are recorded above no query or update are sended though
		}
	}

	//FSM(8)
	if(opcode == OPCODE_REPLY){
		if(tr->route_state == ACTIVE_STATE){
			reply_received(tr,new_route->sender);
			if(if_all_replies_received(tr)){
				//We have heard from all neightbour, now we can find a new successor
				proccess_active_state_route(tr);
			}
		}
	}

	//Will be removed only left to have a running programm atm
	printf("Record Added.\n");
	add_route_record(tr,new_route,proc);
}

bool proccess_uses_if(struct eigrp_proccess *proc, int if_index){
	int i;
	for(i=0;i<proc->ifs.size;i++){
		interface *iff = vector_get(&proc->ifs,i);
		if(iff->index = if_index) return true;
	}
	return false;
}

void interface_down(int index){

	int i;
	route *r, *successor;
	hash_collection *col, *col2;
	interface *iff;
	struct eigrp_proccess *proc;
	struct topology_route *tr, *prefix_route;
	struct topology_support* support;

	iff = get_interface(index);
	iff->is_up = false;
	
	//Foreach Proccess
	col = prepare(proccesses);
	while( (proc = next(col)) != NULL ){
		
		//Foreach Advertized Route
		for(i=0;i<proc->connected_routes.size;i++){
			r = vector_get(&proc->connected_routes, i);
			r->delay = EIGRP_UNREACHABLE;
			//FSM(2)
			tr = get_topology_network(proc,r->dest,r->prefix);
			if(tr->successor->sender->address == 0){
				successor = find_new_successor(tr);
				if(successor != NULL){
					set_new_successor(tr, successor);
					//New successor send info
					add_update_tlv_all(successor);
					return;				
				}else{
					//FSM(4)
					tr->route_state = ACTIVE_STATE;
					//Set the flags
					tr->ioj = 1;
					set_waiting_for_reply(tr);
					//Send query to all neighbours
					add_query_tlv_all(tr->successor);
					return;
				}
			}
		}
		//Foreach topology route
		col = prepare(proc->topology_support);	
		//Network
		while((support=next(col)) != NULL){
			//Prefix
			col2 = prepare(support->topology_route);

			while((prefix_route=next(col2)) != NULL){
				if(prefix_route->successor->sender->interface->index == index){
					if(prefix_route->route_state == ACTIVE_STATE){

						reply_received_link_down(prefix_route,index);

						//FSM(9)
						if(prefix_route->ioj == 1){
							prefix_route->ioj = 0;
						}
						//FSM(10)
						if(prefix_route->ioj == 3){
							prefix_route->ioj = 2;
						}

						if(if_all_replies_received(prefix_route)){
							//We have heard from all neightbour, now we can find a new successor
							proccess_active_state_route(prefix_route);
						}
					}
				}else{
					//FSM(7)
					//Changes are recorded but no update is sent
				}
			}

		}
	}
}

void interface_up(int index){
	int i;
	interface *iff;
	hash_collection *col;
	struct eigrp_proccess *proc;
	struct topology_route *tr;
	route *r;

	//We will need the iff to pull the delay value
	iff = get_interface(index);
	iff->is_up = true;

	//Foreach Proccess
	col = prepare(proccesses);
	while( (proc = next(col)) != NULL ){
		//Foreach Advertized Route
		//FSM(2)
		for(i=0;i<proc->connected_routes.size;i++){
			r = vector_get(&proc->connected_routes, i);
			r->delay = iff->delay;
		}
	}
	
}

void interface_metric_changed(int if_index,int value_index,int value){
	int i;
	interface *iff;
	hash_collection *col, *col2;
	struct eigrp_proccess *proc;
	struct topology_route *rt, *prefix_route;
	struct topology_support* support;

	iff = get_interface(if_index);

	switch(value_index){
		case 0:
			iff->mtu = value;
			break;
		case 1:
			iff->bandwidth = value;
			break;
		case 2:
			iff->delay = value;
			break;
		case 3:
			iff->load = value;
			break;
		case 4:
			iff->reliability = value;
			break;
	}
	//Foreach Proccess
	col = prepare(proccesses);
	while( (proc = next(col)) != NULL ){
		
		//Foreach topology route
		col = prepare(proc->topology_support);	
		//Network
		while((support=next(col)) != NULL){
			//Prefix
			col2 = prepare(support->topology_route);

			while((prefix_route=next(col2)) != NULL){
				if(prefix_route->successor->sender->interface->index == if_index){
					if(prefix_route->route_state == PASSIVE_STATE){
						calculate_classic_route_metric(proc,prefix_route->successor); //Update entry
						if(prefix_route->successor->reported_distance > prefix_route->feasible_distance){
							route *successor = find_new_successor(prefix_route);
							if(successor != NULL){
								//FSM(2)
								set_new_successor(prefix_route, successor);
								//New successor send info
								add_update_tlv_all(successor);
								continue;		
							}else{
								//FSM(4)
								prefix_route->route_state = ACTIVE_STATE;
								//Set the flags
								prefix_route->ioj = 1;
								set_waiting_for_reply(prefix_route);
								//Send query to all neighbours
								add_query_tlv_all(prefix_route->successor);
								continue;
							}
						}
						//FSM(2)
						add_update_tlv_all(prefix_route->successor);
					}else{

						reply_received_link_down(prefix_route,if_index);						

						//FSM(9)
						if(prefix_route->ioj == 1){
							prefix_route->ioj = 0;
							
						}
						//FSM(10)
						if(prefix_route->ioj == 3){
							prefix_route->ioj = 2;
						}

						if(if_all_replies_received(prefix_route)){
							//We have heard from all neightbour, now we can find a new successor
							proccess_active_state_route(prefix_route);
						}
					}
				}else{
					//FSM(7)
					//Changes are recorded but no update is sent
				}
			}

		}

	}
}

void add_route_record(struct topology_route* tr, route *new_route,struct eigrp_proccess *proc){

	int i;
	for(i=0;i<tr->routes.size;i++){
		route *record = vector_get(&tr->routes,i);
		if(record->sender->address == new_route->sender->address){
			//I was gonna orgininally replace it, but we are just gonna overwrite the values - simpler

			record->delay = new_route->delay;
			record->bandwidth = new_route->bandwidth;
			record->mtu = new_route->mtu;
			record->hop = new_route->hop;
			record->reliability = new_route->reliability;
			record->load = new_route->load;

			record->reported_distance = new_route->reported_distance;

			calculate_classic_route_metric(proc,record);

			//dest,prefix and sender are the same
			return;
		}
	}
	
	calculate_classic_route_metric(proc,new_route);

	//Add the route to the topology table
	vector_add(&tr->routes, new_route);
	//Add the route to neighbour as a reference
	vector_add(&new_route->sender->routes,new_route);
}

void remove_route_record(struct topology_route* tr, route *remove){
	int index;
	//Somehow find the index here
	vector_delete(&tr->routes, index);
}

void route_recalculate(struct topology_route *tr){
	printf("Found route with changes\n");
	//First check if we have a successor
	if(tr->successor != NULL){
		//if the successor is active we exit, this function is called each time a new route
		//is inserted but that doesn't mean we have to recalculate everything if the successor
		//is working fine
		if(tr->successor->sender->is_active && tr->successor->delay != EIGRP_UNREACHABLE){
			tr->was_changed = false;
			return;
		}
	
	}

	//No successors found for the route, we will have to recalculate new ones	
	tr->feasible_distance = get_least_feasible_distance(tr);

	//Now that we have the least distance pass the records a 2nd time to find the successors
	//We are trying to find the 2 minimum cost paths - Hope the code doesn't look too ugly here
	route *primary_route = NULL;//successor
	int i;
	for(i=0;i<tr->routes.size;i++){
		route *record = vector_get(&tr->routes, i);
		//If the neighbour went inactive for some reason skip him
		if(!record->sender->is_active)
			continue;

		if(record->delay == EIGRP_UNREACHABLE)
			continue;

		//If it's upstream ignore it
		if(record->reported_distance < tr->feasible_distance)
			continue;

		if(primary_route == NULL)
			primary_route = record;
			continue;

		if(primary_route->reported_distance > record->reported_distance){
			primary_route = record;
			continue;
		}
	}

	//At this point we searched all record and we should have our successor and feasible successor
	tr->successor = primary_route;

	//Add the new route to the routing table
	printf("passing new routing information.\n");
	if(tr->successor != NULL){
		printf("Metric %d",tr->successor->feasible_distance);
		route_add(&tr->dest,&tr->successor->sender->address,tr->prefix,&tr->successor->feasible_distance);
	}

	tr->route_state = PASSIVE_STATE;
}

void calculate_changes_if_needed(struct eigrp_proccess* proc){
	hash_collection *col = prepare(proc->topology_support);
 
	//We need to check if any of the route had any changes

	
	//Network
	struct topology_support* support;
	while((support=next(col)) != NULL){
		//Prefix
		struct topology_route *prefix_route;
		hash_collection *col2 = prepare(support->topology_route);

		while((prefix_route=next(col2)) != NULL){
			if(prefix_route->route_state = ACTIVE_STATE)
				printf("Changing Route %d\n",prefix_route->dest);
				route_recalculate(prefix_route);
		}

	}
}

void remove_and_recalculate_routes(neighbour *n){

	int i;
	for(i=0;i<n->routes.size;i++){
		route *r = vector_get(&n->routes,i);

		struct topology_route *tr = get_topology_network(n->proc,r->dest,r->prefix);
		int k;
		//Remove the route from the topology table
		for(k=0;k<tr->routes.size;k++){
			route *record = vector_get(&tr->routes,k);			
			if(record->sender->address = r->sender->address){
				vector_delete(&tr->routes,k);
				break;
			}
		}
		//Recalculate the route if needed
		route_recalculate(tr);
	}
	vector_empty(&n->routes);

}

void init_values(struct eigrp_proccess *proc,int i){	

	proc->running = true;

	proc->k1=1;
	proc->k2=0;
	proc->k3=1;
	proc->k4=0;
	proc->k5=0;
	proc->k6=0;

	proc->proccess_id=i;
	proc->router_id=1;
	proc->hello_interval = 5;
	proc->holdtime = proc->hello_interval * 3;

	vector_init(&proc->ifs);
	vector_init(&proc->connected_routes);

	linkedlist_init(&proc->multicast_queue);

	proc->seq_num = 1;

	proc->neighbours = create_hash_table(DEFAULT_NEIGHBOURS_HASHTABLE_SIZE);
	proc->topology_support = create_hash_table(30);

}

void *hello_packet_thread(void *ptr){
	struct eigrp_proccess *proc;
	interface *iff;

	proc = (struct eigrp_proccess *)ptr;

	//Prepare the hello packet once so we don't have to make it over and over
	int i,packet_len=0;
	char *buffer = create_hello_packet(&packet_len,proc);

	struct sockaddr_in sin;
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = inet_addr("224.0.0.10");

	packetv4_param packet;
	packet.buffer = buffer;
	packet.buffer_len = packet_len;
	packet.sin = sin;

	while(proc->running){		
	
		for(i=0;i<proc->ifs.size;i++){
			iff = vector_get(&proc->ifs,i);
			send_ip4_packet(&packet, iff->socket4);
		}
		

		sleep(proc->hello_interval);		
	}

	free(buffer);
}

bool vector_contains(vector *v, char *string){
	int i;
	for(i=0;i<v->size;i++){
		if(compare(vector_get(v,i), string))
			return true;
	}
	return false;
}

void send_packets_neighbour(neighbour *n){
	long long current_time;
	long long delay = 1000; //Send or resend packets every 1 second

	current_time = current_timestamp();

	if(current_time - n->last_response > n->holdtime){
		printf("Neighbour is inactive removing him.\n");
		free_neighbour(n);
	}

	if((!n->send_next_packet) && current_time - n->last_packet_sent < delay){
		return;
	}

	n->send_next_packet = false;

	if(linkedlist_isempty(&n->packet_queue)){
		if(n->last_ack_sent != n->pending_ack){
			int length = sizeof(struct eigrphdr);
			char* buffer = malloc(length);
			n->last_ack_sent = n->pending_ack;
			create_eigrp_header(buffer, length, OPCODE_HELLO, n->proc->proccess_id, 0, n->pending_ack, 0);

			packetv4_param *packet = malloc(sizeof(packetv4_param));
			packet->buffer = buffer;
			packet->buffer_len = length;
			packet->sin = n->sin;

			send_ip4_packet(packet,n->interface->socket4);
			n->last_packet_sent = current_time;
		}
	}else{
		packetv4_param *packet = linkedlist_peekfirst(&n->packet_queue);
		if(packet->seq_num == 0){
			int seq_num = n->proc->seq_num++; //increase the seq_num by 1
			packet->seq_num = seq_num; //assign the seq to the struct so it be retrived later to check for ack
			
			//Save the seq num for the neighbour state change				
			if( flags_are_set(packet->flags, FLAG_INIT) ){
				n->init_seq = seq_num;
			}
		}
		create_eigrp_header(packet->buffer, packet->buffer_len, packet->opcode, n->proc->proccess_id, packet->seq_num , n->pending_ack, packet->flags);
		n->last_ack_sent = n->pending_ack;
		send_ip4_packet(packet,n->interface->socket4);
		n->last_packet_sent = current_time;
	}
}

bool packet_queues_empty(struct eigrp_proccess *proc){
	hash_collection *col;
	neighbour *n;

	col = prepare(proc->neighbours);
	while( (n = next(col)) != NULL){
		if(!linkedlist_isempty(&n->packet_queue)) return false;
	}
	
	return true;
}

void *send_ipv4_packets( void *ptr){
	struct eigrp_proccess *proc;
	hash_collection *col;
	neighbour *n;
	long long current_time;
	struct sockaddr_in sin;
	bool cr = false; //Indicates if cr flag should be set on a multicast packet.
	int flags = 0; //Flag the multicast packet will have
	char *seq_tlv=malloc(PACKET_LENGTH); //We will write the tlv in this buffer and then copy it into the packet
	int seq_len=0; //The actual length we used from the hole buffer

	proc = (struct eigrp_proccess *)ptr;

	printf("test\n");

	while(proc->running){
		sleep_millis(100);

		if(linkedlist_isempty(&proc->multicast_queue)){
			//Send any pending packets from neighbour queue
			col = prepare(proc->neighbours);
			while( (n = next(col)) != NULL){
				send_packets_neighbour(n);
			}

		}else{
			//Send the next multicast packet

			int seq_num = proc->seq_num++; // Get the seq number now cause we might need it for the seq_tlv packet

			//If we have pending ack send the sequence tlv 		
			if(!packet_queues_empty(proc)){
				cr = true;
				
				//Build the sequence tlv
				seq_len = fill_sequence_tlv(seq_tlv, proc);
				//Create the packet
				packetv4_param *seq_packet = create_empty_packet(OPCODE_HELLO, 0 , sin);
				addtlv(seq_packet,seq_tlv,seq_len);
				create_eigrp_header(seq_packet->buffer, seq_packet->buffer_len, seq_packet->opcode, proc->proccess_id, seq_num, 0, 0);
				send_ip4_packet_multicast(seq_packet,proc);
				free(seq_tlv);
				free(seq_packet);
				
			}

			packetv4_param *packet = linkedlist_getfirst(&n->packet_queue);
			int length = sizeof(struct eigrphdr);
			char* buffer = malloc(length);

			if(cr) flags |= FLAG_CR;
			create_eigrp_header(packet->buffer, packet->buffer_len, packet->opcode, proc->proccess_id, seq_num, 0, flags);
			queue_sended_multicast_packet(proc, packet);
			send_ip4_packet_multicast(packet,proc);
		}
	}
}

int get_interface_index_ip4(unsigned int address, int prefix){
	hash_collection *col;
	interface *iff;

	col = get_interfaces();
	while( (iff = next(col)) != NULL){
		int if_prefix = subnet_to_prefix(iff->ifa_netmask_ip4->sin_addr.s_addr);
		if(if_prefix < -1) return -1;
		//We can't advertize a network bigger than the interface network
		if(prefix < if_prefix) continue;

		//Remove the host part and compare
		unsigned int network = address << 32-if_prefix;
		unsigned int if_network = iff->ifa_addr_ip4->sin_addr.s_addr << 32-if_prefix;
		if(network == if_network){
			return iff->index;
		}
	}

	return -1;
}

int init_eigrp_proccess(proccess *proc_info){

	struct eigrp_proccess *proc;
	int i,id = proc_info->id;
	net_info *adv_net;
	hash_collection *col;
	interface *iff;

	//Here we will be skipping the get function cause we are initializing
	proc = hashtable_getitem(proccesses,id);
	if(proc != NULL){
		printf("Trying to initialize an already initialized proccess: %d\n",id);
		return -1;
	}

	printf("Initializing Eigrp Proccess %d\n" , id);
	proc = malloc(sizeof(struct eigrp_proccess));

	//Init Basic Values
	init_values(proc, id);
	col = prepare(interfaces);
	while((iff = next(col)) != NULL){

		if(vector_contains(&proc_info->passive_ifs, iff->name))
			continue;
		else{
			vector_add(&proc->ifs, iff);
		}
	}
	for(i=0;i<proc_info->advertised_networks.size;i++){
		adv_net = vector_get(&proc_info->advertised_networks,i);
		//Interface Index
		int if_index = get_interface_index_ip4(adv_net->network,adv_net->prefix);
		if(if_index == -1){
			printf("Could not find a matching interface for network %s.\n",ip4_tochar(adv_net->network));
			continue;
		}
		interface *iff = get_interface(if_index);
		printf("Found a match for %s/%d through %s/%d-%s.\n",ip4_tochar(adv_net->network),adv_net->prefix,ip4_tochar(iff->ifa_addr_ip4->sin_addr.s_addr),subnet_to_prefix(iff->ifa_netmask_ip4->sin_addr.s_addr),iff->name);

		//Create the route struct
		route *connected_route = malloc(sizeof(route));
		connected_route->is_proccess_generated = true;
		connected_route->index = if_index;
		connected_route->rijk = 0;
		//---------------------------
		connected_route->sender = iff->self;
		connected_route->prefix = adv_net->prefix;
		connected_route->dest = adv_net->network;
		//Metrics
		connected_route->mtu = iff->mtu;
		connected_route->reliability = iff->reliability;
		connected_route->delay = iff->delay;
		connected_route->bandwidth = iff->bandwidth;
		connected_route->load = iff->load;
		connected_route->hop = 0;
		connected_route->route_tag = 0;

		//---------------------------


		calculate_classic_route_metric(proc,connected_route);
		//Add the route struct to the topology_table
		struct topology_route *tr = get_topology_network(proc, connected_route->dest, connected_route->prefix);
		handle_route_changes(tr, connected_route,CONNECTED_ROUTE,proc);
		//Add the route to the directly connected_rotues - Is used when interface does up/down
		vector_add(&proc->connected_routes,connected_route);
	}

	int ret = pthread_create(&proc->hello_sender,NULL ,hello_packet_thread ,(void*)proc);
	if(ret){
		printf("Error creating hello thread for proccess %d ip4.\n", proc->proccess_id);
		free(proc);
		return -1;
	}

	//This is the thread tasked with sending the packets so they arrive with the correct order(seq,ack)
	//also tasked with looking if the neighbour is still active since it handles the packets recved
	ret = pthread_create(&proc->packet_sender,NULL ,send_ipv4_packets ,(void*)proc);
	if(ret){
		printf("Error creating sender thread for proccess %d ip4.\n", proc->proccess_id);
		free(proc);				
		return -1;
	}

	printf("Eigrp proccess %d working on %d interfaces.\n",proc->proccess_id,proc->ifs.size);

	hashtable_additem(proccesses,proc,id);

	return 0;
}

bool is_initialized_eigrp(int i){
	
	struct eigrp_proccess *proc = hashtable_getitem(proccesses,i);
	if(proc == NULL) return false;
	else return true;
}

void *listen_ip6( void *ptr){
	int proccess_id;
	struct eigrp_proccess *proc;
	interface *iff;

	iff = (interface *)ptr;
	//proccess_id = iff->eigrp_proccess_id;
	proc = get_eigrp_proccess(proccess_id);	

	printf("Starting thread for proccess %d.\n", proccess_id);

	char* buffer = (char*)malloc(PACKET_LEN);
	int cur_length = 0;
	int pak_length = 0;

	while(proc->running){
		int len;

		len = recv(iff->socket6, (buffer+cur_length), PACKET_LEN, 0);
		cur_length += len;
		if(cur_length >= 6){
			pak_length = buffer[5] | buffer[4] << 8;
		}else{
			continue;
		}

		//wait for the whole packet to be transmitted
		if(cur_length >= pak_length){
			packet *p = create_packet(buffer,pak_length);
			handle_packet_ipv6(p);

			//we have some data from the next packet
			if(cur_length > pak_length){
				memmove(buffer,buffer+pak_length,cur_length-pak_length);
				pak_length = 0;
				cur_length -= pak_length;
				continue;
			}

			pak_length = 0;
			cur_length = 0;
		}

		

	}
}

void *listen_ip4( void *ptr){
	interface *iff;

	iff = (interface *)ptr;
	

	//Make a string with family name for printing
	char *family_name;
	if(iff->ifa_addr_ip4->sin_family == AF_INET) family_name = "AF_INET";
	printf("Starting packet listener thread %s for interface %s.\n",family_name,iff->name);

	char buffer[PACKET_LEN];
	int cur_length = 0;
	int pak_length = 0;

	while(iff->running){
		int len;

		len = recv(iff->socket4, (buffer+cur_length), PACKET_LEN, 0);
		cur_length += len;
		if(cur_length > 4){
			pak_length = buffer[3] | buffer[2] << 8;
		}else{
			continue;
		}

		//wait for the whole packet to be transmitted
		if(cur_length >= pak_length){
			packet *p = create_packet(buffer,pak_length);
			handle_packet_ipv4(p,iff);
			free(p);
			//we have some data from the next packet
			if(cur_length > pak_length){
				memmove(buffer,buffer+pak_length,cur_length-pak_length);
				pak_length = 0;
				cur_length -= pak_length;
				continue;
			}

			pak_length = 0;
			cur_length = 0;
		}

		

	}
}

int disable_ip4_loopback(int socket){
	char loopch = 0;
	if(setsockopt(socket, IPPROTO_IP, IP_MULTICAST_LOOP, (char *)&loopch, sizeof(loopch)) < 0){
		return -1;
	}
	return 0;
}

int get_socket_mtu(int socket,int family,char *name){
	struct ifreq ifr;
	ifr.ifr_addr.sa_family = family;
	strcpy(ifr.ifr_name,name);
	if(ioctl(socket, SIOCGIFMTU, &ifr) < 0){
		return -1;
	}
	return ifr.ifr_mtu;
}

int init_interface(interface *iff){
	char host[NI_MAXHOST];
	int ret;

	/*
		INIT FOR IP4
	*/

	iff->running = true;
	iff->reliability = 255;
	iff->load = 1;

	if(iff->ifa_addr_ip4->sin_addr.s_addr != 0){

		

		iff->socket4 = socket(AF_INET, SOCK_RAW, EIGRP_PROT_NUM);
		if(iff->socket4 == -1){
			printf("ERROR:Could not create socket ip4 for interface %s.\n", iff->name);
		}
		printf("Test Family:%d IF:%s\n",iff->ifa_addr_ip4->sin_family,iff->name);
		int result = getnameinfo((struct sockaddr*)iff->ifa_addr_ip4, sizeof(struct sockaddr_in), host, NI_MAXHOST, NULL , 0 , NI_NUMERICHOST);
		if( result != 0){
			printf("ERROR:getnameinfo() failed: %s.\n",gai_strerror(result));
		}
		struct ip_mreq group;
		group.imr_multiaddr.s_addr = inet_addr("224.0.0.10");
		group.imr_interface.s_addr = inet_addr(host);
		if(setsockopt(iff->socket4, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char*)&group, sizeof(group)) < 0){
			printf("ERROR:Could not join multicast group at ip4 for interface %s.\n", iff->name);
		}
		if(setsockopt(iff->socket4, SOL_SOCKET, SO_BINDTODEVICE, iff->name, sizeof(iff->name))){
			printf("ERROR:Could not bind socket to interface %s.\n", iff->name);
			close(iff->socket4);
		}
			
		//----
		if(disable_ip4_loopback(iff->socket4) < 0){
			printf("ERROR:Could not set disable loopback to interface %s.\n", iff->name);
			close(iff->socket4);
		}
		int mtu = get_socket_mtu(iff->socket4,AF_INET,iff->name);
		if(mtu < 0){
			printf("ERROR:Could not get interface %s MTU.\n", iff->name);
			close(iff->socket4);
		}
		iff->mtu = mtu;
		ret = pthread_create(&iff->packet_listener4,NULL ,listen_ip4 ,(void*)iff);
		if(ret){
			printf("ERROR:Error creating listen thread for interface %s at ip4.\n", iff->name);
			close(iff->socket4);
		}
	}

	/*
		INIT FOR IP6
	*/

	if(iff->ifa_addr_ip6->sin6_addr.s6_addr != 0){

		iff->socket6 = socket(AF_INET6, SOCK_RAW, EIGRP_PROT_NUM);
		if(iff->socket6 == -1){
			printf("ERROR:Could not create socket ip6 for interface %s.\n", iff->name);
		}
		printf("Test Family:%d IF:%s\n",iff->ifa_addr_ip6->sin6_family,iff->name);
		int result = getnameinfo((struct sockaddr*)iff->ifa_addr_ip6, sizeof(struct sockaddr_in6), host, NI_MAXHOST, NULL , 0 , NI_NUMERICHOST);
		if( result != 0){
			printf("ERROR:getnameinfo() failed: %s.\n",gai_strerror(result));
		}
		struct ipv6_mreq group;
		struct addrinfo *reslocal,*resmulti,hints;
		
		getaddrinfo(host, NULL, NULL, &reslocal);
		getaddrinfo("FF02::A",NULL,NULL,&resmulti);
		group.ipv6mr_multiaddr = ((struct sockaddr_in6 *)resmulti->ai_addr)->sin6_addr;
		group.ipv6mr_interface = ((struct sockaddr_in6 *)reslocal->ai_addr)->sin6_scope_id;
			if(setsockopt(iff->socket6, IPPROTO_IPV6, IPV6_ADD_MEMBERSHIP, (char*)&group, sizeof(group)) < 0){
			printf("ERROR:Could not join multicast group at ip6 for interface %s.\n", iff->name);
		}
		if(setsockopt(iff->socket6, SOL_SOCKET, SO_BINDTODEVICE, iff->name, sizeof(iff->name))){
			printf("ERROR:Could not bind socket to interface %s.\n", iff->name);
			close(iff->socket6);
		}
		int loopch = 0;
		if(setsockopt(iff->socket6, IPPROTO_IPV6, IPV6_MULTICAST_LOOP, &loopch, sizeof(loopch)) < 0){
			printf("ERROR:Could not set disable loopback to interface %s.\n", iff->name);				
			close(iff->socket6);
		}
		ret = 0;//pthread_create(&iff->packet_listener6 ,NULL ,listen_ip6 ,(void*)iff);
		if(ret){
			printf("ERROR:Error creating listen thread for interface %s at ip6.\n", iff->name);
			close(iff->socket6);
		}
	}

	//Make Self Neighbour - used ONLY for directly connected routes to pull info
	struct neighbour_ *n = malloc(sizeof(struct neighbour_));
	n->address = 0;
	n->interface = iff;
	n->proc = NULL;
	n->eot = true;
	vector_init(&n->routes);

	iff->self = n;

	hashtable_additem(interfaces,iff,iff->index);

	return 0;
}

void *if_change( void *ptr){
	look_interface_changes();
}

void start_interface_state_listener(){
	int ret = pthread_create(&interface_state_listener ,NULL ,if_change , NULL);
	if(ret){
		printf("Error creating interface state listener.\n");
		return;
	}
}

void free_neighbour(neighbour *n){
	n->is_active = false;
	remove_and_recalculate_routes(n);
	vector_free(&n->routes);
	linkedlist_free(&n->packet_queue);
	free(n);
}

void shutdown_proccess(int i){
	struct eigrp_proccess *proc;

	proc = get_eigrp_proccess(i);	

	proc->running = false;

	hashtable_free(proc->neighbours);
}

void shutdown_eigrp(){
	hash_collection *col = malloc(sizeof(hash_collection));
	col->table=proccesses;
	col->table_index = 0;
	col->current = NULL;
	
	struct eigrp_proccess* proc;
	while((proc=next(col)) != NULL){
		shutdown_proccess(proc->proccess_id);
		vector_free(&proc->ifs);
		free(proc);
	}
}

void free_array(){
	hashtable_free(proccesses);
}

//TEST FUNCTION
void send_query(){

	struct eigrp_proccess *proc;
	proc = get_eigrp_proccess(3);	

	hash_collection *col = malloc(sizeof(hash_collection));
	col->table=proc->neighbours;
	col->table_index = 0;
	col->current = NULL;
	
	//Network
	neighbour *n;
	
	while((n=next(col)) != NULL){
		test(n);
	}
}
