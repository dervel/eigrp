#include <stdbool.h>

#ifndef NODE_H_
#define NODE_H_

typedef struct node_{
	void** data;
	struct node_ *next;
} node;

#endif

#ifndef LINKEDLIST_H_
#define LINKEDLIST_H_

typedef struct linkedlist_{
	node *first;
	node *last;
} linkedlist;

typedef struct number_container{
	long number;
} number;

#endif

void linkedlist_addtail(linkedlist *list ,void*);
void linkedlist_init(linkedlist *list);
void *linkedlist_getfirst(linkedlist *list);
void *linkedlist_peekfirst(linkedlist *list);
bool linkedlist_isempty(linkedlist *list);
void linkedlist_free(linkedlist *list);
