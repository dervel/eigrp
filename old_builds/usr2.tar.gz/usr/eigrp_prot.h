#include <stdbool.h>
#include <sys/types.h>
#include <asm/byteorder.h>
#include <netinet/ip.h>

#include "linkedlist.h"
#include "eigrp_structs.h"

#ifndef PACKET_H_
#define PACKET_H_

typedef struct incoming_packet_{
	char *data;
	int length;
} packet;
#endif

packet *create_packet(char *buffer, int lenght);
void queue_reply_packet(neighbour *n,int flags,route *r);
void handle_packet_ipv4(packet *p, interface *iff);
void handle_packet_ipv6(packet *p);
void send_ip4_packet_multicast(packetv4_param *param, struct eigrp_proccess *proc);
void send_ip4_packet(packetv4_param *param, int socket);
unsigned long classic_unscale_bandwidth(unsigned long bw);
unsigned long classic_unscale_delay(unsigned long millisecond);
unsigned long classic_scale_bandwidth(unsigned long bw);
unsigned long classic_scale_delay(unsigned long millisecond);

//TEST FUNCTIONS
void test(neighbour *n);
