int get_telnet_port();
int get_eigrp_routing_table_number();
int get_eigrp_routing_protocol_number();
bool stop();
