#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <pthread.h>
#include <poll.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

#include "config.h"
#include "telnet.h"
#include "eigrp_structs.h"
#include "utils.h"
#include "eigrp_base.h"
#include "packet_factory.h"
#include "eigrp_main.h"

static bool running;
static pthread_t telnet;
static telnet_client *telnet_c;

static struct telnet_info tinfo;

//Line Preparing
void options_help(char *token, char options[][20],int option_size){

	if(strlen(token) == 0)return;
	
	char last = token[strlen(token)-1];
	if(last == '?'){
		int k;
		char *search = strsep(&token,"?");
		sbuffer b;
		b.len =0;
		for(k=0;k<option_size;k++){
			if(compare(search,options[k])){
				int i = sprintf(b.s, "%s   ",options[k]);
				bwrite(&b,b.s,i);
			}
		}
		bwrite(&b,"\n",4);
		telnet_printf(telnet_c->client,b.buffer,b.len);
	}
}

void show_ip_eigrp_interfaces_print(sbuffer *buffer, struct eigrp_proccess *proc){
	int n = sprintf(buffer->s,"IP-EIGRP Interfaces for process %d\n\n\t\t\tXmit Queue\tMean\tPacing Time\tMulticast\tPending\nInterfaces\tPeers\tUn/Reeliable\tSRTT\tUn/Reliable\tFlow Timer\tRoutes\n", proc->proccess_id);
	bwrite(buffer,buffer->s,n);

	hash_collection col;
	prepare_hashcollection(&col,get_interfaces());
	interface *iff;
	while( (iff=next(&col)) != NULL){
		//Finding peers
		int peers =0;
		hash_collection col1;
		prepare_hashcollection(&col1,proc->neighbours);
		neighbour *n;
		while( (n = next(&col1)) != NULL){
			if(iff->index == n->interface->index)peers++;
		}
		//Xmit Queues
		int reliable_packets = proc->multicast_queue.size;
		int k = sprintf(buffer->s,"%s\t\t%d\t\t%d/%d\t%d\t\t%d/%d\t%d\t\t%d\n",iff->name,peers,0,reliable_packets,1234,0,10,0,0);
		bwrite(buffer,buffer->s,k);
	}
}

void show_ip_eigrp_neighbors_print(sbuffer *buffer, struct eigrp_proccess *proc){
	int i = sprintf(buffer->s,"IP-EIGRP Neighbors for process %d\n\nAddress\t\tInterface\tHoldtime\tUptime\tQ\tSeq\tSRTT\tRTO\n\t\t\t\t(secs)\t\t(h:m:s)\tCount\tNum\t(ms)\t(ms)\n",proc->proccess_id);
	bwrite(buffer,buffer->s,i);
	hash_collection col;
	prepare_hashcollection(&col,proc->neighbours);
	neighbour *n;
	while( (n=next(&col)) != NULL){
		char time[9];
		time_format(&time,current_timestamp()-n->discovery_time);
		char address[INET6_ADDRSTRLEN];
		ip_tochar(&address,&n->address);
		int k = sprintf(buffer->s,"%s\t%s\t\t%lld\t\t%s\t%d\t%d\t%lld\t%d\n",address,n->interface->name,n->holdtime/1000,time,n->packet_queue.size,n->pending_ack,n->srtt%1000,0);
		bwrite(buffer,buffer->s,k);
	}
}

void show_ip_eigrp_traffic_print(sbuffer *buffer, struct eigrp_proccess *proc){
	int i = snprintf(buffer->s,sizeof(buffer->s),
		"IP-EIGRP Traffic Statistics for process %d\n"
		"  Hellos sent/received: %d/%d\n"
		"  Updates sent/received: %d/%d\n"
		"  Queries sent/received: %d/%d\n"
		"  Replies sent/received: %d/%d\n"
		"  Acks sent/received: %d/%d\n"
		"  SIA-Queries sent/received: %d/%d\n"
		"  SIA-Replies sent/received: %d/%d\n"
		,proc->proccess_id,
		proc->stats.packets_sent[OPCODE_HELLO],proc->stats.packets_received[OPCODE_HELLO],
		proc->stats.packets_sent[OPCODE_UPDATE],proc->stats.packets_received[OPCODE_UPDATE],
		proc->stats.packets_sent[OPCODE_QUERY],proc->stats.packets_received[OPCODE_QUERY],
		proc->stats.packets_sent[OPCODE_REPLY],proc->stats.packets_received[OPCODE_REPLY],
		proc->stats.acks_sent,proc->stats.acks_received,
		proc->stats.packets_sent[OPCODE_SIAQUERY],proc->stats.packets_received[OPCODE_SIAQUERY],
		proc->stats.packets_sent[OPCODE_SIAREPLY],proc->stats.packets_received[OPCODE_SIAREPLY]
			);
	bwrite(buffer,buffer->s,i);
	
}

void show_ip_eigrp_topology_print(sbuffer *buffer, struct eigrp_proccess *proc){
	int i = sprintf(buffer->s,
	"IP-EIGRP Topology Table for process %d\n\n"
	"Codes: P - Passive, A - Active, U - Update, Q - Query, R - Reply,\n"
	"\tr - Reply status\n\n",proc->proccess_id);
	bwrite(buffer,buffer->s,i);

	//Network
	hash_collection col;
	prepare_hashcollection(&col,proc->topology_support);
	struct topology_support* support;
	while((support=next(&col)) != NULL){
		//Prefix
		struct topology_route *tr;
		hash_collection col2;
		prepare_hashcollection(&col2,support->topology_route);

		while((tr=next(&col2)) != NULL){
			char *code = (tr->route_state == PASSIVE_STATE ? "P" : "A");
			int successors = count_feasible_successors(tr,tr->successor->is_external);
			char address[INET6_ADDRSTRLEN];
			ip_tochar(&address,&tr->dest);
			int k = sprintf(buffer->s,"%s %s/%d, %d successors, FD is %d\n", code, address, tr->prefix, successors, tr->feasible_distance);
			bwrite(buffer,buffer->s,k);
			for(i=0;i<tr->routes.size;i++){
				route *r = vector_get(&tr->routes,i);
				if(tr->successor->is_external != r->is_external)continue;
				if(r->reported_distance > tr->successor->feasible_distance && tr->route_state == PASSIVE_STATE)continue;
				if(r->is_proccess_generated){
					k = sprintf(buffer->s,"\tvia Connected, %s\n", r->sender->interface->name);
					bwrite(buffer,buffer->s,k);
				}else{
					ip_tochar(&address,&r->sender->address);
					if(tr->route_state == PASSIVE_STATE){
						if(r->delay == EIGRP_UNREACHABLE || r->bandwidth == 0)continue;
						k = sprintf(buffer->s,"\tvia %s (%d/%d), %s\n", address, r->feasible_distance, r->reported_distance, r->sender->interface->name);
						bwrite(buffer,buffer->s,k);
					}else{
						k = sprintf(buffer->s,"\tvia %s (%d/%d), %s", address, r->feasible_distance, r->reported_distance, r->sender->interface->name);
						bwrite(buffer,buffer->s,k);
						if(r->rijk == 1){
							k = sprintf(buffer->s,", r");
							bwrite(buffer,buffer->s,k);
						}
						k = sprintf(buffer->s,"\n");
						bwrite(buffer,buffer->s,k);
					}					
					
				}
			}
		}
	}
}

void show_key_chain_print(sbuffer *buffer, key_chain *chain){
	int i = sprintf(buffer->s, "Key-chain %s:\n",chain->name);
	bwrite(buffer,buffer->s,i);

	hash_collection col;
	prepare_hashcollection(&col,chain->keys);
	key *k;
	while( (k=next(&col)) != NULL){
		i = sprintf(buffer->s, "\tkey %ld -- text \"%s\"\n"
		"\t\taccept lifetime (always valid) - (always valid) [valid now]\n"
		"\t\tsend lifetime (always valid) - (always valid) [valid now]\n"
		, k->indentifier,k->password);
		bwrite(buffer,buffer->s,i);
	}
}

//Direct Commands
void show_ip_eigrp_topology_command(char *line){
	char *token;
	token = strsep(&line," ");

	if(token == NULL){
		sbuffer buffer;
		init_sbuffer(&buffer);
		hash_collection col;
		prepare_hashcollection(&col,get_proccesses(AF_INET));
		struct eigrp_proccess *proc;
		while( (proc=next(&col)) != NULL){
			show_ip_eigrp_topology_print(&buffer,proc);
		}
		telnet_printf(telnet_c->client,buffer.buffer,buffer.len);
	}
	if(token){
		//Show topology for specific proccess
		int ret = strtol(token,0,10);
		if(ret != 0){
			struct eigrp_proccess *proc = get_eigrp_proccess(ret,AF_INET);
			if(proc != NULL){
				sbuffer buffer;
				buffer.len = 0;
				show_ip_eigrp_topology_print(&buffer,proc);
				telnet_printf(telnet_c->client,buffer.buffer,buffer.len);
			}
		}
	}
}

void show_ip_eigrp_neighbors_command(char *line){
	char *token;
	token = strsep(&line," ");

	if(token == NULL){
		sbuffer buffer;
		init_sbuffer(&buffer);
		hash_collection col;
		prepare_hashcollection(&col,get_proccesses(AF_INET));
		struct eigrp_proccess *proc;
		while( (proc=next(&col)) != NULL){
			show_ip_eigrp_neighbors_print(&buffer,proc);
		}
		telnet_printf(telnet_c->client,buffer.buffer,buffer.len);
	}
	if(token){
		//Show neighbors for specific proccess
		int ret = strtol(token,0,10);
		if(ret != 0){
			struct eigrp_proccess *proc = get_eigrp_proccess(ret,AF_INET);
			if(proc != NULL){
				sbuffer buffer;
				init_sbuffer(&buffer);
				show_ip_eigrp_neighbors_print(&buffer,proc);
				telnet_printf(telnet_c->client,buffer.buffer,buffer.len);
			}
		}
	}
}

void show_ip_eigrp_interfaces_command(char *line){
	char *token;
	token = strsep(&line," ");

	if(token == NULL){
		sbuffer buffer;
		init_sbuffer(&buffer);
		hash_collection col;
		prepare_hashcollection(&col,get_proccesses(AF_INET));
		struct eigrp_proccess *proc;
		while( (proc=next(&col)) != NULL){
			show_ip_eigrp_interfaces_print(&buffer,proc);
		}
		telnet_printf(telnet_c->client,buffer.buffer,buffer.len);
	}
	if(token){
		//Show interfaces for specific proccess
		int ret = strtol(token,0,10);
		if(ret != 0){
			struct eigrp_proccess *proc = get_eigrp_proccess(ret,AF_INET);
			if(proc != NULL){
				sbuffer buffer;
				init_sbuffer(&buffer);
				show_ip_eigrp_interfaces_print(&buffer,proc);
				telnet_printf(telnet_c->client,buffer.buffer,buffer.len);
			}
		}
	}
}

void show_ip_eigrp_traffic_command(char *line){
	char *token;
	token = strsep(&line," ");

	if(token == NULL){
		sbuffer buffer;
		init_sbuffer(&buffer);
		hash_collection col;
		prepare_hashcollection(&col,get_proccesses(AF_INET));
		struct eigrp_proccess *proc;
		while( (proc=next(&col)) != NULL){
			show_ip_eigrp_traffic_print(&buffer,proc);
		}
		telnet_printf(telnet_c->client,buffer.buffer,buffer.len);
	}
	if(token){
		//Show traffic for specific proccess
		int ret = strtol(token,0,10);
		if(ret != 0){
			struct eigrp_proccess *proc = get_eigrp_proccess(ret,AF_INET);
			if(proc != NULL){
				sbuffer buffer;
				init_sbuffer(&buffer);
				show_ip_eigrp_traffic_print(&buffer,proc);
				telnet_printf(telnet_c->client,buffer.buffer,buffer.len);
			}
		}
	}
}

void show_ip_eigrp_command(char *line){
	char *token;
	token = strsep(&line," ");

	char options[][20] = {"interfaces","neighbors","topology","traffic"};
	options_help(token,options,4);

	if(equals(token,"interfaces")){
		show_ip_eigrp_interfaces_command(line);
	}
	if(equals(token,"neighbors")){
		show_ip_eigrp_neighbors_command(line);
	}
	if(equals(token,"topology")){
		show_ip_eigrp_topology_command(line);
	}
	if(equals(token,"traffic")){
		show_ip_eigrp_traffic_command(line);
	}
}

void show_ip_command(char *line){
	char *token;
	token = strsep(&line," ");

	char options[][20] = {"eigrp"};
	options_help(token,options,2);

	if(equals(token,"eigrp")){
		show_ip_eigrp_command(line);
	}
}

void show_ipv6_command(char *line){

}

void show_key_chain_command(char *line){
	char *token;
	token = strsep(&line," ");

	if(token == NULL){
		sbuffer buffer;
		init_sbuffer(&buffer);
		hash_collection col;
		prepare_hashcollection(&col,get_global_vars()->key_chains);
		key_chain *chain;
		while( (chain=next(&col)) != NULL){
			show_key_chain_print(&buffer,chain);
		}
		telnet_printf(telnet_c->client,buffer.buffer,buffer.len);
	}
	if(token){
		key_chain *chain = get_key_chain(token);
		//Show key chain for specific proccess
		if(chain != NULL){
			sbuffer buffer;
			init_sbuffer(&buffer);
			show_key_chain_print(&buffer,chain);
			telnet_printf(telnet_c->client,buffer.buffer,buffer.len);
		}
	}
}

void show_key_command(char *line){
	char *token;
	token = strsep(&line," ");

	char options[][20] = {"chain"};
	options_help(token,options,1);

	if(equals(token,"chain")){
		show_key_chain_command(line);
	}
}

void show_command(char *line){
	char *token;
	token = strsep(&line," ");

	char options[][20] = {"ip","ipv6","key"};
	options_help(token,options,3);

	if(equals(token,"ip")){
		show_ip_command(line);
	}
	if(equals(token,"ipv6")){
		show_ipv6_command(line);
	}
	if(equals(token,"key")){
		show_key_command(line);
	}
}

//DEBUGGING COMMANDS
void dual_nbrchange(struct eigrp_proccess *proc, neighbour *n,bool active, char *msg){

	if(!tinfo.connected)return;

	sbuffer buffer;
	init_sbuffer(&buffer);

	char address[INET6_ADDRSTRLEN];
	char timestamp[20];
	char *activestr;

	ip_tochar(&address,&n->address);
	str_now(&timestamp);
	activestr = (active ? "up" : "down" );

	int i = sprintf(buffer.s,"\n%s: DUAL-5-NBRCHANGE: IP-EIGRP(0) %u: Neighbor %s (%s) is %s: %s",timestamp, proc->proccess_id,address,n->interface->name,activestr,msg);
	bwrite(&buffer,buffer.s,i);

	telnet_printf(telnet_c->client,buffer.buffer,buffer.len);

}

void topology_search(struct topology_route *tr){
	if(!tinfo.connected)return;
	if(!tinfo.debug.fsm)return;

	sbuffer buffer;
	init_sbuffer(&buffer);

	char address[INET6_ADDRSTRLEN];
	char timestamp[20];

	ip_tochar(&address,&tr->dest);
	str_now(&timestamp);

	char *active = (tr->route_state == PASSIVE_STATE ? "not " : "");
	int i = sprintf(buffer.s,"\n%s: DUAL: dest(%s) %sactive",timestamp,address,active);
	bwrite(&buffer,buffer.s,i);

	telnet_printf(telnet_c->client,buffer.buffer,buffer.len);
}

void packet_handling(char *state,route *r){
	if(!tinfo.connected)return;
	if(!tinfo.debug.fsm)return;

	sbuffer buffer;
	init_sbuffer(&buffer);

	char route_address[INET6_ADDRSTRLEN];
	char neighbor_address[INET6_ADDRSTRLEN];
	char timestamp[20];

	ip_tochar(&route_address,&r->dest);
	ip_tochar(&neighbor_address,&r->sender->address);
	str_now(&timestamp);

	int i = sprintf(buffer.s,"\n%s: DUAL: %s: %s via %s metric %u/%u",timestamp, state, route_address,neighbor_address,r->reported_distance,r->feasible_distance);
	bwrite(&buffer,buffer.s,i);

	telnet_printf(telnet_c->client,buffer.buffer,buffer.len);
}

void telnet_find_fs(struct topology_route *tr, route *successor){
	if(!tinfo.connected)return;
	if(!tinfo.debug.fsm)return;

	sbuffer buffer;
	init_sbuffer(&buffer);

	char route_address[INET6_ADDRSTRLEN];
	char neighbor_address[INET6_ADDRSTRLEN];
	char timestamp[20];
	int feasible_distance;
	int reported_distance;

	if(successor != NULL){
		feasible_distance = successor->feasible_distance;
		reported_distance = successor->reported_distance;
	}else{
		feasible_distance = EIGRP_UNREACHABLE;
		reported_distance = EIGRP_UNREACHABLE;
	}

	ip_tochar(&route_address,&tr->dest);
	str_now(&timestamp);

	int i = sprintf(buffer.s,"\n%s: DUAL: Find FS for dest %s/%d. FD is %u, RD is %u",timestamp, route_address,tr->prefix,feasible_distance,reported_distance);
	bwrite(&buffer,buffer.s,i);

	telnet_printf(telnet_c->client,buffer.buffer,buffer.len);

	sbuffer buffer2;
	init_sbuffer(&buffer2);

	int k;
	for(i=0;i<tr->routes.size;i++){
		route *r = vector_get(&tr->routes,i);
				
		ip_tochar(&neighbor_address,&r->sender->address);
		k = sprintf(buffer2.s,"\n%s: DUAL:     %s metric %u/%u",timestamp, neighbor_address,r->feasible_distance,r->reported_distance);
		bwrite(&buffer2,buffer2.s,k);
			
	}

	telnet_printf(telnet_c->client,buffer2.buffer,buffer2.len);
}

void telnet_install_route(route *r){
	if(!tinfo.connected)return;
	if(!tinfo.debug.fsm)return;

	sbuffer buffer;
	init_sbuffer(&buffer);

	char route_address[INET6_ADDRSTRLEN];
	char neighbor_address[INET6_ADDRSTRLEN];
	char timestamp[20];

	ip_tochar(&route_address,&r->dest);
	ip_tochar(&neighbor_address,&r->sender->address);
	str_now(&timestamp);

	int i = sprintf(buffer.s,"\n%s: DUAL: RT installed %s/%d via %s",timestamp, route_address,r->prefix,neighbor_address);
	bwrite(&buffer,buffer.s,i);

	telnet_printf(telnet_c->client,buffer.buffer,buffer.len);
}

void telnet_route_active(struct topology_route *tr){
	if(!tinfo.connected)return;
	if(!tinfo.debug.fsm)return;

	sbuffer buffer;
	init_sbuffer(&buffer);

	char route_address[INET6_ADDRSTRLEN];
	char timestamp[20];
	ip_tochar(&route_address,&tr->dest);
	str_now(&timestamp);


	int i = sprintf(buffer.s,"\n%s: DUAL: Dest %s/%d entering active state",timestamp, route_address,tr->prefix);
	bwrite(&buffer,buffer.s,i);

	telnet_printf(telnet_c->client,buffer.buffer,buffer.len);
}

void telnet_reply_count(int count){
	if(!tinfo.connected)return;
	if(!tinfo.debug.fsm)return;

	sbuffer buffer;
	init_sbuffer(&buffer);

	char timestamp[20];
	str_now(&timestamp);	

	int i = sprintf(buffer.s,"\n%s: DUAL: reply count is %u",timestamp, count);
	bwrite(&buffer,buffer.s,i);

	telnet_printf(telnet_c->client,buffer.buffer,buffer.len);

}

void telnet_all_replies_received(struct topology_route *tr){
	if(!tinfo.connected)return;
	if(!tinfo.debug.fsm)return;

	sbuffer buffer;
	init_sbuffer(&buffer);

	char timestamp[20];
	str_now(&timestamp);
	char route_address[INET6_ADDRSTRLEN];
	ip_tochar(&route_address,&tr->dest);

	int i = sprintf(buffer.s,"\n%s: DUAL: All replies received for %s/%d",timestamp, route_address, tr->prefix);
	bwrite(&buffer,buffer.s,i);

	telnet_printf(telnet_c->client,buffer.buffer,buffer.len);
}

void telnet_remove_successor(route *r){
	if(!tinfo.connected)return;
	if(!tinfo.debug.fsm)return;

	sbuffer buffer;
	init_sbuffer(&buffer);

	char timestamp[20];
	str_now(&timestamp);
	char route_address[INET6_ADDRSTRLEN];
	ip_tochar(&route_address,&r->dest);
	char neighbor_address[INET6_ADDRSTRLEN];
	ip_tochar(&neighbor_address,&r->sender->address);

	int i = sprintf(buffer.s,"\n%s: DUAL: Removing dest %s/%d, nexthop %s",timestamp, route_address, r->prefix, neighbor_address);
	bwrite(&buffer,buffer.s,i);

	telnet_printf(telnet_c->client,buffer.buffer,buffer.len);
}

void telnet_no_routes(struct topology_route *tr){
	if(!tinfo.connected)return;
	if(!tinfo.debug.fsm)return;

	sbuffer buffer;
	init_sbuffer(&buffer);

	char timestamp[20];
	str_now(&timestamp);
	char route_address[INET6_ADDRSTRLEN];
	ip_tochar(&route_address,&tr->dest);

	int i = sprintf(buffer.s,"\n%s: DUAL: No routes. Flushing dest %s/%d",timestamp, route_address, tr->prefix);
	bwrite(&buffer,buffer.s,i);

	telnet_printf(telnet_c->client,buffer.buffer,buffer.len);
}

void telnet_dest_state_change(struct topology_route *tr, int new_state){
	if(!tinfo.connected)return;
	if(!tinfo.debug.fsm)return;

	sbuffer buffer;
	init_sbuffer(&buffer);

	char timestamp[20];
	str_now(&timestamp);

	int i = sprintf(buffer.s,"\n%s: DUAL: Going from state %d to %d",timestamp, tr->ioj, new_state);
	bwrite(&buffer,buffer.s,i);

	telnet_printf(telnet_c->client,buffer.buffer,buffer.len);
}

void telnet_neighbour_down(neighbour *n){
	if(!tinfo.connected)return;
	if(!tinfo.debug.neighbors)return;

	sbuffer buffer;
	init_sbuffer(&buffer);

	char timestamp[20];
	str_now(&timestamp);
	char neighbor_address[INET6_ADDRSTRLEN];
	ip_tochar(&neighbor_address,&n->address);


	int i = sprintf(buffer.s,"\n%s: EIGRP: Neighbor %s went down on %s",timestamp, neighbor_address, n->interface->name);
	bwrite(&buffer,buffer.s,i);

	telnet_printf(telnet_c->client,buffer.buffer,buffer.len);
}

void telnet_new_peer(neighbour *n){
	if(!tinfo.connected)return;
	if(!tinfo.debug.neighbors)return;

	sbuffer buffer;
	init_sbuffer(&buffer);

	char timestamp[20];
	str_now(&timestamp);
	char neighbor_address[INET6_ADDRSTRLEN];
	ip_tochar(&neighbor_address,&n->address);


	int i = sprintf(buffer.s,"\n%s: EIGRP: New peer %s",timestamp, neighbor_address);
	bwrite(&buffer,buffer.s,i);

	telnet_printf(telnet_c->client,buffer.buffer,buffer.len);
}

void debug_eigrp_command(char *line){
	char *token;
	token = strsep(&line," ");

	char options[][20] = {"fsm","neighbors","nsf","packets","transmit"};
	options_help(token,options,5);

	if(equals(token,"fsm")){
		tinfo.debug.fsm = true;
		char *message = "EIGRP FSM Events/Action debugging is on\n";
		telnet_printf(telnet_c->client,message,strlen(message));
	}
	if(equals(token,"neighbors")){
		tinfo.debug.neighbors = true;
		char *message = "EIGRP Neighbors debugging is on\n";
		telnet_printf(telnet_c->client,message,strlen(message));
	}
	if(equals(token,"nsf")){
		tinfo.debug.nsf = true;
	}
	if(equals(token,"packets")){
		
	}
	if(equals(token,"transmit")){
		
	}
}

void debug_command(char *line){
	char *token;
	token = strsep(&line," ");

	char options[][20] = {"eigrp"};
	options_help(token,options,1);

	if(equals(token,"eigrp")){
		debug_eigrp_command(line);
		return;
	}

	char *message = "Invalid input detected at 'debug ?'\n";
	telnet_printf(telnet_c->client,message,strlen(message));
}

void no_debug_eigrp_command(char *line){
	char *token;
	token = strsep(&line," ");

	char options[][20] = {"fsm","neighbors","nsf","packets","transmit"};
	options_help(token,options,5);

	if(equals(token,"fsm")){
		tinfo.debug.fsm = false;
		char *message = "EIGRP FSM Events/Action debugging is off\n";
		telnet_printf(telnet_c->client,message,strlen(message));
	}
	if(equals(token,"neighbors")){
		tinfo.debug.neighbors = false;
		char *message = "EIGRP Neighbors debugging is off\n";
		telnet_printf(telnet_c->client,message,strlen(message));
	}
	if(equals(token,"nsf")){
		tinfo.debug.nsf = false;
	}
	if(equals(token,"packets")){
		
	}
	if(equals(token,"transmit")){
		
	}
}

void no_debug_command(char *line){
	char *token;
	token = strsep(&line," ");

	char options[][20] = {"eigrp"};
	options_help(token,options,1);

	if(equals(token,"eigrp")){
		no_debug_eigrp_command(line);
	}

	
}


void no_command(char *line){
	char *token;
	token = strsep(&line," ");

	char options[][20] = {"debug"};
	options_help(token,options,1);

	if(equals(token,"debug")){
		no_debug_command(line);
	}
}

void handle_command(const char *buffer, int len){
	char *token;
	//Do not copy the last 2 character as they are part of telnet and not the actual command
	char *line = malloc(len);
	char *original_pointer = line;
	memcpy(line,buffer,len);
	line[len-2] = 0;
	token = strsep(&line," ");

	char options[][20] = {"show","enable","no","debug"};
	options_help(token,options,4);

	/*
	if(equals(token,"shutdown") && tinfo.authed){
		shutdown_eigrp();
	}*/
	if(equals(token,"show")){
		show_command(line);
	}
	if(equals(token,"debug") && tinfo.authed){
		debug_command(line);
	}
	if(equals(token,"no") && tinfo.authed){
		no_command(line);
	}
	if(equals(token,"enable")){
		tinfo.authed = true;
	}
	free(original_pointer);


	sbuffer b;
	init_sbuffer(&b);
	char *hostname = get_global_vars()->hostname;
	bwrite(&b, hostname,strlen(hostname));
	tinfo.authed ? bwrite(&b,"#",1) : bwrite(&b,">",1);
	telnet_printf(telnet_c->client,b.buffer,b.len);
}

//Telnet Functions

void stop_telnet(){
	running = false;
	tinfo.connected = false;
	pthread_join(telnet,NULL);
}

static void _send(int sock, const char *buffer, size_t size){
	int rs;
	while(size > 0){
		if((rs = send(sock,buffer,size,0)) == -1){
			if(errno != EINTR && errno != ECONNRESET){
				printf("send() failed:%s\n",strerror(errno));
			} else{
				return;
			}
		}else if(rs==0){
			printf("send() unexpectedly returned 0\n");
		}
		buffer += rs;
		size -= rs;
	}
}

void telnet_event_handler(telnet_t *telnet, telnet_event_t *ev, void *user_data){
	//telnet_client *user = (telnet_client*)user_data;

	switch(ev->type){
		case TELNET_EV_DATA:
			handle_command(ev->data.buffer, ev->data.size);
			break;
		case TELNET_EV_SEND:
			_send(telnet_c->sock, ev->data.buffer, ev->data.size);
			break;
		case TELNET_EV_IAC:
		case TELNET_EV_WILL:
		case TELNET_EV_WONT:
		case TELNET_EV_DO:
		case TELNET_EV_DONT:
		case TELNET_EV_SUBNEGOTIATION:
		case TELNET_EV_COMPRESS:
		case TELNET_EV_ZMP:
		case TELNET_EV_TTYPE:
		case TELNET_EV_ENVIRON:
		case TELNET_EV_MSSP:
		case TELNET_EV_WARNING:
		case TELNET_EV_ERROR:
			break;
		
	}
}

int init_telnet_server(){
	int ret;

	ret = pthread_create(&telnet,NULL ,telnet_thread ,NULL);
	if(ret){
		printf("ERROR:Error starting telnet.\n");
	}

	return 0;
}

void *telnet_thread(void *ptr){

	int rs;
	int listen_sock;
	char buffer[512];
	socklen_t addrlen;
	struct sockaddr_in addr;
	struct pollfd pfd1[1];
	memset(&tinfo,0,sizeof(struct telnet_info));

	running = true;

	static const telnet_telopt_t my_telopts[] = {
		{ TELNET_TELOPT_ECHO,      TELNET_WILL, TELNET_DO },
		{ -1, 0, 0 }
	};

	while(running){

		tinfo.authed = false;		
		if((listen_sock = socket(AF_INET, SOCK_STREAM, 0)) == -1){
			printf("Error creating telnet.\n");
			return NULL;
		}

		rs = 1;
		setsockopt(listen_sock, SOL_SOCKET, SO_REUSEADDR, (void*)&rs, sizeof(rs));

		memset(&addr, 0, sizeof(addr));
		addr.sin_family = AF_INET;
		addr.sin_addr.s_addr = INADDR_ANY;
		addr.sin_port = htons(get_telnet_port());

		if(bind(listen_sock, (struct sockaddr*)&addr, sizeof(addr)) == -1){
			printf("ERR: Could not bind socket.\n");
			return NULL;
		}

		if(listen(listen_sock, 1) == -1){
			printf("Error listening.\n");
			return NULL;
		}

		memset(pfd1, 0,sizeof(pfd1));
		pfd1[0].fd = listen_sock;
		pfd1[0].events = POLLIN;
		addrlen = sizeof(addr);
		
		telnet_c = malloc(sizeof(telnet_client));

		while(poll(pfd1,1,100) != -1 && running){
			if(pfd1[0].revents & POLLIN){
				if((telnet_c->sock = accept(listen_sock, (struct sockaddr*)&addr, &addrlen)) == -1){
					printf("Error accept().\n");
					return NULL;
				}else{
					break;
				}
			}
		}

		if(!running)break;
		
		printf("TELNET CONNECTION RECEIVED.\n");
		tinfo.authed = false;
		close(listen_sock);

		telnet_c->client = telnet_init(my_telopts,telnet_event_handler,0,telnet_c);
		tinfo.connected = true;
		
		sbuffer b;
		init_sbuffer(&b);
		char *hostname = get_global_vars()->hostname;
		bwrite(&b, hostname,strlen(hostname));
		tinfo.authed ? bwrite(&b,"#",1) : bwrite(&b,">",1);
		telnet_printf(telnet_c->client,b.buffer,b.len);

		struct pollfd pfd;
		memset(&pfd, 0,sizeof(struct pollfd));
		pfd.fd = telnet_c->sock;
		pfd.events = POLLIN;// | POLLHUP | POLLRDNORM;
		char buff[10]; // Just to pass as paramters doesn't get used

		while(running){
			poll(&pfd,1,100);

			if(recv(telnet_c->sock,buff,10, MSG_PEEK | MSG_DONTWAIT) == 0){
				printf("TELNET CLIENT DISCONNECTED\n");
				break;
			}
			if(pfd.revents & POLLIN){
				if((rs =recv(telnet_c->sock, buffer, sizeof(buffer),0)) > 0){
					telnet_recv(telnet_c->client, buffer, rs);
				}

			}
			
		}

		/*while(pfd.revents == 0 && running){
			if(poll(&pfd,1,100) > 0){
				if(recv(telnet_c->sock,buff,10, MSG_PEEK | MSG_DONTWAIT) == 0){
					printf("TELNET CLIENT DISCONNECTED\n");
					break;
				}

				if((rs =recv(telnet_c->sock, buffer, sizeof(buffer),0)) > 0){
					telnet_recv(telnet_c->client, buffer, rs);
				}

			}

			
		}*/
		tinfo.connected = false;
		telnet_free(telnet_c->client);
		close(telnet_c->sock);


	}

	free(telnet_c);

	return NULL;

}
