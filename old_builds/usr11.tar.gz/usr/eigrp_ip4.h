#include <netinet/in.h>

#include "eigrp_structs.h"

bool init_ip4(interface *iff);
void *send_ipv4_packets( void *ptr);
void *listen_ip4( void *ptr);
void *hello_packet_thread_ip4(void *ptr);
