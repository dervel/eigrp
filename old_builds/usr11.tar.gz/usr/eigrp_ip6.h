#include <netinet/in.h>

#include "eigrp_structs.h"

bool init_ip6(interface *iff);
void *send_ipv6_packets( void *ptr);
void *listen_ip6( void *ptr);
void *hello_packet_thread_ip6(void *ptr);
