#define _GNU_SOURCE
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <ifaddrs.h>
#include <netdb.h>
#include <pthread.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <poll.h>
#include <errno.h>


#include "config.h"
#include "eigrp_base.h"
#include "eigrp_prot.h"
#include "vector.h"
#include "utils.h"
#include "hashtable.h"
#include "eigrp_structs.h"
#include "packet_factory.h"
#include "collection.h"
#include "netlink.h"
#include "libtelnet.h"
#include "telnet.h"
#include "eigrp_command_parser.h"

#define EIGRP_PROT_NUM 88
#define DEFAULT_NEIGHBOURS_HASHTABLE_SIZE 40
#define CONNECTED_ROUTE 999


static hash_table_t *proccesses;
static hash_table_t *interfaces;
static pthread_t interface_state_listener;
static globals *global_vars;
static bool proccesses_initialized;

void pre_init(){
	global_vars = malloc(sizeof(globals));
	global_vars->hostname = "Router";
	global_vars->key_chains = create_hash_table(50);
	proccesses_initialized = false;
}

void post_init(){
	init_telnet_server();
	proccesses_initialized = true;
}

globals *get_global_vars(){
	return global_vars;
}

key_chain *get_key_chain(char *name){
	return hashtable_getitem(global_vars->key_chains,hash(name));
}

interface *get_interface(int index){
	return hashtable_getitem(interfaces,index);
}

hash_table_t *get_interfaces(){
	return interfaces;
}

hash_table_t *get_proccesses(){
	return proccesses;
}

void init_proccess_hashtable(int num){
	proccesses = create_hash_table(num);
}

struct eigrp_proccess *get_eigrp_proccess(int id){

	struct eigrp_proccess *proc = hashtable_getitem(proccesses,id);
	if(proc == NULL)
		printf("BASE:Requested a NULL proccess.\n");

	return proc;
}

route *unreachable_route(int dest,int prefix,neighbour *n){
	
	route *r = create_route();
	r->dest = dest;
	r->prefix = prefix;
	r->sender = n;
	r->delay = EIGRP_UNREACHABLE;
	r->bandwidth = 0;
	r->load = 0;
	r->reliability = 0;
	r->hop = 0;
	r->to_be_removed = true;

	return r;
}

void init_interfaces_hashtable(){
	interfaces = create_hash_table(50);
}

route *get_route(route *r, neighbour *n){
	int i;
	for(i=0;i<n->routes.size;i++){
		route *r1 = vector_get(&n->routes, i);
		if(r1->dest == r->dest && r1->prefix == r->prefix)return r1;
	}
	return NULL;
}

int count_feasible_successors(struct topology_route *tr){
	int i,count=0;
	for(i=0;i<tr->routes.size;i++){
		route *r = vector_get(&tr->routes,i);
		if(r->reported_distance <= tr->feasible_distance)count++;
	}
	return count;
}

unsigned long calculate_classic_metric(struct eigrp_proccess *proc,unsigned int bandwidth,int delay,int mtu ,int load,int rel){
	if(delay == EIGRP_UNREACHABLE)
		return EIGRP_INACCESSIBLE;

	int reliability = 1;
	unsigned int bw = (256 * (unsigned long)EIGRP_BANDWIDTH / bandwidth);
	unsigned int dl = 256 * (delay /10); // delay
	if(proc->k5 != 0){
		reliability = (proc->k5 / (rel + proc->k4 ));
	}

	unsigned long metric = (
			proc->k1 * bw + 
			((proc->k2 * bw)/(256-load)) +
			(proc->k3 * dl)
		     ) * reliability;

	return metric;
}

void calculate_classic_route_metric(struct eigrp_proccess *proc, route *newroute){
	unsigned long metric = calculate_classic_metric(proc,newroute->bandwidth,newroute->delay,newroute->mtu,newroute->load,newroute->reliability);	
	//Reported Distance
	newroute->reported_distance = metric;
	//Feasible Distance
	//Bandwidth
	int if_bw = newroute->sender->interface->bandwidth;		
	int min_bw = newroute->bandwidth < if_bw ? newroute->bandwidth : if_bw;
	//Delay
	unsigned long if_delay = newroute->sender->interface->delay;
	unsigned long acc_delay=0;
	if(if_delay == EIGRP_UNREACHABLE || newroute->delay == EIGRP_UNREACHABLE){
		acc_delay = EIGRP_UNREACHABLE;
	}else{
		acc_delay = if_delay + newroute->delay;
	}
	//Mtu
	int if_mtu = newroute->sender->interface->mtu;
	int min_mtu = newroute->mtu < if_mtu ? newroute->mtu : if_mtu;
	//Load
	int if_load = newroute->sender->interface->load;
	int max_load = newroute->load > if_load ? newroute->load : if_load;
	//Reliability
	int if_rel = newroute->sender->interface->reliability;
	int min_rel = newroute->reliability < if_rel ? newroute->reliability : if_rel;

	if(newroute->is_proccess_generated){
		newroute->feasible_distance = metric;
	}else{
		unsigned long feasible_distance = calculate_classic_metric(proc,min_bw,acc_delay,min_mtu ,max_load,min_rel);
		newroute->feasible_distance = feasible_distance;
	}
}

//The idea behind this is to use the network as an identifier, however we can have the
//same network with different prefixes. So we use 2 hashtables to find the route
//One searches the network and the other searches the prefix
struct topology_route* get_topology_network(struct eigrp_proccess* proc, int dest,int prefix){
	struct topology_support* network_table = hashtable_getitem(proc->topology_support, dest);
	if(network_table == NULL){
		printf("Creatng network table\n");
		struct topology_support* new_network_table = malloc(sizeof (struct topology_support));
		new_network_table->topology_route = create_hash_table(32);
		hashtable_additem(proc->topology_support, new_network_table , dest);
		network_table = new_network_table;
	}
	struct topology_route *prefix_route = hashtable_getitem(network_table->topology_route, prefix);
	if(prefix_route == NULL){
		printf("Creatng prefix table\n");
		struct topology_route *new_route = malloc(sizeof(struct topology_route));
		
		//Init topology_route
		vector_init(&new_route->routes);
		new_route->feasible_distance = 0xFFFFFFFF; //set the metric to infinate
		new_route->dest = dest;
		new_route->prefix = prefix;
		new_route->proc = proc;
		new_route->route_state = ACTIVE_STATE;
		new_route->successor = NULL;
		new_route->ioj = -1;
		//end topology_route init

		hashtable_additem(network_table->topology_route, new_route, prefix);
		prefix_route = new_route;
	}
	return prefix_route;
}

bool topology_route_exists(struct eigrp_proccess* proc, int dest,int prefix){
	struct topology_support* network_table = hashtable_getitem(proc->topology_support, dest);
	if(network_table == NULL) return false;
	struct topology_route *prefix_route = hashtable_getitem(network_table->topology_route, prefix);
	return (prefix_route == NULL ? false : true);
}

void remove_route_entry(struct topology_route *tr, route *new_successor){
	//Remove the old entry from the routing table
	if(tr->successor != NULL && tr->successor->sender->address != 0)
		route_del((__u32*)&tr->dest, &tr->successor->sender->address, tr->prefix, (__u32*)&tr->old_successor_metric);
}

void set_new_successor(struct topology_route *tr, route *new_successor){

	printf("Neightbour Address:%d\n",new_successor->sender->address);
	remove_route_entry(tr,new_successor);
		
	tr->successor = new_successor;
	//Add the new entry
	if(tr->successor->sender->address != 0){
		route_add((__u32*)&tr->dest, &tr->successor->sender->address, tr->prefix, (__u32*)&tr->successor->feasible_distance);
		tr->old_successor_metric = tr->successor->feasible_distance;
	}
}

route *find_new_successor(struct topology_route *tr){
	route *new_successor = NULL;
	int lowest_distance = 0xFFFFFFFF;
	int i;
	printf("Find new successor routes for %s are %d\n",ip4_tochar(tr->dest),tr->routes.size);
	for(i=0;i<tr->routes.size;i++){
		route *r = vector_get(&tr->routes,i);

		if(r->delay == EIGRP_UNREACHABLE)continue;
		if(r->bandwidth == 0)continue;

		printf("Route From: %d, reported distance:%d\n",r->sender->address,r->reported_distance);

		calculate_classic_route_metric(tr->proc,r);
		if(r->reported_distance < tr->feasible_distance && r->feasible_distance < lowest_distance){
			lowest_distance = r->feasible_distance;
			new_successor = r;
		}
		if(r->is_proccess_generated && r->feasible_distance <= lowest_distance){
			lowest_distance = r->feasible_distance;
			new_successor = r;
		}
	}

	return new_successor;
}

unsigned int get_least_feasible_distance(struct topology_route *tr){
	int i;
	unsigned int least_router_distance = 0xFFFFFFFF; //Least distance of this router to the destination

	for(i=0;i<tr->routes.size;i++){
		route *record = vector_get(&tr->routes, i);
		calculate_classic_route_metric(tr->proc,record);
		if(record->feasible_distance < least_router_distance)
			least_router_distance = record->feasible_distance;
	}

	return least_router_distance;
	
}

void set_waiting_for_reply(struct topology_route *tr,neighbour *n){
	int i;
	for(i=0;i<tr->routes.size;i++){
		route *r = vector_get(&tr->routes,i);
		if(r->is_proccess_generated || !r->sender->interface->is_up || r->sender->state == PENDING_STATE || n->address == r->sender->address)
			r->rijk = 0; //FSM(8)
		else 
			r->rijk =1;
	}
}

bool if_all_replies_received(struct topology_route *tr){
	
	int i;
	for(i=0;i<tr->routes.size;i++){
		route *r = vector_get(&tr->routes,i);
		if(r->rijk == 1) return false;
	}
	return true;
}

void set_neighbour_routes_unreachable(neighbour *n){
	int i;

	for(i=0;i<n->routes.size;i++){
		route *r = vector_get(&n->routes,i);
		r->delay = EIGRP_UNREACHABLE;
	}
}

void recalculate_routes(neighbour *n){

	printf("Recalculating routes.\n");
	int i;

	for(i=0;i<n->routes.size;i++){
		route *r = vector_get(&n->routes,i);

		struct topology_route *tr = get_topology_network(n->proc,r->dest,r->prefix);
		
		if(tr->successor->sender->address == n->address){
			r->delay = EIGRP_UNREACHABLE;
			//Try to find a new successor, if no successors available set route to active
			route *successor = find_new_successor(tr);
			if(successor != NULL){
				//FSM(2)
				printf("Setting new:%d\n",successor->sender->address);
				set_new_successor(tr, successor);
				//New successor send info
				add_update_tlv_multicast(n->proc,successor,0);
				continue;		
			}else{
				remove_route_entry(tr,tr->successor);
				//FSM(4)
				set_route_to_active(tr,1,tr->successor);
			}
		}
	}

	create_packets_from_queues(n->proc);

}

void remove_route_from_neighbour(route *r){
	neighbour *n = r->sender;
	int i;
	for(i=0;i<n->routes.size;i++){
		route *r1 = vector_get(&n->routes,i);
		if(r1->dest == r->dest && r1->prefix == r->prefix){
			vector_delete(&n->routes,i);
			return;
		}
	}
}

void remove_topology_route(struct topology_route *tr){
	
	int i;
	for(i=0;i<tr->routes.size;i++){
		route *r = vector_get(&tr->routes,i);
		remove_route_from_neighbour(r);
		//free(r);
	}
	struct topology_support* network_table = hashtable_getitem(tr->proc->topology_support, tr->dest);
	hashtable_removeitem(network_table->topology_route, tr->prefix);
	vector_free(&tr->routes);
	free(tr);
}

void proccess_active_state_route(struct topology_route *tr){
	route *new_successor;
	printf("Processing route %s/%d, flag:%d\n",ip4_tochar(tr->dest),tr->prefix,tr->ioj);
	if(tr->ioj == 0){
		tr->feasible_distance = get_least_feasible_distance(tr);
		new_successor = find_new_successor(tr);
		if(new_successor == NULL){
			//FSM(11)
			//No successor was found
			set_route_to_active(tr,1,tr->successor);			
		}else{
			//FSM(14)
			tr->route_state = PASSIVE_STATE;
			tr->ioj = -1;
			//We don't send a reply
			//Set the new_successor
			set_new_successor(tr, new_successor);
			add_update_tlv_multicast(tr->proc,tr->successor,0);

		}
	}else if(tr->ioj == 1){
		tr->feasible_distance = get_least_feasible_distance(tr);
		new_successor = find_new_successor(tr);
		if(new_successor == NULL){
			route *unreachable = unreachable_route(tr->dest,tr->prefix,tr->successor->sender);
			add_update_tlv_multicast(tr->proc,unreachable,0);
			remove_topology_route(tr);
			free(unreachable);
		}else{
			//FSM(15)
			tr->route_state = PASSIVE_STATE;
			tr->ioj = -1;
			set_new_successor(tr, new_successor);
			add_update_tlv_multicast(tr->proc,tr->successor,0);
		}
	}else if(tr->ioj == 2){
		new_successor = find_new_successor(tr);
		if(new_successor == NULL){
			//FSM(12)
			//No successor was found
			set_route_to_active(tr,3,tr->successor);
		}else{
			//FSM(16)
			tr->route_state = PASSIVE_STATE;
			tr->ioj = -1;
			//Send the reply at our previous successor
			add_reply_tlv_neighbour(tr->successor->sender,new_successor,0);
			//Set the new_successor
			set_new_successor(tr, new_successor);
			add_update_tlv_multicast(tr->proc,tr->successor,0);
		}
	}else if(tr->ioj == 3){
		tr->feasible_distance = get_least_feasible_distance(tr);
		new_successor = find_new_successor(tr);
		if(new_successor == NULL){
			route *unreachable = unreachable_route(tr->dest,tr->prefix,tr->successor->sender);
			add_reply_tlv_neighbour(tr->successor->sender,unreachable,0);
			add_update_tlv_multicast(tr->proc,unreachable,0);
			remove_topology_route(tr);
			free(unreachable);
		}else{
			//FSM(13)
			tr->route_state = PASSIVE_STATE;
			tr->ioj = -1;
			//Send the reply at our previous successor
			add_reply_tlv_neighbour(tr->successor->sender,new_successor,0);
			//Set the new_successor
			set_new_successor(tr, new_successor);
			add_update_tlv_multicast(tr->proc,tr->successor,0);
		}
	}else{
		printf("I fucked up the flag.\n");
	}

	//create_packets_from_queues(tr->proc);
}

void *stuck_in_active(void *ptr){
	route *r;
	int i;

	r =(route *)ptr;
	r->sia_query_received = false;


	for(i=0;i<4;i++){
		sleep_millis(90 * 1000);

		//Reply was received
		if(r->rijk == 0) return NULL;

		//Do not send siaquery at the first loop - Initial period
		if(i != 0){
			send_siaquery_neighbour(r->sender,r,0,0);
		}

		//If the neighbour doesn't reply to a sia-query set all dest as unreachable
		if(i != 0 && !r->sia_query_received){
			set_neighbour_routes_unreachable(r->sender);
			recalculate_routes(r->sender);
			r->rijk = 0;
			//Check if all replies were received
			struct topology_route *tr = get_topology_network(r->sender->proc,r->dest,r->prefix);
			if(if_all_replies_received(tr)){
				proccess_active_state_route(tr);
				create_packets_from_queues(tr->proc);
			}
			return NULL;
		}

	}

	//We have sended 3 sia queries and no reply set the flag as it has received the packet
	r->delay = EIGRP_UNREACHABLE;
	r->rijk = 0;

	//Check if all replies were received
	struct topology_route *tr = get_topology_network(r->sender->proc,r->dest,r->prefix);
	if(if_all_replies_received(tr)){
		proccess_active_state_route(tr);
		create_packets_from_queues(tr->proc);
	}

	return NULL;
}

void set_route_to_active(struct topology_route *tr, int flag,route *r){
	tr->route_state = ACTIVE_STATE;
	tr->ioj = flag;
	set_waiting_for_reply(tr,r->sender);

	printf("Route %s/%d went to ACTIVE flag %d\n",ip4_tochar(r->dest),r->prefix,flag);

	if(if_all_replies_received(tr)){
		printf("No neighbours available proccessing route rightaway\n");
		proccess_active_state_route(tr);
		create_packets_from_queues(tr->proc);
		return;
	}

	if(flag == 3 || flag == 1)
		add_query_tlv_multicast(tr->proc,r,0);

	int i;
	for(i=0;i<tr->routes.size;i++){
		route *r = vector_get(&tr->routes,i);
		if(r->is_proccess_generated)continue;
		int ret = pthread_create(&r->active_route_control,NULL ,stuck_in_active ,(void*)r);
		if(ret){
			printf("Error creating active route control thread\n");				
		}
	}

	

	
}

void init_calculate_routes(struct eigrp_proccess *proc){
	struct topology_route *prefix_route;
	struct topology_support* support;
	route *new_successor;	

	//Foreach topology route
	hash_collection col;
	prepare_hashcollection(&col,proc->topology_support);	
	//Network
	while((support=next(&col)) != NULL){
		//Prefix
		hash_collection col2;
		prepare_hashcollection(&col2,support->topology_route);	
		while((prefix_route=next(&col2)) != NULL){
			printf("Route:%s\n",ip4_tochar(prefix_route->dest));
			prefix_route->feasible_distance = get_least_feasible_distance(prefix_route);
			printf("Router feasible distance: %d\n", prefix_route->feasible_distance);
			new_successor = find_new_successor(prefix_route);
			if(new_successor == NULL){
				printf("No successor found, smth went wrong.\n");
			}else{
				set_new_successor(prefix_route,new_successor);
				prefix_route->route_state = PASSIVE_STATE;
			}		
		}
	}
}

bool all_end_of_table_received(struct eigrp_proccess *proc){
	
	neighbour *n = NULL;

	hash_collection col;
	prepare_hashcollection(&col,proc->neighbours);
	while( (n = next(&col)) != NULL){
		if(n->eot == false)return false;
	}

	return true;
}

void reply_received(struct topology_route *tr, neighbour *n){
	int i;
	for(i=0;i<tr->routes.size;i++){
		route *r = vector_get(&tr->routes,i);
		if(r->sender->address == n->address){
			r->rijk = 0;
			return;
		}
	}
}

void reply_received_link_down(struct topology_route *tr, int index){
	int i;
	for(i=0;i<tr->routes.size;i++){
		route *r = vector_get(&tr->routes,i);
		if(r->sender->interface->index == index){
			r->rijk = 0;
		}
	}
}

/*
	This functions adds/changes the routes that we receive from packets. As so we will use it to handle the route
	state.

	Also FSM(x) indicator references the http:/tools.ietf.org/html/draft-savage-eigrp-02 page 13 state transition events
*/

bool handle_route_changes(route *new_route, int opcode, struct eigrp_proccess *proc){
	printf("Handling route %s/%u delay %llu\n",ip4_tochar(new_route->dest),new_route->prefix,new_route->delay);

	bool free_route = false;

	if(!topology_route_exists(proc,new_route->dest,new_route->prefix) && false){
		//This is a new destination
		//TODO: incase delay is unreachable or bandwidth is 0 don't create the route but handle the rest accordingly
		struct topology_route *tr = get_topology_network(proc,new_route->dest,new_route->prefix);
		free_route = add_route_record(tr,new_route,proc);
		printf("New route:%s\n",ip4_tochar(tr->dest));
		tr->feasible_distance = get_least_feasible_distance(tr);
		route *new_successor = find_new_successor(tr);
		if(new_successor == NULL){
			printf("No successor found, smth went wrong.\n");
		}else{
			set_new_successor(tr,new_successor);
			tr->route_state = PASSIVE_STATE;
			add_update_tlv_multicast(tr->proc,tr->successor,0);
		}
	}

	struct topology_route *tr = get_topology_network(proc,new_route->dest,new_route->prefix);

	if(opcode == CONNECTED_ROUTE){
		free_route = add_route_record(tr,new_route,proc);
		tr->feasible_distance = get_least_feasible_distance(tr);
		route *new_successor = find_new_successor(tr);
		if(new_successor == NULL){
			remove_topology_route(tr);
		}else{
			tr->route_state = PASSIVE_STATE;
			tr->ioj = -1;
			set_new_successor(tr, new_successor);
		}
		return free_route;
	}

	if(opcode == OPCODE_QUERY){
		printf("Query Packet\n");
		free_route = add_route_record(tr,new_route,proc);
		printf("Recorded\n");
		if(tr->route_state == PASSIVE_STATE){
			printf("Route is Passive\n");
			//FSM(1)
			//If is not the successor
			if(tr->successor->sender->address != new_route->sender->address){
				//Send the reply
				add_reply_tlv_neighbour(new_route->sender,tr->successor, 0);
				//Run FC to check changes on current successor
				//if(new_route->feasible_distance < tr->feasible_distance)
					//TODO:Think i am missing something here
					//tr->feasible_distance = new_route->feasible_distance;

				return free_route; //Return so that we don't send a reply since it has already been sended
			}else{ //Is the successor
				//FSM(?)
				printf("FSM(?)-QUERY\n");
				if(new_route->delay == EIGRP_UNREACHABLE || new_route->reported_distance > tr->feasible_distance){
					route *successor = find_new_successor(tr);
					if(successor != NULL){
						set_new_successor(tr, successor);
						//New successor send info
						add_update_tlv_multicast(tr->proc,successor,0);			
					}else{
						//FSM(3)
						set_route_to_active(tr,3,new_route);
						return free_route; //Route entered active state return so we that we don't send a reply
					}
				}else{
				//We still have the old successor but the metrics changed so we send the ones
				add_update_tlv_multicast(tr->proc,tr->successor,0);
				}
			}
			//We send a reply since this is a query
			add_reply_tlv_neighbour(new_route->sender,tr->successor,0);
		}else{ //Route is in active state

			if(tr->successor == NULL){
				tr->successor = new_route;
				set_route_to_active(tr,3,new_route);
				return free_route;
			}	

			//Is the successor
			//FSM(5)
			if(tr->successor->sender->address == new_route->sender->address){
				if(tr->ioj == 0 || tr->ioj == 1)
					tr->ioj = 2;
			}else{ //Is not the successor
				//FSM(6)
				add_reply_tlv_neighbour(new_route->sender,new_route,0);
			}

		}
	}

	if(opcode == OPCODE_UPDATE){
		free_route = add_route_record(tr,new_route,proc);
		if(tr->route_state == PASSIVE_STATE){
			//FSM(2)
			printf("FSM(2)-UPDATE\n");
			if(tr->successor->sender->address == new_route->sender->address){
				tr->feasible_distance = get_least_feasible_distance(tr);
				if(new_route->delay == EIGRP_UNREACHABLE || new_route->reported_distance > tr->feasible_distance){
					route *successor = find_new_successor(tr);
					if(successor != NULL){
						set_new_successor(tr, successor);
						//New successor send info
						add_update_tlv_multicast(tr->proc,successor,0);
						return free_route;				
					}else{
						//FSM(4)
						set_route_to_active(tr,1,new_route);
						return free_route;
					}
				}
				//This will refresh the metric on the routing table
				if(tr->old_successor_metric != tr->successor->feasible_distance){
					route *successor = find_new_successor(tr);
					set_new_successor(tr, successor);
					return free_route;
				}
			}
		}else{
			if(tr->successor != NULL && tr->successor->sender->address == new_route->sender->address){
				if(new_route->delay == EIGRP_UNREACHABLE || new_route->bandwidth == 0){
					remove_topology_route(tr);
				}else{
					if(if_all_replies_received(tr))
						proccess_active_state_route(tr);
				}
			}else{
				tr->successor = new_route;
				set_route_to_active(tr,0,new_route);
			}
			//FSM(7)
			//The changes are recorded above no query or update are sended though
		}
	}

	//FSM(8)
	if(opcode == OPCODE_REPLY){
		if(tr->route_state == ACTIVE_STATE){
			reply_received(tr,new_route->sender);
			if(if_all_replies_received(tr)){
				//We have heard from all neightbour, now we can find a new successor
				proccess_active_state_route(tr);
			}
		}
	}

	printf("Creating Packets.\n");
	create_packets_from_queues(proc);

	return free_route;
}

bool proccess_uses_if(struct eigrp_proccess *proc, int if_index){
	int i;
	for(i=0;i<proc->ifs.size;i++){
		interface *iff = vector_get(&proc->ifs,i);
		if(iff->index == if_index) return true;
	}
	return false;
}

bool check_if_interface_exists(int index){
	interface *iff = get_interface(index);
	return (iff == NULL ? false : true);
}

void interface_down(int index){

	int i;
	route *r, *successor;
	interface *iff;
	struct eigrp_proccess *proc;
	struct topology_route *tr, *prefix_route;
	struct topology_support* support;
	neighbour *n;

	printf("IF DOWN method was called\n");
	if(!check_if_interface_exists(index))return;

	iff = get_interface(index);

	if(iff->is_up == false){
		printf("Interface %s id alreay down\n",iff->name);
		return;
	}
	
	iff->is_up = false;
	iff->running = false;
	
	//Foreach Proccess
	hash_collection col;
	prepare_hashcollection(&col,proccesses);
	while( (proc = next(&col)) != NULL ){
		
		//Foreach Advertized Route
		for(i=0;i<proc->connected_routes.size;i++){
			r = vector_get(&proc->connected_routes, i);
			if(r->index == index){
				r->delay = EIGRP_UNREACHABLE;
				//FSM(2)
				tr = get_topology_network(proc,r->dest,r->prefix);
				if(tr->successor != NULL && tr->successor->sender->address == 0){
					successor = find_new_successor(tr);
					if(successor != NULL){
						set_new_successor(tr, successor);
						//New successor send info
						add_update_tlv_multicast(tr->proc,successor,0);			
					}else{
						//FSM(4)
						set_route_to_active(tr,1,tr->successor);
					}
				}
			}
		}
		//Foreach topology route
		hash_collection col1;
		prepare_hashcollection(&col1,proc->topology_support);	
		//Network
		while((support=next(&col1)) != NULL){
			//Prefix

			hash_collection col2;
			prepare_hashcollection(&col2,support->topology_route);

			while((prefix_route=next(&col2)) != NULL){
				if(prefix_route->successor != NULL && prefix_route->successor->sender->interface->index == index){
					if(prefix_route->route_state == ACTIVE_STATE){

						reply_received_link_down(prefix_route,index);

						//FSM(9)
						if(prefix_route->ioj == 1){
							prefix_route->ioj = 0;
						}
						//FSM(10)
						if(prefix_route->ioj == 3){
							prefix_route->ioj = 2;
						}

						if(if_all_replies_received(prefix_route)){
							//We have heard from all neightbour, now we can find a new successor
							proccess_active_state_route(prefix_route);
						}
					}
				}else{
					//FSM(7)
					//Changes are recorded but no update is sent
				}
			}

		}

		//Foreach Neighbour
		hash_collection col3;
		prepare_hashcollection(&col3,proc->neighbours);
		printf("Neighbours:%d\n",proc->neighbours->real_size);
		while( (n=next(&col3)) != NULL ){
			free_neighbour(n);
		}
		create_packets_from_queues(proc);
	}

	//if(iff->ip4_init){
		free(iff->ifa_addr_ip4);
		free(iff->ifa_netmask_ip4);
	//}

	//if(iff->ip6_init){	
		free(iff->ifa_addr_ip6);
		free(iff->ifa_netmask_ip6);
	//}

	
}

void interface_up(int index){
	int i;
	interface *iff;
	struct eigrp_proccess *proc;
	//struct topology_route *tr;
	route *r;

	printf("IF UP method was called.\n");

	if(!check_if_interface_exists(index))return;

	//We will need the iff to pull the delay value
	iff = get_interface(index);

	if(iff->is_up){
		printf("Interface %s already up returning.\n",iff->name);
		return;
	}

	iff->is_up = true;

	re_init_interface(iff);

	//Foreach Proccess
	hash_collection col;
	prepare_hashcollection(&col,proccesses);
	while( (proc = next(&col)) != NULL ){
		//Foreach Advertized Route
		//FSM(2)
		for(i=0;i<proc->connected_routes.size;i++){
			r = vector_get(&proc->connected_routes, i);
			r->delay = iff->delay;
		}
		create_packets_from_queues(proc);
	}

	
	
}

void interface_metric_changed(int if_index,int value_index,int value){
	interface *iff;
	struct eigrp_proccess *proc;
	struct topology_route *prefix_route;//,*tr;
	struct topology_support* support;

	iff = get_interface(if_index);

	switch(value_index){
		case 0:
			iff->mtu = value;
			break;
		case 1:
			iff->bandwidth = value;
			break;
		case 2:
			iff->delay = value;
			break;
		case 3:
			iff->load = value;
			break;
		case 4:
			iff->reliability = value;
			break;
	}
	//Foreach Proccess
	hash_collection col;
	prepare_hashcollection(&col,proccesses);
	while( (proc = next(&col)) != NULL ){
		
		//Foreach topology route
		hash_collection col2;
		prepare_hashcollection(&col2,proc->topology_support);
		//Network
		while((support=next(&col2)) != NULL){
			//Prefix
			hash_collection col3;
			prepare_hashcollection(&col3,support->topology_route);

			while((prefix_route=next(&col3)) != NULL){
				if(prefix_route->successor->sender->interface->index == if_index){
					if(prefix_route->route_state == PASSIVE_STATE){
						calculate_classic_route_metric(proc,prefix_route->successor); //Update entry
						if(prefix_route->successor->reported_distance > prefix_route->feasible_distance){
							route *successor = find_new_successor(prefix_route);
							if(successor != NULL){
								//FSM(2)
								set_new_successor(prefix_route, successor);
								//New successor send info
								add_update_tlv_multicast(prefix_route->proc,successor,0);
								continue;		
							}else{
								//FSM(4)
								set_route_to_active(prefix_route,1,prefix_route->successor);
								continue;
							}
						}
						//FSM(2)
						add_update_tlv_multicast(prefix_route->proc,prefix_route->successor,0);
					}else{

						reply_received_link_down(prefix_route,if_index);						

						//FSM(9)
						if(prefix_route->ioj == 1){
							prefix_route->ioj = 0;
							
						}
						//FSM(10)
						if(prefix_route->ioj == 3){
							prefix_route->ioj = 2;
						}

						if(if_all_replies_received(prefix_route)){
							//We have heard from all neightbour, now we can find a new successor
							proccess_active_state_route(prefix_route);
						}
					}
				}else{
					//FSM(7)
					//Changes are recorded but no update is sent
				}
			}

		}
		create_packets_from_queues(proc);

	}
}

bool add_route_record(struct topology_route* tr, route *new_route,struct eigrp_proccess *proc){

	int i;
	for(i=0;i<tr->routes.size;i++){
		route *record = vector_get(&tr->routes,i);
		if(record->sender->address == new_route->sender->address){
			//I was gonna orgininally replace it, but we are just gonna overwrite the values - simpler

			record->delay = new_route->delay;
			record->bandwidth = new_route->bandwidth;
			record->mtu = new_route->mtu;
			record->hop = new_route->hop;
			record->reliability = new_route->reliability;
			record->load = new_route->load;

			record->reported_distance = new_route->reported_distance;
			//dest,prefix and sender are the same

			calculate_classic_route_metric(proc,record);
			
			return true;
		}
	}
	
	calculate_classic_route_metric(proc,new_route);

	//If the route is unreachable DO NOT add it at the topology metrics
	//if(new_route->delay == EIGRP_UNREACHABLE || new_route->bandwidth == 0){
		//return true;
	//}

	//Add the route to the topology table
	vector_add(&tr->routes, new_route);
	//Add the route to neighbour as a reference
	vector_add(&new_route->sender->routes,new_route);

	return false;
}

void remove_route_record(struct topology_route* tr, route *remove){
	int k;	
	for(k=0;k<tr->routes.size;k++){
		route *record = vector_get(&tr->routes,k);		
		if(record->sender->address == remove->sender->address){
			vector_delete(&tr->routes,k);
			break;
		}
	}
}

void route_recalculate(struct topology_route *tr){
	printf("Found route with changes\n");
	//First check if we have a successor
	if(tr->successor != NULL){
		//if the successor is active we exit, this function is called each time a new route
		//is inserted but that doesn't mean we have to recalculate everything if the successor
		//is working fine
		if(tr->successor->sender->is_active && tr->successor->delay != EIGRP_UNREACHABLE){
			tr->was_changed = false;
			return;
		}
	
	}

	//No successors found for the route, we will have to recalculate new ones	
	tr->feasible_distance = get_least_feasible_distance(tr);

	//Now that we have the least distance pass the records a 2nd time to find the successors
	//We are trying to find the 2 minimum cost paths - Hope the code doesn't look too ugly here
	route *primary_route = NULL;//successor
	int i;
	for(i=0;i<tr->routes.size;i++){
		route *record = vector_get(&tr->routes, i);
		//If the neighbour went inactive for some reason skip him
		if(!record->sender->is_active)
			continue;

		if(record->delay == EIGRP_UNREACHABLE)
			continue;

		//If it's upstream ignore it
		if(record->reported_distance < tr->feasible_distance)
			continue;

		if(primary_route == NULL)
			primary_route = record;
			continue;

		if(primary_route->reported_distance > record->reported_distance){
			primary_route = record;
			continue;
		}
	}

	//At this point we searched all record and we should have our successor and feasible successor
	tr->successor = primary_route;

	//Add the new route to the routing table
	printf("passing new routing information.\n");
	if(tr->successor != NULL){
		printf("Metric %d",tr->successor->feasible_distance);
		route_add((__u32*)&tr->dest,&tr->successor->sender->address,tr->prefix,(__u32*)&tr->successor->feasible_distance);
	}

	tr->route_state = PASSIVE_STATE;
}

void calculate_changes_if_needed(struct eigrp_proccess* proc){
	
	hash_collection col;
	prepare_hashcollection(&col,proc->topology_support);
 
	//We need to check if any of the route had any changes

	
	//Network
	struct topology_support* support;
	while((support=next(&col)) != NULL){
		//Prefix
		struct topology_route *prefix_route;

		hash_collection col2;
		prepare_hashcollection(&col2,support->topology_route);

		while((prefix_route=next(&col2)) != NULL){
			if(prefix_route->route_state == ACTIVE_STATE)
				printf("Changing Route %d\n",prefix_route->dest);
				route_recalculate(prefix_route);
		}

	}
}

void remove_routes_from_neighbour(neighbour *n){
	printf("Removing routes:%d.\n",n->routes.size);
	int i;

	for(i=0;i<n->routes.size;i++){
		route *r = vector_get(&n->routes,i);

		if(r->delay != EIGRP_UNREACHABLE)
			printf("WARNING:Removing a route from neighbour %s to dest %s:%d with a non-unreachable value.\n",ip4_tochar(n->address),ip4_tochar(r->dest),r->prefix);

		struct topology_route *tr = get_topology_network(n->proc,r->dest,r->prefix);
		remove_route_record(tr,r);
	}

	vector_empty(&n->routes);
}

void init_values(struct eigrp_proccess *proc,int i,proccess *proc_info){	

	proc->running = true;

	proc->k1=proc_info->k1;
	proc->k2=proc_info->k2;
	proc->k3=proc_info->k3;
	proc->k4=proc_info->k4;
	proc->k5=proc_info->k5;
	proc->k6=proc_info->k6;

	proc->proccess_id=i;
	proc->router_id=1;
	proc->hello_interval = 5;
	proc->holdtime = proc->hello_interval * 3;

	vector_init(&proc->ifs);
	vector_init(&proc->connected_routes);

	linkedlist_init(&proc->multicast_queue);
	linkedlist_init(&proc->query_tlv_queue);
	linkedlist_init(&proc->update_tlv_queue);

	proc->seq_num = 1;

	proc->neighbours = create_hash_table(DEFAULT_NEIGHBOURS_HASHTABLE_SIZE);
	proc->topology_support = create_hash_table(30);

	int k;
	for(k=0;k<12;k++){
		proc->stats.packets_received[k] = 0;
		proc->stats.packets_sent[k] = 0;
	}
	proc->stats.acks_sent = 0;
	proc->stats.acks_received = 0;

}

void *hello_packet_thread(void *ptr){
	struct eigrp_proccess *proc;
	interface *iff;

	proc = (struct eigrp_proccess *)ptr;

	//Prepare the hello packet once so we don't have to make it over and over
	int i;

	struct sockaddr_in sin;
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = inet_addr("224.0.0.10");

	packetv4_param *packet = create_empty_packet(OPCODE_HELLO, 0, sin);
	create_hello_packet(packet,proc);

	while(proc->running){		
	
		for(i=0;i<proc->ifs.size;i++){
			iff = vector_get(&proc->ifs,i);

			//Record packets sent
			proc->stats.packets_sent[OPCODE_HELLO]++;			

			if(iff->ip4_init && iff->running)
				send_ip4_packet(packet, iff->socket4);
		}
		

		sleep(proc->hello_interval);		
	}
	
	free(packet);

	return NULL;
}

bool vector_contains(vector *v, char *string){
	int i;
	for(i=0;i<v->size;i++){
		if(compare(vector_get(v,i), string))
			return true;
	}
	return false;
}

void send_packets_neighbour(neighbour *n){
	long long current_time;
	long long delay = 1000; //Send or resend packets every 1 second

	current_time = current_timestamp();

	if(current_time - n->last_response > n->holdtime){
		printf("Neighbour is inactive removing him.\n");
		free_neighbour(n);
		return;
	}

	if((!n->send_next_packet) && current_time - n->last_packet_sent < delay){
		return;
	}

	n->send_next_packet = false;

	if(linkedlist_isempty(&n->packet_queue)){
		if(n->last_ack_sent != n->pending_ack && n->pending_ack != -1){
			int length = sizeof(struct eigrphdr);
			packetv4_param *packet = create_empty_packet(OPCODE_HELLO,0, n->sin);


	
			n->last_ack_sent = n->pending_ack;
			create_eigrp_header(packet, length, OPCODE_HELLO, n->proc->proccess_id, 0, n->pending_ack, 0);

			//Record packets sent
			n->proc->stats.packets_sent[packet->opcode]++;
			if(n->pending_ack != 0)n->proc->stats.acks_sent++;

			send_ip4_packet(packet,n->interface->socket4);
			n->last_packet_sent = current_time;

			free(packet);
		}
	}else{
		packetv4_param *packet = linkedlist_peekfirst(&n->packet_queue);
		if(packet->seq_num == 0){
			int seq_num = n->proc->seq_num++; //increase the seq_num by 1
			packet->seq_num = seq_num; //assign the seq to the struct so it be retrived later to check for ack
			
			//create_eigrp_header(packet, packet->buffer_len, packet->opcode, n->proc->proccess_id, packet->seq_num , n->pending_ack, packet->flags);
			//n->last_ack_sent = n->pending_ack;

			//Save the seq num for the neighbour state change				
			if( flags_are_set(packet->flags, FLAG_INIT) ){
				n->init_seq = seq_num;
			}
		}

		int ack = n->pending_ack;
		if(ack == -1) ack = 0; 
		create_eigrp_header(packet, packet->buffer_len, packet->opcode, n->proc->proccess_id, packet->seq_num , ack, packet->flags);
		n->last_ack_sent = n->pending_ack;
		
		//Record packets sent
		n->proc->stats.packets_sent[packet->opcode]++;
		if(n->pending_ack != 0)n->proc->stats.acks_sent++;
		
		send_ip4_packet(packet,n->interface->socket4);
		n->last_packet_sent = current_time;
	}
}

bool packet_queues_empty(struct eigrp_proccess *proc){
	neighbour *n;

	hash_collection col;
	prepare_hashcollection(&col,proc->neighbours);
	while( (n = next(&col)) != NULL){
		if(!linkedlist_isempty(&n->packet_queue)) return false;
	}
	
	return true;
}

void *send_ipv4_packets( void *ptr){
	struct eigrp_proccess *proc;
	neighbour *n;
	//long long current_time;
	struct sockaddr_in sin;
	bool cr = false; //Indicates if cr flag should be set on a multicast packet.
	int flags = 0; //Flag the multicast packet will have
	int seq_len=0; //The actual length we used from the hole buffer

	proc = (struct eigrp_proccess *)ptr;

	while(proc->running){
		sleep_millis(100);

		if(linkedlist_isempty(&proc->multicast_queue)){
			//Send any pending packets from neighbour queue
			hash_collection col;
			prepare_hashcollection(&col,proc->neighbours);
			while( (n = next(&col)) != NULL){
				send_packets_neighbour(n);
			}

		}else{
			printf("Sending multicast Packet.\n");
			//Send the next multicast packet

			int seq_num = proc->seq_num++; // Get the seq number now cause we might need it for the seq_tlv packet

			//If we have pending ack send the sequence tlv 		
			if(!packet_queues_empty(proc)){
				cr = true;
				
				//Build the sequence tlv
				void *seq_tlv=malloc(PACKET_LENGTH); //We will write the tlv in this buffer and then copy it into the packet
				seq_len = fill_sequence_tlv(seq_tlv, proc);
				//Create the packet
				packetv4_param *seq_packet = create_empty_packet(OPCODE_HELLO, 0 , sin);
				addtlv(seq_packet,seq_tlv,seq_len);
				struct tlv_next_multicast next_mul;
				next_mul.type = htons(0x0005);
				next_mul.length = htons(8);
				next_mul.seq_num = htonl(seq_num);
				addtlv(seq_packet,&next_mul,8);
				create_eigrp_header(seq_packet, seq_packet->buffer_len, seq_packet->opcode, proc->proccess_id, 0, 0, 0);
				send_ip4_packet_multicast(seq_packet,proc);
				//Record packets sent
				proc->stats.packets_sent[seq_packet->opcode]++;
				free(seq_tlv);
				free(seq_packet);
	
			}

			packetv4_param *packet = linkedlist_getfirst(&proc->multicast_queue);
			//int length = sizeof(struct eigrphdr);
			//char* buffer = malloc(length);

			if(cr) flags |= FLAG_CR;
			create_eigrp_header(packet, packet->buffer_len, packet->opcode, proc->proccess_id, seq_num, 0, flags);
			queue_sended_multicast_packet(proc, packet);
			send_ip4_packet_multicast(packet,proc);
			//Record packets sent
			proc->stats.packets_sent[packet->opcode]++;
			printf("Done sending multicast packet.\n");
		}
	}

	return NULL;
}

int get_interface_index_ip4(unsigned int address, int prefix){
	
	interface *iff;

	hash_collection col;
	prepare_hashcollection(&col,interfaces);
	while( (iff = next(&col)) != NULL){
		if(iff->ifa_addr_ip4 == NULL)continue;
		//Interface could not get an address
		int if_prefix = subnet_to_prefix(iff->ifa_netmask_ip4->sin_addr.s_addr);
		if(if_prefix < -1) return -1;
		//We can't advertize a network bigger than the interface network
		if(prefix < if_prefix) continue;

		//Remove the host part and compare
		unsigned int network = address << (32-if_prefix);
		unsigned int if_network = iff->ifa_addr_ip4->sin_addr.s_addr << (32-if_prefix);
		if(network == if_network){
			return iff->index;
		}
	}

	return -1;
}

void register_connected_route(struct eigrp_proccess *proc,net_info *adv_net){

	//Interface Index
	int if_index = get_interface_index_ip4(adv_net->network,adv_net->prefix);
	if(if_index == -1){
		printf("Could not find a matching interface for network %s.\n",ip4_tochar(adv_net->network));
		return;
	}
	interface *iff = get_interface(if_index);
	printf("Found a match for %s/%d through %s/%d-%s.\n",ip4_tochar(adv_net->network),adv_net->prefix,ip4_tochar(iff->ifa_addr_ip4->sin_addr.s_addr),subnet_to_prefix(iff->ifa_netmask_ip4->sin_addr.s_addr),iff->name);

	//Create the route struct
	route *connected_route = create_route();
	connected_route->is_proccess_generated = true;
	connected_route->index = if_index;
	connected_route->rijk = 0;
	//---------------------------
	connected_route->sender = iff->self;
	connected_route->prefix = adv_net->prefix;
	connected_route->dest = adv_net->network;
	//Metrics
	connected_route->mtu = iff->mtu;
	connected_route->reliability = iff->reliability;
	connected_route->delay = iff->delay;
	connected_route->bandwidth = iff->bandwidth;
	connected_route->load = iff->load;
	connected_route->hop = 0;
	connected_route->route_tag = 0;
	//---------------------------

	//Add the route to the directly connected_rotues - Is used when interface does up/down
	vector_add(&proc->connected_routes,connected_route);
	calculate_classic_route_metric(proc,connected_route);
	//Add the route struct to the topology_table
	bool free_route = handle_route_changes(connected_route,CONNECTED_ROUTE,proc);
	if(free_route)free(connected_route);
	

}

int init_eigrp_proccess(proccess *proc_info){

	struct eigrp_proccess *proc;
	int i,id = proc_info->id;
	net_info *adv_net;
	interface *iff;

	//Here we will be skipping the get function cause we are initializing
	proc = hashtable_getitem(proccesses,id);
	if(proc != NULL){
		printf("Trying to initialize an already initialized proccess: %d\n",id);
		return -1;
	}

	printf("Initializing Eigrp Proccess %d\n" , id);
	proc = malloc(sizeof(struct eigrp_proccess));

	//Init Basic Values
	init_values(proc, id,proc_info);

	hash_collection col;
	prepare_hashcollection(&col,interfaces);
	while((iff = next(&col)) != NULL){

		if(vector_contains(&proc_info->passive_ifs, iff->name))
			continue;
		else{
			vector_add(&proc->ifs, iff);
		}
	}
	
	for(i=0;i<proc_info->advertised_networks.size;i++){
		adv_net = vector_get(&proc_info->advertised_networks,i);
		register_connected_route(proc,adv_net);
	}

	int ret = pthread_create(&proc->hello_sender,NULL ,hello_packet_thread ,(void*)proc);
	if(ret){
		printf("Error creating hello thread for proccess %d ip4.\n", proc->proccess_id);
		free(proc);
		return -1;
	}

	//This is the thread tasked with sending the packets so they arrive with the correct order(seq,ack)
	//also tasked with looking if the neighbour is still active since it handles the packets recved
	ret = pthread_create(&proc->packet_sender,NULL ,send_ipv4_packets ,(void*)proc);
	if(ret){
		printf("Error creating sender thread for proccess %d ip4.\n", proc->proccess_id);
		free(proc);				
		return -1;
	}

	printf("Eigrp proccess %d working on %d interfaces.\n",proc->proccess_id,proc->ifs.size);

	hashtable_additem(proccesses,proc,id);

	return 0;
}

bool is_initialized_eigrp(int i){
	
	struct eigrp_proccess *proc = hashtable_getitem(proccesses,i);
	if(proc == NULL) return false;
	else return true;
}

void *listen_ip6( void *ptr){

	interface *iff;

	iff = (interface *)ptr;

	char *buffer = malloc(PACKET_LEN);
	int cur_length = 0;
	int pak_length = 0;

	while(iff->running){
		int len;

		len = recv(iff->socket6, (buffer+cur_length), PACKET_LEN, 0);
		cur_length += len;
		if(cur_length >= 6){
			pak_length = (buffer[5] | buffer[4] << 8);
		}else{
			continue;
		}

		//wait for the whole packet to be transmitted
		if(cur_length >= pak_length){
			packet *p = NULL;
			handle_packet_ipv6(p);
			free(p);

			//we have some data from the next packet
			if(cur_length > pak_length){
				memmove(buffer,buffer+pak_length,cur_length-pak_length);
				pak_length = 0;
				cur_length -= pak_length;
				continue;
			}

			pak_length = 0;
			cur_length = 0;
		}

		

	}

	free(buffer);

	return NULL;
}

void *listen_ip4( void *ptr){
	interface *iff;

	iff = (interface *)ptr;

	//Interfaces get initialized first, hold until the proccesses are ready as well
	while(!proccesses_initialized){
		sleep(1);
	}
	

	//Make a string with family name for printing
	char *family_name;
	if(iff->ifa_addr_ip4->sin_family == AF_INET) family_name = "AF_INET";
	printf("Starting packet listener thread %s for interface %s.\n",family_name,iff->name);

	char buffer[PACKET_LEN];
	int cur_length = 0;
	int pak_length = 0;


	while(iff->running){
		int len;

		len = recv(iff->socket4, (buffer+cur_length), PACKET_LEN, MSG_DONTWAIT);

		if(len < 0)
			continue;
		
		cur_length += len;
		if(cur_length > 4){
			pak_length = buffer[3] | buffer[2] << 8;
		}else{
			continue;
		}

		//wait for the whole packet to be transmitted
		if(cur_length >= pak_length){
			packet p;
			fill_packet(&p,buffer,pak_length);
			handle_packet_ipv4(&p,iff);
			//we have some data from the next packet
			if(cur_length > pak_length){
				memmove(buffer,buffer+pak_length,cur_length-pak_length);
				pak_length = 0;
				cur_length -= pak_length;
				continue;
			}

			pak_length = 0;
			cur_length = 0;
		}

		

	}

	//Leave the multicast group
	char host[NI_MAXHOST];
	int result = getnameinfo((struct sockaddr*)iff->ifa_addr_ip4, sizeof(struct sockaddr_in), host, NI_MAXHOST, NULL , 0 , NI_NUMERICHOST);
	if( result != 0){
		printf("ERROR:getnameinfo() failed: %s.\n",gai_strerror(result));
		return false;
	}
	struct ip_mreq group;
	group.imr_multiaddr.s_addr = inet_addr("224.0.0.10");
	group.imr_interface.s_addr = inet_addr(host);
	if(setsockopt(iff->socket4, IPPROTO_IP, IP_DROP_MEMBERSHIP, (char*)&group, sizeof(group)) < 0){
		printf("ERROR:Could not drop multicast group at ip4 for interface %s.\n", iff->name);
	}

	close(iff->socket4);
	printf("Stoped packet listener thread %s for interface %s.\n",family_name,iff->name);
	
	return NULL;
}

int disable_ip4_loopback(int socket){
	char loopch = 0;
	if(setsockopt(socket, IPPROTO_IP, IP_MULTICAST_LOOP, (char *)&loopch, sizeof(loopch)) < 0){
		return -1;
	}
	return 0;
}

int get_socket_mtu(int socket,int family,char *name){
	struct ifreq ifr;
	ifr.ifr_addr.sa_family = family;
	strcpy(ifr.ifr_name,name);
	if(ioctl(socket, SIOCGIFMTU, &ifr) < 0){
		return -1;
	}
	return ifr.ifr_mtu;
}

bool init_ip4(interface *iff){
	char host[NI_MAXHOST];
	int ret;
	iff->socket4 = socket(AF_INET, SOCK_RAW, EIGRP_PROT_NUM);
	if(iff->socket4 == -1){
		printf("ERROR:Could not create socket ip4 for interface %s.\n", iff->name);
		return false;
	}
	printf("Test Family:%d IF:%s\n",iff->ifa_addr_ip4->sin_family,iff->name);
	int result = getnameinfo((struct sockaddr*)iff->ifa_addr_ip4, sizeof(struct sockaddr_in), host, NI_MAXHOST, NULL , 0 , NI_NUMERICHOST);
	if( result != 0){
		printf("ERROR:getnameinfo() failed: %s.\n",gai_strerror(result));
		return false;
	}
	struct ip_mreq group;
	group.imr_multiaddr.s_addr = inet_addr("224.0.0.10");
	group.imr_interface.s_addr = inet_addr(host);
	if(setsockopt(iff->socket4, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char*)&group, sizeof(group)) < 0){
		printf("ERROR:Could not join multicast group at ip4 for interface %s\nErr:%s.\n", iff->name,strerror(errno));
		return false;
	}
	if(setsockopt(iff->socket4, SOL_SOCKET, SO_BINDTODEVICE, iff->name, sizeof(iff->name))){
		printf("ERROR:Could not bind socket to interface %s.\n", iff->name);
		close(iff->socket4);
		return false;
	}
		
	//----
	if(disable_ip4_loopback(iff->socket4) < 0){
		printf("ERROR:Could not set disable loopback to interface %s.\n", iff->name);
		close(iff->socket4);
		return false;
	}
	int mtu = get_socket_mtu(iff->socket4,AF_INET,iff->name);
	if(mtu < 0){
		printf("ERROR:Could not get interface %s MTU.\n", iff->name);
		close(iff->socket4);
		return false;
	}
	iff->mtu = mtu;
	ret = pthread_create(&iff->packet_listener4,NULL ,listen_ip4 ,(void*)iff);
	if(ret){
		printf("ERROR:Error creating listen thread for interface %s at ip4.\n", iff->name);
		close(iff->socket4);
		return false;
	}

	return true;
}

bool init_ip6(interface *iff){
	char host[NI_MAXHOST];
	int ret;
	iff->socket6 = socket(AF_INET6, SOCK_RAW, EIGRP_PROT_NUM);
	if(iff->socket6 == -1){
		printf("ERROR:Could not create socket ip6 for interface %s.\n", iff->name);
		return false;
	}
	printf("Test Family:%d IF:%s\n",iff->ifa_addr_ip6->sin6_family,iff->name);
	int result = getnameinfo((struct sockaddr*)iff->ifa_addr_ip6, sizeof(struct sockaddr_in6), host, NI_MAXHOST, NULL , 0 , NI_NUMERICHOST);
	if( result != 0){
		printf("ERROR:getnameinfo() failed: %s.\n",gai_strerror(result));
		return false;
	}
	struct ipv6_mreq group;
	struct addrinfo *reslocal,*resmulti;//,hints;
	
	getaddrinfo(host, NULL, NULL, &reslocal);
	getaddrinfo("FF02::A",NULL,NULL,&resmulti);
	group.ipv6mr_multiaddr = ((struct sockaddr_in6 *)resmulti->ai_addr)->sin6_addr;
	group.ipv6mr_interface = ((struct sockaddr_in6 *)reslocal->ai_addr)->sin6_scope_id;
	if(setsockopt(iff->socket6, IPPROTO_IPV6, IPV6_ADD_MEMBERSHIP, (char*)&group, sizeof(group)) < 0){
		printf("ERROR:Could not join multicast group at ip6 for interface %s.\n", iff->name);
		return false;
	}
	if(setsockopt(iff->socket6, SOL_SOCKET, SO_BINDTODEVICE, iff->name, sizeof(iff->name))){
		printf("ERROR:Could not bind socket to interface %s.\n", iff->name);
		close(iff->socket6);
		return false;
	}
	int loopch = 0;
	if(setsockopt(iff->socket6, IPPROTO_IPV6, IPV6_MULTICAST_LOOP, &loopch, sizeof(loopch)) < 0){
		printf("ERROR:Could not set disable loopback to interface %s.\n", iff->name);				
		close(iff->socket6);
		return false;
	}
	ret = 0;//pthread_create(&iff->packet_listener6 ,NULL ,listen_ip6 ,(void*)iff);
	if(ret){
		printf("ERROR:Error creating listen thread for interface %s at ip6.\n", iff->name);
		close(iff->socket6);
		return false;
	}

	return true;
}

int re_init_interface(interface *iff){

	sleep(3);
	printf("Setting up interface %s for use.\n",iff->name);

	struct ifaddrs *addrs, *tmp, *next_obj;

	getifaddrs(&addrs);
	next_obj = addrs;

	while(next_obj){
		tmp = next_obj;
		next_obj = next_obj->ifa_next;

		if(!compare(tmp->ifa_name, iff->name)){
			continue;
		}

		int family = tmp->ifa_addr->sa_family;

		//If it is NOT one of the follow families then continue
		if(!(family == AF_INET || family == AF_INET6))
			continue;

		if(family == AF_INET){
			//Address
			struct sockaddr *temp = malloc(sizeof(struct sockaddr));
			memcpy(temp,tmp->ifa_addr,sizeof(struct sockaddr));
			iff->ifa_addr_ip4 = (struct sockaddr_in*)temp;
			
			//Mask
			struct sockaddr *temp1 = malloc(sizeof(struct sockaddr));
			memcpy(temp1,tmp->ifa_netmask,sizeof(struct sockaddr));
			iff->ifa_netmask_ip4 = (struct sockaddr_in*)temp1;
		}else if(family == AF_INET6){
			//Address
			struct sockaddr *temp = malloc(sizeof(struct sockaddr));
			memcpy(temp,tmp->ifa_addr,sizeof(struct sockaddr));
			iff->ifa_addr_ip6 = (struct sockaddr_in6*)temp;
			//Mask
			struct sockaddr *temp1 = malloc(sizeof(struct sockaddr));
			memcpy(temp1,tmp->ifa_netmask,sizeof(struct sockaddr));
			iff->ifa_netmask_ip6 = (struct sockaddr_in6*)temp1;
		}
	}
	
	freeifaddrs(addrs);

	iff->running = true;

	/*
		INIT FOR IP4
	*/

	if(iff->ifa_addr_ip4 != NULL && iff->ifa_addr_ip4->sin_addr.s_addr != 0){

		if(init_ip4(iff)){
			iff->ip4_init = true;
		}
	}

	/*
		INIT FOR IP6
	*/

	if(iff->ifa_addr_ip6 != NULL && iff->ifa_addr_ip6->sin6_addr.s6_addr != 0){

		if(init_ip6(iff)){
			iff->ip6_init = true;
		}
	}

	hash_collection col;
	prepare_hashcollection(&col,proccesses);
	struct eigrp_proccess *proc;
	int i;

	while( (proc=next(&col)) != NULL ){
		proccess *proc_info = get_proccess_info(proc->proccess_id);
		for(i=0;i<proc_info->advertised_networks.size;i++){

			net_info *adv_net = vector_get(&proc_info->advertised_networks,i);

			//Find again an interface capable of routing to the network
			int if_index = get_interface_index_ip4(adv_net->network,adv_net->prefix);
			if(if_index == -1){
				printf("Could not find a matching interface for network %s.\n",ip4_tochar(adv_net->network));
				continue;
			}

			//If the index of that network is interface we are currently re initializing register the routes at eigrp
			if(if_index == iff->index){
				printf("Adding connected route %s/%d.\n",ip4_tochar(adv_net->network),adv_net->prefix);
				adv_net = vector_get(&proc_info->advertised_networks,i);
				register_connected_route(proc,adv_net);
			}
		}
	}

	return 0;
}


int init_interface(iff_info *info){

	struct ifaddrs *addrs, *tmp, *next_obj;	
	//char host[NI_MAXHOST];
	//int ret;

	interface *new_if = malloc(sizeof(interface));
	new_if->name = info->name;
	new_if->index = info->index;
	new_if->ip4_init = false;
	new_if->ip6_init = false;
	new_if->ifa_addr_ip4 = NULL;
	new_if->ifa_addr_ip6 = NULL;
	new_if->ifa_netmask_ip4 = NULL;
	new_if->ifa_netmask_ip6 = NULL;
	new_if->delay = info->delay;
	new_if->bandwidth = info->bandwidth;
	new_if->is_up = true;
	new_if->proccess_encryption =create_hash_table(info->eigrp_encryption->real_size);

	hash_collection col;
	prepare_hashcollection(&col,info->eigrp_encryption);
	
	encrypt_info *encrypt;
	while( (encrypt = next(&col)) != NULL){
		process_keys *proc_keys = malloc(sizeof(process_keys));
		proc_keys->eigrp_id = encrypt->eigrp_id;
		
		key_chain *keychain = hashtable_getitem(global_vars->key_chains,hash(encrypt->keychain_name));
		if(keychain == NULL){
			printf("Key chain %s could not be found\n",encrypt->keychain_name);
			free(proc_keys);
			continue;
		}
		proc_keys->keychain = keychain;

		hashtable_additem(new_if->proccess_encryption,proc_keys,proc_keys->eigrp_id);
	}

	getifaddrs(&addrs);
	next_obj = addrs;

	while(next_obj){
		tmp = next_obj;
		next_obj = next_obj->ifa_next;

		if(!compare(tmp->ifa_name, new_if->name)){
			continue;
		}

		int family = tmp->ifa_addr->sa_family;

		//If it is NOT one of the follow families then continue
		if(!(family == AF_INET || family == AF_INET6))
			continue;

		if(family == AF_INET){
			//Address
			struct sockaddr *temp = malloc(sizeof(struct sockaddr));
			memcpy(temp,tmp->ifa_addr,sizeof(struct sockaddr));
			new_if->ifa_addr_ip4 = (struct sockaddr_in*)temp;
			
			//Mask
			struct sockaddr *temp1 = malloc(sizeof(struct sockaddr));
			memcpy(temp1,tmp->ifa_netmask,sizeof(struct sockaddr));
			new_if->ifa_netmask_ip4 = (struct sockaddr_in*)temp1;
		}else if(family == AF_INET6){
			//Address
			struct sockaddr *temp = malloc(sizeof(struct sockaddr));
			memcpy(temp,tmp->ifa_addr,sizeof(struct sockaddr));
			new_if->ifa_addr_ip6 = (struct sockaddr_in6*)temp;
			//Mask
			struct sockaddr *temp1 = malloc(sizeof(struct sockaddr));
			memcpy(temp1,tmp->ifa_netmask,sizeof(struct sockaddr));
			new_if->ifa_netmask_ip6 = (struct sockaddr_in6*)temp1;
		}
	}
	
	freeifaddrs(addrs);

	new_if->running = true;
	new_if->reliability = 255;
	new_if->load = 1;

	bool ip4error __attribute__((unused))= false;
	bool ip6error __attribute__((unused))= false;

	/*
		INIT FOR IP4
	*/

	if(new_if->ifa_addr_ip4 != NULL && new_if->ifa_addr_ip4->sin_addr.s_addr != 0){

		if(init_ip4(new_if)){
			new_if->ip4_init = true;
		}
	}

	/*
		INIT FOR IP6
	*/

	if(new_if->ifa_addr_ip6 != NULL && new_if->ifa_addr_ip6->sin6_addr.s6_addr != 0){

		if(init_ip6(new_if)){
			new_if->ip6_init = true;
		}
	}

	//Make Self Neighbour - used ONLY for directly connected routes to pull info
	struct neighbour_ *n = malloc(sizeof(struct neighbour_));
	n->address = 0;
	n->interface = new_if;
	n->proc = NULL;
	n->eot = true;
	vector_init(&n->routes);

	new_if->self = n;

	printf("Interface %s index:%d is ready for use.\n",new_if->name,new_if->index);
	hashtable_additem(interfaces,new_if,new_if->index);

	return 0;
}

int init_keychain(keychain_info *info){

	key_chain *new_keychain = malloc(sizeof(key_chain));
	new_keychain->name = info->name;
	int hash_size = info->keys->real_size;
	if(hash_size<10)hash_size = 10;
	new_keychain->keys = create_hash_table(hash_size);

	hash_collection col;
	prepare_hashcollection(&col,info->keys);
	key_info *k;

	while( (k = next(&col)) != NULL){
		key *new_key = malloc(sizeof(key));
		new_key->indentifier = k->indentifier;
		new_key->password = k->password;
		hashtable_additem(new_keychain->keys,new_key,new_key->indentifier);

		free(k);
	}

	hashtable_additem(global_vars->key_chains,new_keychain,hash(new_keychain->name));
	return 0;
}

void *if_change( void *ptr){
	look_interface_changes();
	return NULL;
}

// FREE/FINALIZE STUFF

void start_interface_state_listener(){
	int ret = pthread_create(&interface_state_listener ,NULL ,if_change , NULL);
	if(ret){
		printf("Error creating interface state listener.\n");
		return;
	}
}

void free_neighbour(neighbour *n){
	printf("Starting Freeing.\n");
	n->is_active = false;
	recalculate_routes(n);
	remove_routes_from_neighbour(n);
	vector_free(&n->routes);
	hashtable_removeitem(n->proc->neighbours,n->address);
	packetv4_param *packet;
	while(	(packet=linkedlist_getfirst(&n->packet_queue)) != NULL )
		free(packet);
	linkedlist_free(&n->packet_queue);
	linkedlist_free(&n->update_tlv_queue);
	linkedlist_free(&n->query_tlv_queue);
	linkedlist_free(&n->reply_tlv_queue);
	free(n);
	printf("Freeing Done.\n");
}

void shutdown_proccess(int i){
	printf("Shutting Down Eigrp Proccess %d.\n",i);
	struct eigrp_proccess *proc;

	proc = get_eigrp_proccess(i);	

	proc->running = false;

	hash_collection col;
	prepare_hashcollection(&col,proc->neighbours);
	neighbour *n;
	while( (n=next(&col)) != NULL){
		free_neighbour(n);
	}
	hashtable_free(proc->neighbours);

	linkedlist_free(&proc->multicast_queue);
	linkedlist_free(&proc->query_tlv_queue);
	linkedlist_free(&proc->update_tlv_queue);
	printf("Shutting Down Eigrp Proccess Done.\n");
}

void shutdown_eigrp(){
	printf("Shutting Down Eigrp.\n");
	stop_telnet();

	hash_collection col;
	prepare_hashcollection(&col,proccesses);
	
	struct eigrp_proccess* proc;
	while((proc=next(&col)) != NULL){
		shutdown_proccess(proc->proccess_id);
		vector_free(&proc->ifs);
		free(proc);
	}

	free_lists();

	printf("Shutting Down Eigrp Done.\n");
}

void free_array(){
	hashtable_free(proccesses);
}

