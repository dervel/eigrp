/*

	eigrp - A routing daemon for the eigrp protocol
	Copyright (C) 2015 Paraskeuas Karahatzis

	This program is free software: you can redistribute it and/or modify it under the terms of the
	GNU General Public License as published by the Free Software Foundation, either version 3 of the
	License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
	even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
	General Public License for more details.

	You should have received a copy of the GNU General Public License along with this program. If not,
	see <http://www.gnu.org/licenses/>. 

	dervelakos.madlax@gmail.com

*/

#define _GNU_SOURCE
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <ifaddrs.h>
#include <net/if.h>
#include <netdb.h>
#include <limits.h>
#include <arpa/inet.h>

#include "eigrp_structs.h"
#include "eigrp_command_parser.h"
#include "eigrp_base.h"
#include "utils.h"
#include "hashtable.h"
#include "vector.h"
#include "collection.h"

//static int active_proccess_id = -1; //A negative value means no eigrp proccess is selected for configuration
//static int active_interface_index = -1; //A negative value mean no interface is selected for configuration

static int proccesses_ip4=0,proccesses_ip6=0,maxid_ip4=0,maxid_ip6=0;

static keychain_info *active_chain= NULL; //snowflake, this goes down 2 nodes so we would lose the previous id to keep the keys id

static hash_table_t *proccess_list_ip4;
static hash_table_t *proccess_list_ip6;
static hash_table_t *interface_list;
static hash_table_t *keychain_list;

static command_node active_node = NONE;
static int node_id=0;

proccess *get_proccess_info(int id, int family){
	if(family == AF_INET)
		return hashtable_getitem(proccess_list_ip4,id);
	else if(family == AF_INET6)
		return hashtable_getitem(proccess_list_ip6,id);
	else
		return NULL;
}

iff_info *get_interface_info(int index){
	return hashtable_getitem(interface_list,index);
}

int change_active_interface(char *line_token){
	char *token;
	token = strsep(&line_token," ");
	if(token == NULL){
		printf("Could not find inteface name.\n");
		return -1;
	}
	
	char *name = token;
	int index = if_nametoindex(name);
	if(index == 0){
			printf("Error getting the index of the interface %s.\n",name);
			return -1;
	}

	iff_info *info = hashtable_getitem(interface_list, index);
	if(info == NULL){
		iff_info *new_iff = malloc(sizeof(iff_info));

		new_iff->index = index;
		new_iff->name = name;
		new_iff->delay = 100000;
		new_iff->bandwidth = 100000;
		new_iff->eigrp_encryption = create_hash_table(10);

		hashtable_additem(interface_list,new_iff,index);
		info = new_iff;
		printf("Interface %s registered for initialization.\n",name);
	}

	active_node = INTERFACE;
	node_id = index;

	return 0;
}

void change_active_proccess(char *line_token, int family){
	char *token;

	//Token will now have the number of the eigrp proccess
	token = strsep(&line_token," ");
	if(token == NULL){
		printf("Could not find eigrp id.\n");
		return;
	}
	char *p = NULL;
	long val = strtol(token,&p,10); //ret is the eigrp id
	if(*p){
		printf("Could not convert id to number.\n");
		return;
	}


	proccess *proc = get_proccess_info(val,family);
	if(proc == NULL){

		proccess *new_proc = malloc(sizeof(proccess));
		new_proc->id = val;
		new_proc->k1 = 1;
		new_proc->k2 = 0;
		new_proc->k3 = 1;
		new_proc->k4 = 0;
		new_proc->k5 = 0;
		new_proc->k6 = 0;

		new_proc->redistribute_static = false;
		new_proc->variance = 1;
		new_proc->lb_enabled = false;
		new_proc->lb_min = true;

		vector_init(&new_proc->passive_ifs);
		vector_init(&new_proc->advertised_networks);

		if(family == AF_INET){
			hashtable_additem(proccess_list_ip4,new_proc,val);
			printf("Eigrp proccess %lu ip4 registered.\n",val);
			if(val > 0) proccesses_ip4++;
			if(val > maxid_ip4) maxid_ip4 = val;
		}else{
			hashtable_additem(proccess_list_ip4,new_proc,val);
			printf("Eigrp proccess %lu ip6 registered.\n",val);
			if(val > 0) proccesses_ip6++;
			if(val > maxid_ip6) maxid_ip6 = val;
		}
	}

	active_node = (family == AF_INET ? ROUTER : IPV6);
	node_id = val;
	
	return;
}

//The command to parse the work of the line cuts it from the string so we have to pass the initial command
//or we will be missing the first word from the line
int parse_proccess_commands(char *current, char *line_token){
	char *token;
	int ret;

	proccess *proc = get_proccess_info(node_id, AF_INET);	
	if(proc == NULL){
		printf("Somehow you tryed to set options for a NULL proccess.\n");
		return -1;
	}

	if(compare(current,"network")){
		net_info *adv_net = malloc(sizeof(net_info));
		adv_net->external = false;
		//Network Address
		token = strsep(&line_token," ");
		//char *temp = token;
		adv_net->family = AF_INET;
		struct sockaddr_in address;
		address.sin_family = AF_INET;
		int result = inet_pton(AF_INET, token, &address.sin_addr);
		memcpy(&adv_net->network,&address,sizeof(struct sockaddr_in));
		//adv_net->network = address;
		if(result != 1){
			printf("Invalid network address %s.\n", token);
			free(adv_net);
			return -1;
		}
		//Mask
		token = strsep(&line_token," ");
		adv_net->prefix = wildcard_to_prefix(token);
		if(adv_net->prefix == -1){
			printf("Invalid subnet mask or wildcard %s.\n",token);
			free(adv_net);
			return -1;
		}
		vector_add(&proc->advertised_networks,adv_net);
	}

	if(compare(current,"redistribute")){
		token = strsep(&line_token," ");
		if(compare(token,"static")){
			proc->redistribute_static = true;
		}
	}

	if(compare(current,"passive-interface")){
		token = strsep(&line_token," ");
		if(token != NULL){
			vector_add(&proc->passive_ifs,token);
		}

	}

	if(compare(current,"traffic-share")){
		token = strsep(&line_token," ");
		if(compare(token,"balanced")){
			proc->lb_enabled = true;
		}
		
		token = strsep(&line_token," ");
		if(compare(token,"min")){
			token = strsep(&line_token," ");
			if(compare(token,"across-interfaces")){
				proc->lb_min = true;
				proc->lb_enabled = true;

			}
		}

	}

	if(compare(current,"variance")){
		token = strsep(&line_token," ");
		char *p = NULL;
		long val = strtol(token,&p,10); //ret is the eigrp id
		if(*p){
			printf("Could not convert variance number.\n");
			return -1;
		}else{
			if(val< 1){
				printf("Can't use a negative variance number. Using:1\n");
				proc->variance = 1;
			}else if(val >128){
				printf("Can't use a value bigger than 128. Using:128\n");
				proc->variance = 128;
			}else{
				proc->variance = val;
			}
		}
	}

	if(compare(current,"metric")){
		token = strsep(&line_token," ");
		if(token != NULL && compare(current,"weights")){
			
			token = strsep(&line_token," ");
			ret = strtol(token,0,10); // tos
			if(ret != 0) return -1;
			token = strsep(&line_token," ");
			proc->k1 = strtol(token,0,10); // k1
			token = strsep(&line_token," ");
			proc->k2 = strtol(token,0,10); // k2
			token = strsep(&line_token," ");
			proc->k3 = strtol(token,0,10); // k3
			token = strsep(&line_token," ");
			proc->k4 = strtol(token,0,10); // k4
			token = strsep(&line_token," ");
			proc->k5 = strtol(token,0,10); // k5
			token = strsep(&line_token," ");
			proc->k6 = strtol(token,0,10); // k6
			
		}
	}

	return 0;
}

//The command to parse the work of the line cuts it from the string so we have to pass the initial command
//or we will be missing the first word from the line
int parse_interface_commands(char *current, char *line_token){

	iff_info *iff = hashtable_getitem(interface_list,node_id);
	if(iff == NULL){
		printf("Somehow you tryed to set options for a NULL interface.\n");
		return -1;
	}

	char *token = strsep(&line_token," ");;
	int ret;

	if(compare(current,"bandwidth")){
		ret = strtol(token,0,10);
		iff->bandwidth = ret;
	}
	if(compare(current,"delay")){
		ret = strtol(token,0,10);
		iff->delay = ret;
	}
	if(compare(current,"ip")){
		if(equals(token,"authentication")){
			token = strsep(&line_token," ");
			if(equals(token,"mode")){
				token = strsep(&line_token," ");
				if(equals(token,"eigrp")){
					token = strsep(&line_token," ");
					int eigrp_id = strtol(token,0,10);
					token = strsep(&line_token," ");
					if(equals(token,"md5")){
						encrypt_info *encrypt = hashtable_getitem(iff->eigrp_encryption,eigrp_id);
						if(encrypt == NULL){
							encrypt = malloc(sizeof(encrypt_info));
							encrypt->keychain_name = "";
							hashtable_additem(iff->eigrp_encryption,encrypt,eigrp_id);
						}
						encrypt->eigrp_id = eigrp_id;
						encrypt->encryption = "md5";
					}
				}
			}
			if(equals(token,"key-chain")){
				token = strsep(&line_token," ");
				if(equals(token,"eigrp")){
					token = strsep(&line_token," ");
					int eigrp_id = strtol(token,0,10);
					token = strsep(&line_token," ");
					char *keychain_name = token;

					encrypt_info *encrypt = hashtable_getitem(iff->eigrp_encryption,eigrp_id);
					if(encrypt == NULL){
						encrypt = malloc(sizeof(encrypt_info));
						encrypt->encryption = "";
						hashtable_additem(iff->eigrp_encryption,encrypt,eigrp_id);
					}
					encrypt->eigrp_id = eigrp_id;
					encrypt->keychain_name = keychain_name;
				}
			}
		}
	}

	return 0;
	
}

int parse_key_commands(char *current, char *line_token){
	char *token;

	key_info *active_key = hashtable_getitem(active_chain->keys,node_id);

	if(compare(current,"key-string")){
		token = strsep(&line_token," ");
		char * p = NULL;
		long val = strtol(token,&p,10);
		char *password = strsep(&line_token," ");
		if(*p){
			active_key->password = token;
			active_key->encryption = 0;
		}else{
			if(val == 0){
				token = strsep(&line_token," ");
				active_key->password = password;
				active_key->encryption = 0;
			}
			if(val == 7){
				//TODO: this needs fixing
				//active_key->encryption = 7;
				printf("Not implemented.\n");
				return -1;
			}
		}
	}

	return 0;
}

int parse_chain_commands(char *current, char *line_token){
	char *token;	

	if(active_chain == NULL){
		printf("Somehow you tryed to set options for a NULL key chain.\n");
		return -1;
	}

	if(equals(current,"key")){
		token = strsep(&line_token," ");
		char *p = NULL;
		long val = strtol(token,&p,10);
		if(*p){
			printf("Could not reach key chain id\n");
			return -1;
		}

		//If the key doesn't exits crate it and register it
		key_info *k = hashtable_getitem(active_chain->keys, val);
		if(k == NULL){
			key_info *new_key = malloc(sizeof(key_info));
			new_key->indentifier = val;
			new_key->encryption = 0;

			hashtable_additem(active_chain->keys,new_key,new_key->indentifier);
			k = new_key;
		}
		
		node_id = val;
	}else{
		parse_key_commands(current,line_token);
	}

	return 0;
}

int parse_ipv6_commands(char *current, char *line_token){
	char *token;
	if(compare(current, "router-id")){
		token = strsep(&line_token," ");
		unsigned long id = ip4_toint(token);
		if(token == NULL || id == 0){
			printf("WARN: Error parsing router id for ipv6 command\n");
			return -1;
		}
		proccess *proc = get_proccess_info(id,AF_INET6);
		proc->router_id = id;
	}
	if(compare(current,"no")){
		token = strsep(&line_token," ");
		if(compare(token,"shutdown")){
			printf("INFO:This command has no use here\n");
			return 0;
		}
	}
	return 0;
}

int parse_commands(char *buff, int len){

	char *line_token = NULL, *token;
	char *p = NULL;
	long val=0;
	//long id,ret;

	proccess_list_ip4 = create_hash_table(30);
	proccess_list_ip6 = create_hash_table(30);
	interface_list = create_hash_table(30);
	keychain_list = create_hash_table(10);

	init_interfaces_hashtable();

	/*
	First we unscramble/order/unite the commands

	Root commands are router,interface and node refers to the commands that are used inside those,
	while 'exit' is not a root command it can be treated so because it does the same thing in all nodes

	*/
	printf("--Parsing Configuration File--\n");
	while((line_token = strsep(&buff,"\n")) != NULL){
		printf("+%s\n", line_token);

		if(strlen(line_token) == 0)
			continue;

		token = strsep(&line_token," "); // First word of the command
		if(token != NULL){

			if(equals(token, "exit")){
				if(active_node == KEY){
					active_node = KEYCHAIN;
				}else{
					active_node = NONE;
				}
			}

			if(equals(token, "end")){
				printf("This command has no effect here. Parsing configuration file continues\n");
				continue;
			}
			if(compare(token,"router")){
				token = strsep(&line_token," ");
				if(compare("eigrp",token))
					change_active_proccess(line_token,AF_INET);
				continue;
			}
			if(compare(token,"interface")){
				change_active_interface(line_token);
				continue;
			}

			if(equals(token, "key")){
				token = strsep(&line_token," ");
				if(equals(token, "chain")){
					token = strsep(&line_token," ");
					keychain_info *chain = hashtable_getitem(keychain_list,hash(token));
					if(chain == NULL){
						keychain_info *new_chain = malloc(sizeof(keychain_info));
						new_chain->keys = create_hash_table(100);
						new_chain->name = token;
						hashtable_additem(keychain_list,new_chain,hash(token));
						chain = new_chain;
					}
					active_node = KEYCHAIN;
					active_chain = chain;
				}else{
					long val = strtol(token,&p,10);
					if(*p){
							printf("Could not reach key id\n");
							continue;
					}else{
						key_info *key = hashtable_getitem(active_chain->keys,val);
						if(key == NULL){
							key_info *new_key = malloc(sizeof(key_info));
							new_key->indentifier = val;
							hashtable_additem(active_chain->keys,new_key,val);
							key = new_key;
						}

						active_node = KEY;
						node_id = val;
					}
				}
				continue;
			}

			if(equals(token,"ipv6")){
				token = strsep(&line_token," ");
				if(equals(token,"router")){
					token = strsep(&line_token," ");
					if(compare(token,"eigrp")){
						change_active_proccess(line_token,AF_INET6);
					}
				}else if(equals(token,"route") && active_node == NONE){
					token = strsep(&line_token," ");
					if(token == NULL){
						printf("Cannot find network and prefix part at command:ipv6 route\n");
						continue;
					}else{
						char *network = strsep(&token,"/");
						char *prefix = strsep(&token," ");
						val = strtol(prefix,&p,10);
						if(*p || network == NULL){
							printf("Wrong syntax at ipv6\n");
							continue;
						}else{
							char *forward = strsep(&line_token," ");
							struct sockaddr_in6 network_addr;
							network_addr.sin6_family = AF_INET6;
							int result = inet_pton(AF_INET6,network,&network_addr.sin6_addr);
							
							if(token != NULL && result == 1){
								net_info *adv_net = malloc(sizeof(net_info));
								adv_net->external = true;
								memcpy(&adv_net->network,&network_addr,sizeof(struct sockaddr_in6));
								adv_net->prefix = val;
								adv_net->forward = forward;
								
								vector_add(&get_global_vars()->static_routes_ip6,adv_net);
							}
						}
					}
					continue;
				}
			}

			switch(active_node){
				case NONE:
					if(compare(token,"hostname")){
						char *name = strsep(&line_token," ");
						if(name != NULL) get_global_vars()->hostname = name;
							continue;
					}
					if(compare(token, "ip")){
						token = strsep(&line_token," ");
						if(equals(token, "route")){
							char *network = strsep(&line_token," ");
							char *mask = strsep(&line_token," ");
							char *forward = strsep(&line_token," ");

							if(network == NULL || mask == NULL || forward == NULL)
								continue;

							struct sockaddr_in address;
							address.sin_family = AF_INET;
							int result = inet_pton(AF_INET, network, &address.sin_addr);
							if(result != 1){
								printf("Invalid network address %s.\n", token);
								continue;
							}
							
							int network_prefix = wildcard_to_prefix(mask);
					
							net_info *adv_net = malloc(sizeof(net_info));
							adv_net->external = true;
							memcpy(&adv_net->network,&address,sizeof(struct sockaddr_in));
							adv_net->prefix = network_prefix;
							adv_net->forward = forward;

							token = strsep(&line_token," ");
							if(compare(token, "tag")){
								char *tag = strsep(&line_token," ");
								val = strtol(tag,&p,10);
								if(*p){
									adv_net->tag = 0;
								}else{
									adv_net->tag = val;
								}
						
							}

							vector_add(&get_global_vars()->static_routes_ip4,adv_net);
						}
						continue;
					}
					break;
				case INTERFACE:
					parse_interface_commands(token,line_token);
				break;
				case ROUTER:
					parse_proccess_commands(token,line_token);
					break;
				case KEYCHAIN:
					parse_chain_commands(token,line_token);
					break;
				case KEY:
					//Commands for this are parsed thorough the parse_chain_command()
				break;
				case IPV6:
					parse_ipv6_commands(token,line_token);
				break;
			}
			continue;

		}

	}


	printf("--Initializing Key Chains--\n");
	hash_collection col;
	prepare_hashcollection(&col,keychain_list);
	keychain_info *chain_info;
	while( (chain_info = next(&col)) != NULL){
		init_keychain(chain_info);
		hashtable_free(chain_info->keys);
		free(chain_info);
	}
	hashtable_free(keychain_list);

	printf("--Initializing Interfaces--\n");
	hash_collection col2;
	prepare_hashcollection(&col2,interface_list);
	iff_info *if_info;
	while( (if_info = next(&col2)) != NULL){
		init_interface(if_info);
	}

	//Initialize eigrp proccesses
	printf("--Initializing Proccesses--\n");
	//Create an optimal hashtable for eigrp usage
	if(proccesses_ip4 < 50)
		proccesses_ip4 = 50;
	else if(proccesses_ip4 / maxid_ip4 > 0.75)
		proccesses_ip4 = maxid_ip4;

	if(proccesses_ip6 < 50)
		proccesses_ip6 = 50;
	else if(proccesses_ip6 / maxid_ip6 > 0.75)
		proccesses_ip6 = maxid_ip6;

	init_proccess_hashtable(proccesses_ip4,proccesses_ip6);

	hash_collection col3;
	proccess *proc;

	prepare_hashcollection(&col3,proccess_list_ip4);	
	while((proc=next(&col3))!= NULL){
		init_eigrp_proccess(proc,AF_INET);
	}

	prepare_hashcollection(&col3,proccess_list_ip6);	
	while((proc=next(&col3))!= NULL){
		init_eigrp_proccess(proc,AF_INET6);
	}

	return 0;
}
void free_proccess_info(hash_table_t *proccess_list){
	hash_collection col;
	prepare_hashcollection(&col,proccess_list);
	proccess *proc;
	while( (proc=next(&col))!= NULL ){
		int i;
		for(i=0;i<proc->advertised_networks.size;i++){
			net_info *adv_net = vector_get(&proc->advertised_networks,i);
			free(adv_net);
		}
		vector_free(&proc->advertised_networks);
		vector_free(&proc->passive_ifs);
		free(proc);
	}
	hashtable_free(proccess_list);	
}

void free_interface_info(hash_table_t *interface_list){
	hash_collection col;
	prepare_hashcollection(&col,interface_list);
	iff_info *iff;
	while( (iff=next(&col))!= NULL ){
		hash_collection col1;
		prepare_hashcollection(&col1,iff->eigrp_encryption);
		encrypt_info *keys;
		while( (keys=next(&col1))!= NULL ){
			free(keys);
		}
		hashtable_free(iff->eigrp_encryption);
		free(iff);
	}
	hashtable_free(interface_list);
}

/*void free_key_info(hash_table_t *keychain_list){
	hash_collection col,col1;
	prepare_hashcollection(&col,keychain_list);
	keychain_info *keychain;
	while ( (keychain=next(&col)) != NULL){
		prepare_hashcollection(&col1,keychain->keys);
		key_info *key;
		while ( (key=next(&col1)) != NULL){
			//free(key->password);
			free(key);
		}
		hashtable_free(keychain->keys);
		//free(keychain->name);
		free(keychain);
	}

	hashtable_free(keychain_list);
}*/

void free_lists(){
	free_proccess_info(proccess_list_ip4);
	free_proccess_info(proccess_list_ip6);
	free_interface_info(interface_list);
}
