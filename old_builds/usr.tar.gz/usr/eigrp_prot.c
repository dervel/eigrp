#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <string.h>
#include <arpa/inet.h>

#include "eigrp_prot.h"
#include "linkedlist.h"
#include "eigrp_structs.h"
#include "eigrp_base.h"
#include "packet_factory.h"
#include "vector.h"
#include "utils.h"
#include "config.h"

bool flags_are_set(int flag_field, int flag){
	int val = flag_field & flag;
	if(val = 0) return false;
	else return true;
}

packet *create_packet(char *buffer, int length){

	packet *p = malloc(sizeof(packet));
	p->data = buffer;
	p->length = length;
	return p;
}

tlv_ip4_internal *create_interal_route_tlv(struct route *r, int flags){

	int byte_len = ((r->prefix -1)/8)+1;
	tlv_ip4_internal *tlv = malloc(sizeof(tlv_ip4_internal));
	memset(tlv,0,sizeof(tlv_ip4_internal));
	tlv->type = htons(0x0102);
	tlv->length = htons(25 + byte_len);
	tlv->nexthop = htonl(0x00000000);
	tlv->scaled_delay = htonl(r->delay);
	tlv->scaled_bw = htonl(r->bandwidth);

	tlv->mtu_3 = r->sender->interface->mtu & 0xFF;
	tlv->mtu_2 = (r->sender->interface->mtu >> 8) & 0xFF;
	tlv->mtu_1 = (r->sender->interface->mtu >> 16) & 0xFF;

	tlv->hop_count = r->hop;
	tlv->reliability = r->reliability;
	tlv->load = r->load;
	tlv->route_tag = r->route_tag;
	tlv->flags = flags;
	tlv->prefix = r->prefix;
	if(byte_len>=1)tlv->pnt_var_addr1= (r->dest >>24) & 0xFF;
	if(byte_len>=2)tlv->pnt_var_addr2= (r->dest >>16) & 0xFF;
	if(byte_len>=3)tlv->pnt_var_addr3= (r->dest >>8) & 0xFF;
	if(byte_len>=4)tlv->pnt_var_addr4= r->dest & 0xFF;
	
}

void queue_reply_packet(neighbour *n,int flags,struct route *r){
	tlv_ip4_internal *test_tlv = create_interal_route_tlv(r,0);
			
	packetv4_param *packet = create_empty_packet(OPCODE_REPLY,flags,n->sin);
	int byte_len = ((r->prefix -1)/8)+1;
	//tlv assumes destination is 4 byte so we subtract it and add the correct
	addtlv(packet, test_tlv,sizeof(tlv_ip4_internal)-4+byte_len-3); //-3 is struct?

	//Add it to the list so it get send orderly
	linkedlist_addtail(&n->packet_queue,packet);
}

void send_ip4_packet(packetv4_param *param, int socket){
	
	if(sendto(socket, param->buffer, param->buffer_len, 0,(struct sockaddr*)&param->sin, sizeof(param->sin)) < 0){
		printf("Error Sending Packet\n");
	}
}

void *send_ipv4_packets( void *ptr){
	struct eigrp_proccess *proc;
	neighbour *n;

	n = (neighbour *)ptr;
	proc = n->proc;

	long long delay = 1000;

	int last_ack_sent=0;
	long long last_packet_sent = current_timestamp();

	while(n->is_active){
		sleep_millis(100);

		long long current_time = current_timestamp();
		if(current_time - n->last_response > n->holdtime){
			printf("Neighbour is inactive removing him.\n");
			free_neighbour(n);
		}

		if(!(n->send_next_packet || current_time - last_packet_sent < delay)){
			continue;
		}

		n->send_next_packet = false;

		
		if(linkedlist_isempty(&n->packet_queue)){
			if(last_ack_sent != n->pending_ack){
				int length = sizeof(struct eigrphdr);
				char* buffer = malloc(length);
				last_ack_sent = n->pending_ack;
				create_eigrp_header(buffer, length, OPCODE_HELLO, proc->proccess_id, 0, n->pending_ack, 0);

				packetv4_param *packet = malloc(sizeof(packetv4_param));
				packet->buffer = buffer;
				packet->buffer_len = length;
				packet->sin = n->sin;

				send_ip4_packet(packet,n->interface->socket);
				last_packet_sent = current_time;
			}
		}else{

			packetv4_param *packet = linkedlist_peekfirst(&n->packet_queue);
			if(packet->seq_num == 0){
				int seq_num = n->seq_num++; //increase the seq_num by 1
				packet->seq_num = seq_num; //assign the seq to the struct so it be retrived later to check for ack
				
				//Save the seq num for the neighbour state change				
				if( flags_are_set(packet->flags, FLAG_INIT) ){
					n->init_seq = seq_num;
				}
			}
			create_eigrp_header(packet->buffer, packet->buffer_len, packet->opcode, proc->proccess_id, packet->seq_num , n->pending_ack, packet->flags);
			last_ack_sent = n->pending_ack;
			send_ip4_packet(packet,n->interface->socket);
			last_packet_sent = current_time;
		}
	}
	
}


void eigrp_hello(packet *p,struct interface_listener *listener,struct eigrp_proccess *proc,vector *tlvs){
	struct iphdr *ip;
	ip = (struct iphdr*)p->data;

	struct eigrphdr *eigrp;
	eigrp = (struct eigrphdr*)(p->data + ip->ihl*4);


	neighbour *n;
	n = hashtable_getitem(proc->neighbours,ip->saddr);
	if(n == NULL){
		printf("New neighbour canditate\n");
		
		struct tlv_parameter_type *param = NULL;
		struct tlv_version_type *version = NULL;
		
		//first extract the tlv_param
		int i;		
		for(i=0;i<tlvs->size;i++){
			char *index = vector_get(tlvs,i);
			int type = index[1] | index[0] << 8;
			printf("Type:%d\n", type);
			if(type == 0x0001)
				param = (struct tlv_parameter_type *)index;
			if(type == 0x0004)
				version = (struct tlv_version_type *)index;
		}

		
		if(param == NULL){
			printf("Missing parameter tlv ignoring hello packet.\n");
			return;
		}
		
		if(version == NULL){
			printf("Missing version tlv ignoring hello packet.\n");
			return;
		}
		
		//Let's make a big if to check the tlv_parameters
		if(proc->k1 == param->k1 && proc->k2 == param->k2 &&
			proc->k3 == param->k3 && proc->k4 == param->k4 &&
			proc->k5 == param->k5 && proc->k6 == param->k6)
		{
			//Initialize new neighbour
			printf("All parameters matching.\n");
			neighbour *n = malloc(sizeof(neighbour));
			n->address = ip->saddr;
			n->interface = listener;
			vector_init(&n->routes);
			n->proc = proc;
			n->seq_num = 1;
			n->last_response = current_timestamp();
			n->holdtime = htons(param->holdtime)*1000;
			n->eigrp_version = htons(version->eigrp_version);
			n->eigrp_version = htons(version->eigrp_version);
			n->pending_ack = -1; // We don't want to validate the first packet
			n->is_active = true;
			n->send_next_packet = true; //Don't wait for the first packet
			n->state = PENDING_STATE;

			struct sockaddr_in sin;
			sin.sin_family = AF_INET;
			sin.sin_addr.s_addr = ip->saddr;

			n->sin = sin;

			//This is the thread tasked with sending the packets so they arrive with the correct order(seq,ack)
			//also tasked with looking if the neighbour is still active since it handles the packets recved
			int ret = pthread_create(&n->packet_sender,NULL ,send_ipv4_packets ,(void*)n);
			if(ret){
				printf("Error creating sender thread for proccess %d ip4.\n", proc->proccess_id);
				free(n);				
				return;
			}
	
			linkedlist_init(&n->packet_queue);

			hashtable_additem(proc->neighbours,n,ip->saddr);

			//Create the update init packet

			//The packet is gonna be empty since the header is created at the end and we have no tlvs
			packetv4_param *packet = create_empty_packet(OPCODE_UPDATE,FLAG_INIT,n->sin);

			//Add it to the list so it get send orderly
			linkedlist_addtail(&n->packet_queue,packet);


			//TEMP FOR TESTING
			struct route *test = malloc(sizeof(struct route));
			test->dest = 269090816; // 16.10.0.0
			test->prefix = 16;
			test->delay = 512000;
			test->bandwidth = 20000000;
			test->mtu = 1500;
			test->hop = 1;
			test->reliability = 255;
			test->load = 1;
			test->route_tag = 0;
			test->sender = n;
			tlv_ip4_internal *test_tlv = create_interal_route_tlv(test,0);
			
			packetv4_param *packet1 = create_empty_packet(OPCODE_UPDATE,FLAG_ENDOFTABLE,n->sin);
			int byte_len = ((test->prefix -1)/8)+1;
			//tlv assumes destination is 4 byte so we subtract it and add the correct
			addtlv(packet1, test_tlv,sizeof(tlv_ip4_internal)-4+byte_len-3); //-3 is struct?
			printf("tlv length:%d\n.",sizeof(tlv_ip4_internal));

			//Add it to the list so it get send orderly
			linkedlist_addtail(&n->packet_queue,packet1);
			
		}
		
		
	}
}

struct in_addr get_destination_address(__u8 *offset, int prefix){
	int byte_len = ((prefix -1)/8)+1;
	
	struct in_addr addr;
	unsigned char *bytes = (unsigned char *) &addr;
	int i,k;
	for(i=0;i<4;i++){
		bytes[i] = 0;
	}
	k=4-byte_len-1;
	for(i=byte_len;i>0;i--){
		bytes[k--] = offset[i-1];
	}

	return addr;
}

unsigned long get_mtu(unsigned char *offset){
	return  (offset[0] << 16) | (offset[1] << 8) | (offset[2] & 0xFF);
}

unsigned long classic_unscale_bandwidth(unsigned long bw){
	return (unsigned long)EIGRP_CLASSIC_SCALE * EIGRP_BANDWIDTH / bw;
}

unsigned long classic_unscale_delay(unsigned long millisecond){
	return (unsigned long)EIGRP_CLASSIC_SCALE * 10 / millisecond;
}

unsigned long classic_scale_bandwidth(unsigned long bw){
	return (unsigned long)EIGRP_CLASSIC_SCALE * EIGRP_BANDWIDTH / bw;
}

unsigned long classic_scale_delay(unsigned long millisecond){
	return (unsigned long)EIGRP_CLASSIC_SCALE * 10 / millisecond;
}

void store_data_in_route(struct route *new_route,tlv_ip4_internal *tlv_route,neighbour *n){
	new_route->sender = n;
	new_route->prefix = tlv_route->prefix;
	//Destination address is varriable
	struct in_addr ip_addr = get_destination_address(&tlv_route->pnt_var_addr1,tlv_route->prefix);
	new_route->dest = *(unsigned int *)&ip_addr;
	
	//Metrics
	new_route->mtu = get_mtu(&tlv_route->mtu_1);
	new_route->reliability = tlv_route->reliability;
	new_route->delay = htonl(tlv_route->scaled_delay);
	new_route->bandwidth = htonl(tlv_route->scaled_bw);
	new_route->load = tlv_route->load;
	new_route->hop = tlv_route->hop_count;
	new_route->route_tag = tlv_route->route_tag;
}

void eigrp_query(packet *p,struct interface_listener *listener,struct eigrp_proccess *proc,vector *tlvs){
	struct iphdr *ip;
	ip = (struct iphdr*)p->data;

	struct eigrphdr *eigrp;
	eigrp = (struct eigrphdr*)(p->data + ip->ihl*4);


	neighbour *n;
	n = hashtable_getitem(proc->neighbours,ip->saddr);
	if(n == NULL)return;

	int i;		
	for(i=0;i<tlvs->size;i++){
		char *index = vector_get(tlvs,i);
		int type = index[1] | index[0] << 8;
		printf("Type:%d\n", type);
		if(type == 0x0102){
			tlv_ip4_internal *tlv_route = (tlv_ip4_internal *)index;
			struct route *new_route = malloc(sizeof(struct route));
			store_data_in_route(new_route,tlv_route,n);
			calculate_classic_route_metric(new_route);

			//Add the record to the topology table.
			struct topology_route *tr = get_topology_network(proc, new_route->dest, new_route->prefix);
			handle_route_changes(tr, new_route,OPCODE_QUERY);

			if(new_route->feasible_distance < tr->feasible_distance){
				tr->route_state = ACTIVE_STATE;
				route_recalculate(tr);
			}

			packetv4_param *packet = create_empty_packet(OPCODE_REPLY,0,n->sin);

			//Add it to the list so it get send orderly
			linkedlist_addtail(&n->packet_queue,packet);
	

			
		}

	}
}

void eigrp_update(packet *p,struct interface_listener *listener,struct eigrp_proccess *proc,vector *tlvs){
	struct iphdr *ip;
	ip = (struct iphdr*)p->data;

	struct eigrphdr *eigrp;
	eigrp = (struct eigrphdr*)(p->data + ip->ihl*4);


	neighbour *n;
	n = hashtable_getitem(proc->neighbours,ip->saddr);
	if(n == NULL)return;

	int i;		
	for(i=0;i<tlvs->size;i++){
		char *index = vector_get(tlvs,i);
		int type = index[1] | index[0] << 8;
		printf("Type:%d\n", type);
		if(type == 0x0102){
			//Get the tlv
			tlv_ip4_internal *tlv_route = (tlv_ip4_internal *)index;
			//Create a route records and fill it.
			struct route *new_route = malloc(sizeof(struct route));

			store_data_in_route(new_route,tlv_route,n);

			//Calculate reported_distance
			calculate_classic_route_metric(new_route);

			
			//Add the record to the topology table.
			struct topology_route *tr = get_topology_network(proc, new_route->dest, new_route->prefix);

			handle_route_changes(tr, new_route,OPCODE_UPDATE);

			if(flags_are_set(htonl(eigrp->flags), FLAG_ENDOFTABLE)){
				calculate_changes_if_needed(proc);
				n->state = UP_STATE;
			} 
		}
		if(type == 0x0103){
			struct tlv_ip4_external *route = (struct tlv_ip4_external *)index;
		}
	}
	

}

void handle_packet_ipv4(packet *p,struct interface_listener *listener,struct eigrp_proccess *proc){

	//Packet p is freed at the end of the faction
	//DO NOT free it a subfunction

	struct iphdr *ip;
	ip = (struct iphdr*)p->data;

	struct eigrphdr *eigrp;
	eigrp = (struct eigrphdr*)(p->data + ip->ihl*4);

	//First we see if the checksum is wrong to discard it
	int sum = checksum((char *)eigrp,p->length - ip->ihl*4);
	if(sum != 0){
		printf("Wrong checksum found %#4x \n", sum);
	} 

	//The socket will listen to all eigrp on this interface so we have to filter out
	//packet for other eigrp proccesses
	if(htons(proc->proccess_id) != eigrp->autonomous_sys_number){
		printf("Version %d, Opcode, %d, Virtual Router Id %d\n",eigrp->version,eigrp->opcode,eigrp->router_id);
		printf("Packet(%d) not for me(%d) dropping it\n",htons(eigrp->autonomous_sys_number),proc->proccess_id);
		free(p);
		return;
	}

	//See if the packet is coming from an existing neighbour
	neighbour *n = hashtable_getitem(proc->neighbours,ip->saddr);

	if(n == NULL){
		printf("Neighbour not found\n");

		//If a neighbour is not found but is a hello packet it will pass for proccessing
		if(eigrp->opcode != OPCODE_HELLO){
			//Is not inited yet as a neighbour and is sending non hello packets
			//drop it
			free(p);
			return;
		}
	}else{

		if(!n->is_active){
			printf("Inactive Neighour is talking again.\n");
			//Reinitialize him again
		}

		printf("Dt: %d\n",current_timestamp()-n->last_response);
		n->last_response = current_timestamp();

		int received_ack = htonl(eigrp->seqnum);
		if(received_ack != 0){
			n->pending_ack = htonl(eigrp->seqnum);
		}
		//If the packet sends the ack for the first packet in queued list remove it
		//so that the next could be send

		if(n->state = PENDING_STATE)
			if(n->init_seq == htonl(eigrp->acknum))n->state = UP_STATE;
			

		if(!linkedlist_isempty(&n->packet_queue)){
			packetv4_param *first = linkedlist_peekfirst(&n->packet_queue);
			if(htonl(eigrp->acknum) == first->seq_num && first->seq_num != 0){
				printf("removing packet seq:%d\n",first->seq_num);
				packet *sendedpacket = linkedlist_getfirst(&n->packet_queue);
				free(sendedpacket);
			}
		}

		//We removed the previous packet so now we can send the next one
		n->send_next_packet = true;

		if(eigrp->opcode == OPCODE_HELLO){
			//Drop the packet or we will end up with multiple instanses of the same
			//neightbour. Packet only used to reset the holdtime
			free(p);
			return;
		}
	}

	//Extract TLV's from the packet
	vector tlvs;
	vector_init(&tlvs); //Memory is freed at the end of this fanction
	
	char* cur_index = p->data;
	cur_index += ip->ihl*4+sizeof(struct eigrphdr);
	//we will only keep the pointer at the start of the tlv
	//then we advance the index by it's length untill we reach the end of the packet
	while(cur_index < p->data + p->length){
		vector_add(&tlvs,cur_index);
		cur_index += (cur_index[3] | cur_index[2] << 8);
	}
	//now we know how many tlv we have and where they start and can easily find out
	//the type by parsing the 3rd and 4th byte/char
	
	switch(eigrp->opcode){
		case 1: //update
			eigrp_update(p,listener,proc,&tlvs);
			break;
		case 2: //request
		break;
		case 3: //query
			eigrp_query(p,listener,proc,&tlvs);
			break;
		case 4: //reply
		break;
		case 5: //hello
			eigrp_hello(p,listener,proc,&tlvs);
			break;
		case 6: //reserved
		break;
		case 7:	//probe
		break; 
		case 8: //reserved
		break;
		case 9: //reserved
		break;
		case 10: //siaquery
		break;
		case 11: //siareply
		break;
	}

	vector_free(&tlvs);
	free(p);
}

void handle_packet_ipv6(packet *p){

	free(p);
}

//TEST FUNCTIONS
void test(neighbour *n){

	struct route *test = malloc(sizeof(struct route));
	test->dest = 269090816; // 16.10.0.0
	test->prefix = 16;
	test->delay = EIGRP_UNREACHABLE;
	test->bandwidth = 20000000;
	test->mtu = 1500;
	test->hop = 1;
	test->reliability = 0;
	test->load = 0;
	test->route_tag = 0;
	test->sender = n;
	tlv_ip4_internal *test_tlv = create_interal_route_tlv(test,0);
	
	packetv4_param *packet1 = create_empty_packet(OPCODE_QUERY,0,n->sin);
	int byte_len = ((test->prefix -1)/8)+1;
	//tlv assumes destination is 4 byte so we subtract it and add the correct
	addtlv(packet1, test_tlv,sizeof(tlv_ip4_internal)-4+byte_len-3); //-3 is struct?
	printf("tlv length:%d\n.",sizeof(tlv_ip4_internal));
	//Add it to the list so it get send orderly

	linkedlist_addtail(&n->packet_queue,packet1);
}
