#include <linux/kernel.h>
#include <asm/byteorder.h>
#include <sys/types.h>

bool compare(char *s1, char *s2);
long long current_timestamp();
int sleep_millis(long long milliseconds);
__u16 checksum(char *buffer,int len);
