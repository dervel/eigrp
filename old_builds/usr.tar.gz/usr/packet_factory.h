#include "eigrp_structs.h"

#define PACKET_LENGTH 	2046

#define OS_VERSION 	0x0C04
#define EIGRP_VERSION 	0x0102

#define OPCODE_UPDATE	1
#define OPCODE_QUERY	3
#define OPCODE_REPLY	4
#define OPCODE_HELLO	5

#define FLAG_INIT 	1
#define FLAG_ENDOFTABLE 8

#define VERSION 	2

#define LEAST_MTU	500

void auto_packet_split(neighbour *n,vector *tvls,int opcode,int flags);
void addtlv(packetv4_param *packet, void* tlv,int len);
packetv4_param *create_empty_packet(int opcode,int flags, struct sockaddr_in sin);
void create_eigrp_header(char* buffer, int packet_len, int opcode, int auto_sys_number, int seqnum, int acknum, int flags);
char *create_hello_packet(int* packet_len, struct eigrp_proccess *proc);
