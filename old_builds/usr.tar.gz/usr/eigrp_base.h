#include <stdbool.h>

#include "eigrp_structs.h"

struct eigrp_proccess* get_eigrp_proccess(int i);
struct topology_route* get_topology_network(struct eigrp_proccess* proc, int dest,int prefix);
void handle_route_changes(struct topology_route* tr, struct route *new_route, int opcode);
void add_route_record(struct topology_route* tr, struct route *new_route);
void remove_route_record(struct topology_route* tr, struct route *remove);
void calculate_changes_if_needed(struct eigrp_proccess* proc);
void remove_and_recalculate_routes(neighbour *n);
int calculate_classic_metric(struct eigrp_proccess *proc,int bandwidth,int delay,int mtu ,int load,int rel);
void calculate_classic_route_metric(struct route* newroute);
int init_eigrp_proccess(int i);
bool is_initialized_eigrp(int i);
void remove_interface(int eigrp_num, char *name);
void post_init(void);
void shutdown_eigrp(void);
void free_neighbour(neighbour *n);
void init_arrays(void);
void free_array(void);

//TEST FUNCTION
void send_query();
