#include "stdlib.h"
#include "hashtable.h"

hash_table_t *create_hash_table(int size){
	hash_table_t *new_table;

	if(size < 1) return NULL;

	if((new_table = malloc(sizeof(hash_table_t))) == NULL)
		return NULL;

	if((new_table->table = malloc(sizeof(list_t *) * size)) == NULL)
		return NULL;

	int i;
	for(i=0; i<size;i++) new_table->table[i] = NULL;

	new_table->size = size;

	return new_table;
}

unsigned int inner_hash(hash_table_t *hashtable, int key){
	unsigned int hashval;

	hashval = key;

	return hashval % hashtable->size;
}

void *hashtable_getitem(hash_table_t *hashtable, int key){
	list_t *list;
	unsigned int hashval = inner_hash(hashtable, key);

	for(list = hashtable->table[hashval]; list != NULL; list = list->next){
		if(list->key == key)
			return list->value;
	}
}

bool hashtable_removeitem(hash_table_t *hashtable, int key){

	unsigned int hashval = inner_hash(hashtable, key);

	list_t *list = hashtable->table[hashval];

	if(list == NULL) return false;

	for(; list != NULL; list = list->next){
		if(list->key == key){
			list_t *to_be_removed = list;
			list = list->next;
			free(to_be_removed);
			return true;
		}
	}

	return false;
	
}

int hashtable_additem(hash_table_t *hashtable, void* value, int key){
	list_t *new_list, *current_list;
	unsigned int hashval = inner_hash(hashtable, key);

	if((new_list = malloc(sizeof(list_t))) == NULL) return 1;
	
	current_list = hashtable_getitem(hashtable, key);
	if(current_list != NULL) return 2;

	new_list->value = value;
	new_list->key = key;
	new_list->next = hashtable->table[hashval];
	hashtable->table[hashval] = new_list;

	return 0;
}

void hashtable_free(hash_table_t *hashtable){
	int i;
	list_t *list, *temp;

	if(hashtable == NULL) return;

	for(i=0;i<hashtable->size;i++){
		list = hashtable->table[i];
		while(list != NULL){
			temp = list;
			list = list->next;
			free(temp);
		}
	}

	free(hashtable->table);
	free(hashtable);
}

unsigned int hash(char *str){
	unsigned int hashval;
	
	for(hashval=0 ; *str != 0 ; str++){
		hashval = *str + (hashval << 5) - hashval;
	}

	return hashval;

}
