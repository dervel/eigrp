#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <asm/types.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>

#include "vector.h"

struct netlink_route{
	unsigned long dest;
	int prefix;
	unsigned long gateway;
	unsigned char proto;
	unsigned long metric;
};

int route_add(__u32* destination, __u32* gateway,int prefix,__u32* metric);
int route_del(__u32* destination, __u32* gateway,int prefix,__u32* metric);
vector get_routes_by_table(int table);
vector get_routes_by_protocol(int rtm_prot);
int remove_routes_by_protocol(int protocol);
