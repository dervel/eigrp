#define VECTOR_INITIAL_CAPACITY 100

#ifndef VECTOR_H_
#define VECTOR_H_

typedef struct vector_{
	int size;
	int capacity;
	void** data;
} vector;

#endif

void vector_init(vector *vector);
void vector_empty(vector *vector);
void vector_add(vector *vector, void*);
void vector_replace(vector *vector, int index, void *value);
void *vector_get(vector *vector, int index);
void vector_set(vector *vector, int index,void*);
void vector_delete(vector *vector, int index);
void vector_double_capacity_if_full(vector *vector);
void vector_free(vector *vector);


