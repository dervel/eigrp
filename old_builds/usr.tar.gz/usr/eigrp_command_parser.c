#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "eigrp_command_parser.h"
#include "eigrp_base.h"
#include "utils.h"

static int active_proccess_id = -1; //A negative value means no eigrp proccess is selected for configuration
static int active_interface_index = -1; //A negative value mean no interface is selected for configuration

int parse_commands(char *buff, int len){

	//Split the commands by lines
	char *line_token;
	char *token;
	long id;
	long ret;

	printf("Parsing Configuration File.\n");
	while((line_token = strsep(&buff,"\n")) != NULL){
		printf("%s\n", line_token);

		token = strsep(&line_token," ");
		if(token != NULL){
			if(compare(token,"router")){
				//We expect eigrp next if not throw a message.
				token = strsep(&line_token," ");
				if(token == NULL || !compare(token, "eigrp")){
					printf("Error parsing router command.\n");
					return -1; //Negative return means smth went wrong
				}

				//Token will now have the number of the eigrp proccess
				token = strsep(&line_token," ");
				if(token == NULL){
					printf("Could not find eigrp id.\n");
					return -1;
				}
				char *ptr;
				ret = strtol(token,0,10);
				if(ret == 0){
					printf("Could not convert id to number.\n");
					return -1;
				}
				active_proccess_id = (int)ret;
				if(!is_initialized_eigrp(ret)){
					init_eigrp_proccess(ret);
				}

			}else if(compare(token,"auto-summery")){

			}else if(compare(token,"distance")){

			}else if(compare(token,"exit")){
				/*
				This command would have meaning at a real cisco router but here we will keep it only
				for the sake of having the same commands.

				It will just 'exit' the proccess so we wont be passing commands at a random eigrp proc
				*/
				active_proccess_id = -1;
			}else if(compare(token,"metric")){

			}else if(compare(token,"network")){

			}else if(compare(token,"no")){

			}else if(compare(token,"passive-interface")){
				//token will have the string description of the interface to remove
				token = strsep(&line_token," ");
				remove_interface(active_proccess_id, token);
			}else if(compare(token,"redistribute")){

			}else if(compare(token,"variance")){

			}
		}

	}

	return 0;
}
