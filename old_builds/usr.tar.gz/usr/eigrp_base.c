#define _GNU_SOURCE
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <ifaddrs.h>
#include <netdb.h>
#include <pthread.h>
#include <net/if.h>
#include <sys/ioctl.h>

#include "config.h"
#include "eigrp_base.h"
#include "eigrp_prot.h"
#include "vector.h"
#include "utils.h"
#include "hashtable.h"
#include "eigrp_structs.h"
#include "packet_factory.h"
#include "collection.h"
#include "netlink.h"

#define MAX_EIGRP_PROCCESSES 65535
#define EIGRP_PROT_NUM 88
#define PACKET_LEN 1500
#define DEFAULT_NEIGHBOURS_HASHTABLE_SIZE 40

//Switch this to some list
static struct eigrp_proccess *proccesses[MAX_EIGRP_PROCCESSES];
static hash_table_t *interface_speeds;
static hash_table_t *interface_delays;

int calculate_classic_metric(struct eigrp_proccess *proc,int bandwidth,int delay,int mtu ,int load,int rel){

	int reliability = 1;

	if(proc->k5 != 0){
		reliability = (proc->k5 / (rel + proc->k4 ));
	}

	int metric = (
			proc->k1 * bandwidth + 
			((proc->k2 * bandwidth)/(256-load)) +
			(proc->k3 * delay)
		     ) * reliability;

	return metric;
}

void calculate_classic_route_metric(struct route* newroute){
	struct eigrp_proccess *proc = newroute->sender->proc;
	int metric = calculate_classic_metric(proc,newroute->bandwidth,newroute->delay,newroute->mtu,newroute->load,newroute->reliability);
	//Reported Distance
	newroute->reported_distance = metric;

	//Feasible Distance
	//Bandwidth
	int if_bw = classic_scale_bandwidth(newroute->sender->interface->bandwidth);		
	int min_bw = newroute->bandwidth < if_bw ? newroute->bandwidth : if_bw;
	//Delay
	int if_delay = classic_scale_delay(newroute->sender->interface->delay);
	int acc_delay = newroute->delay + if_delay;
	//Mtu
	int if_mtu = newroute->sender->interface->mtu;
	int min_mtu = newroute->mtu < if_mtu ? newroute->mtu : if_mtu;
	//Load
	int if_load = newroute->sender->interface->load;
	int max_load = newroute->load > if_load ? newroute->load : if_load;
	//Reliability
	int if_rel = newroute->sender->interface->reliability;
	int min_rel = newroute->reliability < if_rel ? newroute->reliability : if_rel;
			
	int feasible_distance = calculate_classic_metric(newroute->sender->proc,min_bw,acc_delay,min_mtu ,max_load,min_rel);
	newroute->feasible_distance = feasible_distance;

}

//The idea behind this is to use the network as an identifier, however we can have the
//same network with different prefixes. So we use 2 hashtables to find the route
//One searches the network and the other searches the prefix
struct topology_route* get_topology_network(struct eigrp_proccess* proc, int dest,int prefix){
	struct topology_support* network_table = hashtable_getitem(proc->topology_support, dest);
	if(network_table == NULL){
		printf("Creatng network table\n");
		struct topology_support* new_network_table = malloc(sizeof (struct topology_support));
		new_network_table->topology_route = create_hash_table(32);
		hashtable_additem(proc->topology_support, new_network_table , dest);
		network_table = new_network_table;
	}
	struct topology_route *prefix_route = hashtable_getitem(network_table->topology_route, prefix);
	if(prefix_route == NULL){
		printf("Creatng prefix table\n");
		struct topology_route *new_route = malloc(sizeof(struct topology_route));
		
		//Init topology_route
		vector_init(&new_route->routes);
		new_route->feasible_distance = 0xFFFFFFFF; //set the metric to max
		new_route->dest = dest;
		new_route->prefix = prefix;
		new_route->route_state = ACTIVE_STATE;
		new_route->was_changed = true;
		//end topology_route init

		hashtable_additem(network_table->topology_route, new_route, prefix);
		prefix_route = new_route;
	}
	return prefix_route;
}

/*
	This functions adds/changes the routes that we receive from packets. As so we will use it to handle the route
	state.

	Also (x) indicator references the http:/tools.ietf.org/html/draft-savage-eigrp-02 page 13 route events
*/

void handle_route_changes(struct topology_route* tr, struct route *new_route, int opcode){
	//(1)
	if(opcode == OPCODE_QUERY && tr->route_state == PASSIVE_STATE &&
		tr->primary_successor->sender->address != new_route->sender->address){

		//Send the reply
		queue_reply_packet(new_route->sender,0,new_route);
		//Add or update the route metric
		add_route_record(tr,new_route);
		//Run FC to check changes on current successor
		if(new_route->feasible_distance < tr->primary_successor->reported_distance)
			tr->route_state = ACTIVE_STATE;

		return; //Job Done
		
	}

	//Will be removed only left to have a running programm atm
	add_route_record(tr,new_route);
}

void add_route_record(struct topology_route* tr, struct route *new_route){

	int i;
	for(i=0;i<tr->routes.size;i++){
		struct route *record = vector_get(&tr->routes,i);
		if(record->sender->address == new_route->sender->address){
			//I was gonna orgininally replace it, but we are just gonna overwrite the values - simpler

			record->delay = new_route->delay;
			record->bandwidth = new_route->bandwidth;
			record->mtu = new_route->mtu;
			record->hop = new_route->hop;
			record->reliability = new_route->reliability;
			record->load = new_route->load;

			record->reported_distance = new_route->reported_distance;

			//dest,prefix and sender are the same
			tr->was_changed = true;
			return;
		}
	}

	//Add the route to the topology table
	vector_add(&tr->routes, new_route);
	//Add the route to neighbour as a reference
	vector_add(&new_route->sender->routes,new_route);
}

void remove_route_record(struct topology_route* tr, struct route *remove){
	int index;
	//Somehow find the index here
	vector_delete(&tr->routes, index);
}

int get_least_feasible_distance(vector *records){
	int i, least_router_distance = 0xFFFFFFFF; //Least distance of this router to the destination

	for(i=0;i<records->size;i++){
		struct route *record = vector_get(records, i);
		//If the neighbour went inactive for some reason skip him
		if(!record->sender->is_active)
			continue;

		if(record->feasible_distance < least_router_distance)
			least_router_distance = record->feasible_distance;
	}

	return least_router_distance;
	
}

void route_recalculate(struct topology_route *route){
	printf("Found route with changes\n");
	//First check if we have a successor
	if(route->primary_successor != NULL){
	
		//if the successor is active we exit, this function is called each time a new route
		//is inserted but that doesn't mean we have to recalculate everything if the successor
		//is working fine
		if(route->primary_successor->sender->is_active && route->primary_successor->delay != EIGRP_UNREACHABLE){
			route->was_changed = false;
			return;
		}
	
		//If we have a feasible successor we can assign him to be the successor
		//Still no need to recalculate stuff
		if(route->feasible_successor != NULL && route->feasible_successor->sender->is_active && route->feasible_successor->delay != EIGRP_UNREACHABLE){
			
			route_del(&route->dest,&route->primary_successor->sender->address,route->prefix,&route->primary_successor->feasible_distance);	
		
			route->primary_successor = route->feasible_successor;
			route->feasible_successor = NULL;

			route_add(&route->dest,&route->primary_successor->sender->address,route->prefix,&route->primary_successor->feasible_distance);
			route->was_changed = false;
			return;
		}
	}

	//No successors found for the route, we will have to recalculate new ones	

	route->feasible_distance = get_least_feasible_distance(&route->routes);
	

	//Now that we have the least distance pass the records a 2nd time to find the successors
	//We are trying to find the 2 minimum cost paths - Hope the code doesn't look too ugly here
	struct route *primary_route=NULL;//successor
	struct route *secondary_route=NULL;//feasible succesor
	int i;
	for(i=0;i<route->routes.size;i++){
		struct route *record = vector_get(&route->routes, i);
		//If the neighbour went inactive for some reason skip him
		if(!record->sender->is_active)
			continue;

		if(record->delay == EIGRP_UNREACHABLE)
			continue;

		//If it's upstream ignore it
		if(record->reported_distance < route->feasible_distance)
			continue;

		if(primary_route == NULL)
			primary_route = record;
			continue;

		if(primary_route->reported_distance > record->reported_distance){
			secondary_route = primary_route;
			primary_route = record;
			continue;
		}

		if(secondary_route == NULL)
			secondary_route = record;
			continue;

		if(secondary_route->reported_distance > record->reported_distance){
			secondary_route = record;
			continue;
		}
	}

	//At this point we searched all record and we should have our successor and feasible successor
	route->primary_successor = primary_route;
	route->feasible_successor = secondary_route;

	//Add the new route to the routing table
	printf("passing new routing information.\n");
	if(route->primary_successor != NULL){
		printf("Metric %d",route->primary_successor->feasible_distance);
		route_add(&route->dest,&route->primary_successor->sender->address,route->prefix,&route->primary_successor->feasible_distance);
	}

	route->was_changed = false;
	route->route_state = PASSIVE_STATE;
}

void calculate_changes_if_needed(struct eigrp_proccess* proc){
	hash_collection *col = malloc(sizeof(hash_collection));
	col->table=proc->topology_support;
	col->table_index = 0;
	col->current = NULL;
 
	//We need to check if any of the route had any changes

	
	//Network
	struct topology_support* support;
	while((support=next(col)) != NULL){
		//Prefix
		struct topology_route *prefix_route;
		hash_collection *col2 = malloc(sizeof(hash_collection));
		col2->table=support->topology_route;
		col2->table_index = 0;
		col2->current = NULL;

		while((prefix_route=next(col2)) != NULL){
			if(prefix_route->route_state = ACTIVE_STATE)
				//Entering here doesn't mean it will recalute the route but that the
				//route has received some change
				printf("Changing Route %d\n",prefix_route->dest);
				route_recalculate(prefix_route);
		}

	}
}

void remove_and_recalculate_routes(neighbour *n){

	int i;
	for(i=0;i<n->routes.size;i++){
		struct route *r = vector_get(&n->routes,i);

		struct topology_route *route = get_topology_network(n->proc,r->dest,r->prefix);
		int k;
		//Remove the route from the topology table
		for(k=0;k<route->routes.size;k++){
			struct route *record = vector_get(&route->routes,k);			
			if(record->sender->address = r->sender->address){
				vector_delete(&route->routes,k);
				break;
			}
		}
		//Recalculate the route if needed
		route_recalculate(route);
	}
	vector_empty(&n->routes);

}

struct eigrp_proccess* get_eigrp_proccess(int i){
	
	if(i<0 || i > MAX_EIGRP_PROCCESSES){
		return NULL;
	}
	if(proccesses[i-1] == NULL){
		printf("Trying to get an uninitialized proccess %d\n", i);
		return NULL;
	}

	return proccesses[i-1];
}

void init_values(struct eigrp_proccess *proc,int i){	

	proc->running = true;

	proc->k1=1;
	proc->k2=0;
	proc->k3=1;
	proc->k4=0;
	proc->k5=0;
	proc->k6=0;

	proc->proccess_id=i;
	proc->router_id=1;
	proc->hello_interval = 5;
	proc->holdtime = proc->hello_interval * 3;

	vector_init(&proc->ifs);
	vector_init(&proc->ifs);

	proc->neighbours = create_hash_table(DEFAULT_NEIGHBOURS_HASHTABLE_SIZE);
	proc->topology_support = create_hash_table(30);

}



int init_eigrp_proccess(int i){

	struct eigrp_proccess *proc;
	struct net_device *dev;

	if(i<0 || i > MAX_EIGRP_PROCCESSES)
		return -1;

	if(proccesses[i-1] != NULL){
		printf("Eigrp Proccess %d already initialized\n" , i);
		return -1;
	}

	printf("Starting Eigrp Proccess %d\n" , i);
	
	proc = malloc(sizeof(struct eigrp_proccess));

	//Init Basic Values
	init_values(proc, i);

	//struct eigrp_proccess *proc = &proccesses[i-1];

	proccesses[i-1] = proc;

	return 0;
}

void remove_interface(int eigrp_num, char *name){
	int i;
	struct ifaddrs *ifa;
	vector_add(&proccesses[eigrp_num-1]->ifs,name);
}

bool vector_contains(vector *v, char *string){
	int i;
	for(i=0;i<v->size;i++){
		if(compare(vector_get(v,i), string))
			return true;
	}
	return false;
}

bool is_initialized_eigrp(int i){
	
	if(i<0 || i > MAX_EIGRP_PROCCESSES)
		return false;

	if(proccesses[i-1] != NULL){
		return true;
	}else{
		return false;
	}
}

void *hello_packet_thread(void *ptr){
	int proccess_id;
	struct eigrp_proccess *proc;
	struct interface_listener *listener;

	listener = (struct interface_listener *)ptr;
	proccess_id = listener->eigrp_proccess_id;
	proc = proccesses[proccess_id-1];

	//Prepare the hello packet once so we don't have to make it over and over
	int packet_len=0;
	char *buffer = create_hello_packet(&packet_len,proc);

	struct sockaddr_in sin;
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = inet_addr("224.0.0.10");

	packetv4_param packet;
	packet.buffer = buffer;
	packet.buffer_len = packet_len;
	packet.sin = sin;

	while(proc->running){		

		send_ip4_packet(&packet, listener->socket);

		sleep(proc->hello_interval);		
	}

	free(buffer);
}

void *listen_ip6( void *ptr){
	int proccess_id;
	struct eigrp_proccess *proc;
	struct interface_listener *listener;

	listener = (struct interface_listener *)ptr;
	proccess_id = listener->eigrp_proccess_id;
	proc = proccesses[proccess_id-1];	
	
	printf("Starting thread for proccess %d.\n", proccess_id);

	char* buffer = (char*)malloc(PACKET_LEN);
	int cur_length = 0;
	int pak_length = 0;

	while(proc->running){
		int len;

		len = recv(listener->socket, (buffer+cur_length), PACKET_LEN, 0);
		cur_length += len;
		if(cur_length >= 6){
			pak_length = buffer[5] | buffer[4] << 8;
		}else{
			continue;
		}

		//wait for the whole packet to be transmitted
		if(cur_length >= pak_length){
			packet *p = create_packet(buffer,pak_length);
			handle_packet_ipv6(p);

			//we have some data from the next packet
			if(cur_length > pak_length){
				memmove(buffer,buffer+pak_length,cur_length-pak_length);
				pak_length = 0;
				cur_length -= pak_length;
				continue;
			}

			pak_length = 0;
			cur_length = 0;
		}

		

	}
}

void *listen_ip4( void *ptr){
	int proccess_id;
	struct eigrp_proccess *proc;
	struct interface_listener *listener;

	listener = (struct interface_listener *)ptr;
	proccess_id = listener->eigrp_proccess_id;
	proc = proccesses[proccess_id-1];	
	
	printf("Starting thread for proccess %d.\n", proccess_id);

	char buffer[PACKET_LEN];
	int cur_length = 0;
	int pak_length = 0;

	while(proc->running){
		int len;

		len = recv(listener->socket, (buffer+cur_length), PACKET_LEN, 0);
		cur_length += len;
		if(cur_length > 4){
			pak_length = buffer[3] | buffer[2] << 8;
		}else{
			continue;
		}

		//wait for the whole packet to be transmitted
		if(cur_length >= pak_length){
			packet *p = create_packet(buffer,pak_length);
			handle_packet_ipv4(p,listener,proc);

			//we have some data from the next packet
			if(cur_length > pak_length){
				memmove(buffer,buffer+pak_length,cur_length-pak_length);
				pak_length = 0;
				cur_length -= pak_length;
				continue;
			}

			pak_length = 0;
			cur_length = 0;
		}

		

	}
}

int disable_ip4_loopback(int socket){
	char loopch = 0;
	if(setsockopt(socket, IPPROTO_IP, IP_MULTICAST_LOOP, (char *)&loopch, sizeof(loopch)) < 0){
		return -1;
	}
	return 0;
}

int get_socket_mtu(int socket,int family,char *name){
	struct ifreq ifr;
	ifr.ifr_addr.sa_family = family;
	strcpy(ifr.ifr_name,name);
	if(ioctl(socket, SIOCGIFMTU, &ifr) < 0){
		return -1;
	}
	return ifr.ifr_mtu;
}

long get_interface_bandwidth(char *name){
	long speed;
	number *result = hashtable_getitem(interface_speeds,hash(name));	
	if(result == NULL){
		//Use default speed - we will use FastEthernet as the default
		speed = 100000;
	}else{
		speed = result->number;
	}
	
	return speed;
}

long get_interface_delay(char *name){
	long delay;
	number *result = hashtable_getitem(interface_delays,hash(name));	
	if(result == NULL){
		//Use default speed - we will use FastEthernet as the default
		delay = 100000;
	}else{
		delay = result->number;
	}
	
	return delay;
}

void post_init_proccess(int i){
	struct eigrp_proccess *proc;
	struct ifaddrs *addrs, *tmp, *next;	
	char host[NI_MAXHOST];
	int ret;

	proc = proccesses[i-1];	
		
	//REGISTER INTERFACES TO LISTEN TO
	getifaddrs(&addrs);
	next = addrs;

	while(next){
		tmp = next;
		next = next->ifa_next;
				
		//first discard the interface we don't want
		if(compare(tmp->ifa_name, "lo")){
			continue;
		}

		if(vector_contains(&proc->ifs,tmp->ifa_name)){
			printf("Skipping interface %s.\n", tmp->ifa_name);
			continue;
		}

		//sa_family == 17 might block some other net protocol will look at it later
		if(!tmp->ifa_addr || tmp->ifa_addr->sa_family == 17)
			continue;

		//Create the socket and the listening thread for each needed interface per eigrp proccess

		struct interface_listener *listener;
		listener = malloc(sizeof(struct interface_listener));
		listener->eigrp_proccess_id = proc->proccess_id;
		listener->name = tmp->ifa_name;
		
		if(tmp->ifa_addr->sa_family == AF_INET){

			listener->socket = socket(AF_INET, SOCK_RAW, EIGRP_PROT_NUM);
			if(listener->socket == -1){
				printf("Could not create socket ip4 in proc %d.\n", i);
				free(listener);
				continue;
			}

			if(getnameinfo(tmp->ifa_addr, sizeof(struct sockaddr_in), host, NI_MAXHOST, NULL , 0 , NI_NUMERICHOST) != 0){
				printf("getnameinfo() failed");
			}
			struct ip_mreq group;
			group.imr_multiaddr.s_addr = inet_addr("224.0.0.10");
			group.imr_interface.s_addr = inet_addr(host);
			if(setsockopt(listener->socket, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char*)&group, sizeof(group)) < 0){
				printf("Could not join multicast group at ip4 proc %d.\n", proc->proccess_id);
				free(listener);
				continue;
			}
			if(setsockopt(listener->socket, SOL_SOCKET, SO_BINDTODEVICE, tmp->ifa_name, sizeof(tmp->ifa_name))){
				printf("Could not bind socket to interface %s.\n", tmp->ifa_name);
				close(listener->socket);
				free(listener);
				continue;
			}
			
			//----
			if(disable_ip4_loopback(listener->socket) < 0){
				printf("Could not set disable loopback to interface %s.\n", tmp->ifa_name);
				close(listener->socket);
				free(listener);
				continue;
			}
			int mtu = get_socket_mtu(listener->socket,AF_INET,tmp->ifa_name);
			if(mtu < 0){
				printf("Could not get interface %s MTU.\n", tmp->ifa_name);
				close(listener->socket);
				free(listener);
				continue;
			}
			listener->mtu = mtu;

			listener->bandwidth = get_interface_bandwidth(tmp->ifa_name);
			listener->reliability = 255;
			listener->load = 1;
			listener->delay = get_interface_delay(tmp->ifa_name);

			ret = pthread_create(&listener->packet_listener,NULL ,listen_ip4 ,(void*)listener);
			if(ret){
				printf("Error creating listen thread for proccess %d ip4.\n", proc->proccess_id);
				close(listener->socket);
				free(listener);
				continue;
			}
			ret = pthread_create(&listener->hello_sender,NULL ,hello_packet_thread ,(void*)listener);
			if(ret){
				printf("Error creating hello thread for proccess %d ip4.\n", proc->proccess_id);
				close(listener->socket);
				free(listener);
				continue;
			}
		}

		if(tmp->ifa_addr->sa_family == AF_INET6){

			listener->socket = socket(AF_INET6, SOCK_RAW, EIGRP_PROT_NUM);
			if(listener->socket == -1){
				printf("Could not create socket ip6 in proc %d.\n", i);
				free(listener);
				continue;
			}
			
			if(getnameinfo(tmp->ifa_addr, sizeof(struct sockaddr_in6), host, NI_MAXHOST, NULL , 0 , NI_NUMERICHOST) != 0){
				printf("getnameinfo() failed");
			}
			struct ipv6_mreq group;
			struct addrinfo *reslocal,*resmulti,hints;
			
			getaddrinfo(host, NULL, NULL, &reslocal);
			getaddrinfo("FF02::A",NULL,NULL,&resmulti);

			group.ipv6mr_multiaddr = ((struct sockaddr_in6 *)resmulti->ai_addr)->sin6_addr;
			group.ipv6mr_interface = ((struct sockaddr_in6 *)reslocal->ai_addr)->sin6_scope_id;

			if(setsockopt(listener->socket, IPPROTO_IPV6, IPV6_ADD_MEMBERSHIP, (char*)&group, sizeof(group)) < 0){
				printf("Could not join multicast group at ip6 proc %d.\n", proc->proccess_id);
				free(listener);
				continue;
			}
			if(setsockopt(listener->socket, SOL_SOCKET, SO_BINDTODEVICE, tmp->ifa_name, sizeof(tmp->ifa_name))){
				printf("Could not bind socket to interface %s.\n", tmp->ifa_name);
				close(listener->socket);
				free(listener);
				continue;
			}
			int loopch = 0;
			if(setsockopt(listener->socket, IPPROTO_IPV6, IPV6_MULTICAST_LOOP, &loopch, sizeof(loopch)) < 0){
				printf("Could not set disable loopback to interface %s.\n", tmp->ifa_name);				
				close(listener->socket);
				free(listener);
				continue;
			}
			ret = pthread_create(&listener->packet_listener ,NULL ,listen_ip6 ,(void*)listener);
			if(ret){
				printf("Error creating listen thread for proccess %d ip6.\n", proc->proccess_id);
				close(listener->socket);
				free(listener);
				continue;
			}
			/*
			ret = pthread_create(&listener->packet_sender,NULL ,send_ip6_packet ,(void*)listener);
			if(ret){
				printf("Error creating thread for proccess %d ip6.\n", proc->proccess_id);
				close(listener->socket);
				free(listener);
				continue;
			}*/
		}

		printf("Interface %s added properly to eigrp proccess %d family: %d \n", tmp->ifa_name, proc->proccess_id, tmp->ifa_addr->sa_family);
		vector_add(&proc->sockets, listener);
		
	}	
	
	freeifaddrs(addrs);
	return;
	
}

void free_neighbour(neighbour *n){
	n->is_active = false;
	remove_and_recalculate_routes(n);
	vector_free(&n->routes);
	linkedlist_free(&n->packet_queue);
	free(n);
}

void post_init(){
	int i;
	for(i=0;i<MAX_EIGRP_PROCCESSES ;i++){
		if(is_initialized_eigrp(i))
			post_init_proccess(i);
	}
}

void shutdown_proccess(int i){
	struct eigrp_proccess *proc;

	proc = proccesses[i-1];	

	proc->running = false;

	int k;
	int size = proc->sockets.size;
	for(k=0;k<size;k++){
		struct interface_listener *listener = vector_get(&proc->sockets,k);
		close(listener->socket);
		free(listener);
	}

	hashtable_free(proc->neighbours);
}

void shutdown_eigrp(){
	int i;
	for(i=0;i<MAX_EIGRP_PROCCESSES ;i++){
		if(is_initialized_eigrp(i))
			shutdown_proccess(i);
	}
}

void init_arrays(){

	interface_speeds=create_hash_table(20);
	interface_delays=create_hash_table(20);

	int i;	
	for(i=0;i<MAX_EIGRP_PROCCESSES;i++){
		proccesses[i] = NULL;
	}
}

void free_array(){
	int i;
	struct eigrp_proccess *proc;
	for(i=0;i<MAX_EIGRP_PROCCESSES;i++){
		if(proccesses[i] != NULL){
			proc = proccesses[i];
			vector_free(&proc->ifs);
			free(proc);
		}
			
	}
}

//TEST FUNCTION
void send_query(){

	struct eigrp_proccess *proc;
	proc = proccesses[3-1];	

	hash_collection *col = malloc(sizeof(hash_collection));
	col->table=proc->neighbours;
	col->table_index = 0;
	col->current = NULL;
	
	//Network
	neighbour *n;
	
	while((n=next(col)) != NULL){
		test(n);
	}
}
