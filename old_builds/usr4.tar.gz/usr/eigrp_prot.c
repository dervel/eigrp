#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <string.h>
#include <arpa/inet.h>

#include "eigrp_prot.h"
#include "linkedlist.h"
#include "eigrp_structs.h"
#include "eigrp_base.h"
#include "packet_factory.h"
#include "vector.h"
#include "utils.h"
#include "config.h"

bool flags_are_set(int flag_field, int flag){
	int val = flag_field & flag;
	if(val == 0){return false;}
	else{return true;}
}

packet *create_packet(char *buffer, int length){

	packet *p = malloc(sizeof(packet));
	p->data = buffer;
	p->length = length;
	return p;
}

void send_ip4_packet_multicast(packetv4_param *param, struct eigrp_proccess *proc){
	int i;
	interface *iff;
	struct sockaddr_in sin;
	
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = inet_addr("224.0.0.10");


	for(i=0;i<proc->ifs.size;i++){
		iff = vector_get(&proc->ifs,i);
		if(sendto(iff->socket4, param->buffer, param->buffer_len, 0,(struct sockaddr*)&sin, sizeof(sin)) < 0){
			printf("Error Sending Packet Muticast\n");
		}
	}
}

void send_ip4_packet(packetv4_param *param, int socket){
	
	if(sendto(socket, param->buffer, param->buffer_len, 0,(struct sockaddr*)&param->sin, sizeof(param->sin)) < 0){
		printf("Error Sending Packet\n");
	}
}

void eigrp_hello(packet *p,interface *iff,struct eigrp_proccess *proc,vector *tlvs){
	int i;	
	struct iphdr *ip;
	ip = (struct iphdr*)p->data;

	struct eigrphdr *eigrp;
	eigrp = (struct eigrphdr*)(p->data + ip->ihl*4);

	neighbour *n;
	n = hashtable_getitem(proc->neighbours,ip->saddr);
	if(n == NULL){
		printf("New neighbour canditate\n");

		//printf("IP:%s\n",ip4_tochar(n->interface->ifa_addr_ip4->sin_addr.s_addr));
		
		struct tlv_parameter_type *param = NULL;
		struct tlv_version_type *version = NULL;
		
		//first extract the tlv_param
		int i;		
		for(i=0;i<tlvs->size;i++){
			char *index = vector_get(tlvs,i);
			int type = index[1] | index[0] << 8;
			printf("Type:%d\n", type);
			if(type == 0x0001)
				param = (struct tlv_parameter_type *)index;
			if(type == 0x0004)
				version = (struct tlv_version_type *)index;
		}

		
		if(param == NULL){
			printf("Missing parameter tlv ignoring hello packet.\n");
			return;
		}
		
		if(version == NULL){
			printf("Missing version tlv ignoring hello packet.\n");
			return;
		}
		
		//Let's make a big if to check the tlv_parameters
		if(proc->k1 == param->k1 && proc->k2 == param->k2 &&
			proc->k3 == param->k3 && proc->k4 == param->k4 &&
			proc->k5 == param->k5 )
		{
			//Initialize new neighbour
			printf("All parameters matching.\n");
			neighbour *n = malloc(sizeof(neighbour));
			n->address = ip->saddr;
			n->interface = iff;
			vector_init(&n->routes);
			n->proc = proc;
			n->last_response = current_timestamp();
			n->holdtime = htons(param->holdtime)*1000;
			n->eigrp_version = htons(version->eigrp_version);
			n->eigrp_version = htons(version->eigrp_version);
			n->pending_ack = -1; // We don't want to validate the first packet
			n->last_ack_sent = 0;
			n->last_packet_sent = 0;
			n->is_active = true;
			n->send_next_packet = true; //Don't wait for the first packet
			n->state = PENDING_STATE;
			n->eot = false;
			n->cr = false;
			n->discovery_time = current_timestamp();
			n->srtt = 0;

			struct sockaddr_in sin;
			sin.sin_family = AF_INET;
			sin.sin_addr.s_addr = ip->saddr;

			n->sin = sin;
	
			linkedlist_init(&n->packet_queue);

			linkedlist_init(&n->update_tlv_queue);
			linkedlist_init(&n->query_tlv_queue);
			linkedlist_init(&n->reply_tlv_queue);

			n->reply_flag = 0;
			n->query_flag = 0;
			n->update_flag = 0;

			hashtable_additem(proc->neighbours,n,ip->saddr);

			//Create the update init packet

			

			//The packet is gonna be empty since the header is created at the end and we have no tlvs
			packetv4_param *packet = create_empty_packet(OPCODE_UPDATE,FLAG_INIT,n->sin);

			//Add it to the list so it get send orderly
			linkedlist_addtail(&n->packet_queue,packet);

			packetv4_param *packet1 = create_empty_packet(OPCODE_UPDATE,FLAG_ENDOFTABLE,n->sin);
			

			for(i=0;i<proc->connected_routes.size;i++){
				route *r = vector_get(&proc->connected_routes,i);
				if(r->sender->interface->index == n->interface->index)continue;
				//tlv assumes destination is 4 byte so we subtract it and add the correct
				tlv_ip4_internal *route_tlv = create_interal_route_tlv(r,0);
				int byte_len = ((r->prefix -1)/8)+1;
				addtlv(packet1, route_tlv,sizeof(tlv_ip4_internal)-4+byte_len-3); //-3 is struct?
			}
			printf("tlv length:%d\n.",sizeof(tlv_ip4_internal));

			//Add it to the list so it get send orderly
			linkedlist_addtail(&n->packet_queue,packet1);
			
		}
		
		
	}else{
		int i;
		bool cr= false;
		int packet_seq=0;	
		for(i=0;i<tlvs->size;i++){
			char *index = vector_get(tlvs,i);
			int type = index[1] | index[0] << 8;
			int len = index[3] | index[2] << 8;
			int pos = 4;
			printf("Type:%d\n", type);
			if(type == 0x0003){
				while(pos < len){
					//if it's not 4 it refers to an other protocol (not ip4)
					if(index[pos] == 4){
						pos++;

						__u32 address;
						memcpy(&address, &index[pos], 4);
						pos +=4;

						printf("IP:%s compared to:%s\n",ip4_tochar(address),ip4_tochar(n->interface->ifa_addr_ip4->sin_addr.s_addr));

						if( address == n->interface->ifa_addr_ip4->sin_addr.s_addr){
							cr = true;
							break;
						}
					}else{
						pos += index[pos] + 1;
					}
				}

			}
			if(type == 0x0005){
				struct tlv_next_multicast *next_mul = NULL;
				next_mul = (struct tlv_next_multicast *)index;
				packet_seq = htonl(next_mul->seq_num);
				int i=0;i++;
			}
		}

		if(cr && packet_seq != 0){
			n->cr = true;
			n->cr_num = packet_seq;
		}

	}
}

struct in_addr get_destination_address(__u8 *offset, int prefix){
	int byte_len = ((prefix -1)/8)+1;
	
	struct in_addr addr;
	unsigned char *bytes = (unsigned char *) &addr;
	int i,k;
	for(i=0;i<4;i++){
		bytes[i] = 0;
	}
	k=byte_len-1;
	for(i=byte_len;i>0;i--){
		printf("B:%d\n",offset[i-1]);
		bytes[k--] = offset[i-1];
	}

	return addr;
}

unsigned long get_mtu(unsigned char *offset){
	return  (offset[0] << 16) | (offset[1] << 8) | (offset[2] & 0xFF);
}

void store_data_in_route(route *new_route,tlv_ip4_internal *tlv_route,neighbour *n){
	new_route->sender = n;
	new_route->prefix = tlv_route->prefix;
	//Destination address is varriable
	struct in_addr ip_addr = get_destination_address(&tlv_route->pnt_var_addr1,tlv_route->prefix);
	new_route->dest = *(unsigned int *)&ip_addr;
	//Metrics
	new_route->mtu = get_mtu(&tlv_route->mtu_1);
	new_route->reliability = tlv_route->reliability;
	new_route->delay = classic_unscale_delay(htonl(tlv_route->scaled_delay));
	new_route->bandwidth = classic_unscale_bandwidth(htonl(tlv_route->scaled_bw));
	new_route->load = tlv_route->load;
	new_route->hop = tlv_route->hop_count;
	new_route->route_tag = tlv_route->route_tag;
}

void eigrp_query(packet *p,interface *iff,struct eigrp_proccess *proc,vector *tlvs){
	struct iphdr *ip;
	ip = (struct iphdr*)p->data;

	struct eigrphdr *eigrp;
	eigrp = (struct eigrphdr*)(p->data + ip->ihl*4);


	neighbour *n;
	n = hashtable_getitem(proc->neighbours,ip->saddr);
	if(n == NULL)return;

	int i;		
	for(i=0;i<tlvs->size;i++){
		char *index = vector_get(tlvs,i);
		int type = index[1] | index[0] << 8;
		printf("Type:%d\n", type);
		if(type == 0x0102){
			tlv_ip4_internal *tlv_route = (tlv_ip4_internal *)index;
			route *new_route = malloc(sizeof(route));
			new_route->is_proccess_generated = false;
			new_route->index = -1;
			new_route->rijk = 0;
			store_data_in_route(new_route,tlv_route,n);
			calculate_classic_route_metric(new_route->sender->proc,new_route);

			//Add the record to the topology table.
			struct topology_route *tr = get_topology_network(proc, new_route->dest, new_route->prefix);
			handle_route_changes(tr, new_route,OPCODE_QUERY,new_route->sender->proc);		
		}

	}
}

void eigrp_reply(packet *p,interface *iff,struct eigrp_proccess *proc,vector *tlvs){
	struct iphdr *ip;
	ip = (struct iphdr*)p->data;

	struct eigrphdr *eigrp;
	eigrp = (struct eigrphdr*)(p->data + ip->ihl*4);


	neighbour *n;
	n = hashtable_getitem(proc->neighbours,ip->saddr);
	if(n == NULL)return;

	//Send the ack packet before we start processing the packet
	n->send_next_packet = true;

	int i;		
	for(i=0;i<tlvs->size;i++){
		char *index = vector_get(tlvs,i);
		int type = index[1] | index[0] << 8;
		printf("Type:%d\n", type);
		if(type == 0x0102){
			tlv_ip4_internal *tlv_route = (tlv_ip4_internal *)index;
			route *new_route = malloc(sizeof(route));
			new_route->is_proccess_generated = false;
			new_route->index = -1;
			new_route->rijk = 0;
			store_data_in_route(new_route,tlv_route,n);
			calculate_classic_route_metric(new_route->sender->proc,new_route);

			//Add the record to the topology table.
			struct topology_route *tr = get_topology_network(proc, new_route->dest, new_route->prefix);
			handle_route_changes(tr, new_route,OPCODE_REPLY,new_route->sender->proc);

		}

	}
}

void eigrp_update(packet *p,interface *iff,struct eigrp_proccess *proc,vector *tlvs){
	struct iphdr *ip;
	ip = (struct iphdr*)p->data;

	struct eigrphdr *eigrp;
	eigrp = (struct eigrphdr*)(p->data + ip->ihl*4);

	neighbour *n;
	n = hashtable_getitem(proc->neighbours,ip->saddr);
	if(n == NULL)return;

	int i;		
	for(i=0;i<tlvs->size;i++){
		char *index = vector_get(tlvs,i);
		int type = index[1] | index[0] << 8;
		printf("Type:%d\n", type);
		if(type == 0x0102){
			//Get the tlv
			tlv_ip4_internal *tlv_route = (tlv_ip4_internal *)index;
			//Create a route records and fill it.
			route *new_route = malloc(sizeof(route));
			new_route->is_proccess_generated = false;
			new_route->index = -1;
			new_route->rijk = 0;
			store_data_in_route(new_route,tlv_route,n);
			//Calculate reported_distance
			calculate_classic_route_metric(new_route->sender->proc,new_route);
		
			//Add the record to the topology table.
			struct topology_route *tr = get_topology_network(proc, new_route->dest, new_route->prefix);
			handle_route_changes(tr, new_route,OPCODE_UPDATE,new_route->sender->proc);
		}
		if(type == 0x0103){
			struct tlv_ip4_external *route = (struct tlv_ip4_external *)index;
		}
	}

	if(flags_are_set(htonl(eigrp->flags), FLAG_ENDOFTABLE)){
		n->eot = true;
		if(all_end_of_table_received(n->proc))
			init_calculate_routes(n->proc);
	}
}

void eigrp_siaquery(packet *p,interface *iff,struct eigrp_proccess *proc,vector *tlvs){
	struct iphdr *ip;
	ip = (struct iphdr*)p->data;

	struct eigrphdr *eigrp;
	eigrp = (struct eigrphdr*)(p->data + ip->ihl*4);

	neighbour *n;
	n = hashtable_getitem(proc->neighbours,ip->saddr);
	if(n == NULL)return;

	//Send ack before processing the packet
	n->send_next_packet = true;

	packetv4_param *packet = create_empty_packet(OPCODE_SIAREPLY,0,n->sin);

	//Sia-query is a per-destination packet but we process it like it was a normal packet
	int i;	
	for(i=0;i<tlvs->size;i++){
		char *index = vector_get(tlvs,i);
		int type = index[1] | index[0] << 8;
		printf("Type:%d\n", type);
		if(type == 0x0102){
			//Get the tlv
			tlv_ip4_internal *tlv_route = (tlv_ip4_internal *)index;
			route *new_route = malloc(sizeof(route));
			new_route->is_proccess_generated = false;
			new_route->index = -1;
			new_route->rijk = 0;
			store_data_in_route(new_route,tlv_route,n);

			struct topology_route *tr = get_topology_network(proc, new_route->dest, new_route->prefix);
			int route_flag = 0;
			if(tr->route_state == ACTIVE_STATE) route_flag |= FLAG_ROUTEACTIVE;

			//tlv assumes destination is 4 byte so we subtract it and add the correct
			tlv_ip4_internal *route_tlv = create_interal_route_tlv(tr->successor,route_flag);
			int byte_len = ((tr->successor->prefix -1)/8)+1;
			addtlv(packet, route_tlv,sizeof(tlv_ip4_internal)-4+byte_len-3); //-3 is struct?
			
		}
		if(type == 0x0103){
			struct tlv_ip4_external *route = (struct tlv_ip4_external *)index;
		}
	}

	//Add it to the list so it get send orderly
	linkedlist_addtail(&n->packet_queue,packet);



}

void eigrp_siareply(packet *p,interface *iff,struct eigrp_proccess *proc,vector *tlvs){
	struct iphdr *ip;
	ip = (struct iphdr*)p->data;

	struct eigrphdr *eigrp;
	eigrp = (struct eigrphdr*)(p->data + ip->ihl*4);

	neighbour *n;
	n = hashtable_getitem(proc->neighbours,ip->saddr);
	if(n == NULL)return;

	//Sia-query is a per-destination packet but we process it like it was a normal packet
	int i;	
	for(i=0;i<tlvs->size;i++){
		char *index = vector_get(tlvs,i);
		int type = index[1] | index[0] << 8;
		printf("Type:%d\n", type);
		if(type == 0x0102){
			//Get the tlv
			tlv_ip4_internal *tlv_route = (tlv_ip4_internal *)index;
			route *new_route = malloc(sizeof(route));
			new_route->is_proccess_generated = false;
			new_route->index = -1;
			new_route->rijk = 0;
			store_data_in_route(new_route,tlv_route,n);

			route *r  = get_route(new_route, n);
			r->sia_query_received = true;

			if(!flags_are_set(tlv_route->flags, FLAG_ROUTEACTIVE)){
				store_data_in_route(new_route,tlv_route,n);
				//Calculate reported_distance
				calculate_classic_route_metric(new_route->sender->proc,new_route);
			}
			
		}
		if(type == 0x0103){
			struct tlv_ip4_external *route = (struct tlv_ip4_external *)index;
		}
	}

}

void handle_packet_ipv4(packet *p,interface *iff){

	//Packet p is freed at the end of the faction
	//DO NOT free it a subfunction

	struct iphdr *ip;
	ip = (struct iphdr*)p->data;

	struct eigrphdr *eigrp;
	eigrp = (struct eigrphdr*)(p->data + ip->ihl*4);

	//First we see if the checksum is wrong to discard it
	int sum = checksum((char *)eigrp,p->length - ip->ihl*4);
	if(sum != 0){
		printf("Wrong checksum found %#4x \n", sum);
	}

	int id = htons(eigrp->autonomous_sys_number);
	struct eigrp_proccess *proc = get_eigrp_proccess(id);
	if(proc == NULL) return;

	//See if the packet is coming from an existing neighbour
	neighbour *n = hashtable_getitem(proc->neighbours,ip->saddr);

	printf("Received Packet for proccess %d of type %s, seq %d.\n",proc->proccess_id,to_string(eigrp->opcode),htonl(eigrp->seqnum));

	if(n == NULL){
		printf("Neighbour not found\n");

		//If a neighbour is not found but is a hello packet it will pass for proccessing
		if(eigrp->opcode != OPCODE_HELLO){
			//Is not inited yet as a neighbour and is sending non hello packets
			//drop it
			return;
		}
	}else{

		if(!n->is_active){
			printf("Inactive Neighour is talking again.\n");
			//Reinitialize him again
		}

		printf("Dt: %d\n",current_timestamp()-n->last_response);
		n->last_response = current_timestamp();
		//Drop packet if it cointain cr flag and we don't have cr flag enabled
		if(flags_are_set(htonl(eigrp->flags), FLAG_CR)){
			if(n->cr && n->cr_num == htonl(eigrp->seqnum)){
				printf("CR flag setted, droping packet.\n");
				n->cr = false;
				return;
			}
		}

		int seqnum = htonl(eigrp->seqnum);
		if(seqnum != 0){

			if(seqnum <= n->pending_ack){
				//Duplicate packet send the last packet/ACK again and drop this one
				n->send_next_packet = true;
				return;
			} 

			if(eigrp->opcode == OPCODE_HELLO){
				printf("Skipping seq number this should contain a seq_tlv\n.");
			}else{
				n->pending_ack = seqnum;
			}
		}
		//If the packet sends the ack for the first packet in queued list remove it
		//so that the next could be send

		if(n->state == PENDING_STATE)
			if(n->init_seq == htonl(eigrp->acknum))n->state = UP_STATE;
			

		if(!linkedlist_isempty(&n->packet_queue)){
			packetv4_param *first = linkedlist_peekfirst(&n->packet_queue);
			if(htonl(eigrp->acknum) == first->seq_num && first->seq_num != 0){
				n->srtt = current_timestamp() - n->last_packet_sent;
				printf("removing packet seq:%d\n",first->seq_num);
				packet *sendedpacket = linkedlist_getfirst(&n->packet_queue);
				free(sendedpacket);
			}
		}

		//We removed the previous packet so now we can send the next one
		n->send_next_packet = true;
	}

	//Extract TLV's from the packet
	vector tlvs;
	vector_init(&tlvs); //Memory is freed at the end of this fanction
	
	char* cur_index = p->data;
	cur_index += ip->ihl*4+sizeof(struct eigrphdr);
	//we will only keep the pointer at the start of the tlv
	//then we advance the index by it's length untill we reach the end of the packet
	while(cur_index < p->data + p->length){
		vector_add(&tlvs,cur_index);
		cur_index += (cur_index[3] | cur_index[2] << 8);
	}
	//now we know how many tlv we have and where they start and can easily find out
	//the type by parsing the 3rd and 4th byte/char

	proc->stats.packets_received[eigrp->opcode]++;
	if(eigrp->acknum != 0)proc->stats.acks_received++;
	
	switch(eigrp->opcode){
		case 1: //update
			eigrp_update(p,iff,proc,&tlvs);
			break;
		case 2: //request
		break;
		case 3: //query
			eigrp_query(p,iff,proc,&tlvs);
			break;
		case 4: //reply
			eigrp_reply(p,iff,proc,&tlvs);
		break;
		case 5: //hello
			eigrp_hello(p,iff,proc,&tlvs);
			break;
		case 6: //reserved
		break;
		case 7:	//probe
		break; 
		case 8: //reserved
		break;
		case 9: //reserved
		break;
		case 10: //siaquery
			eigrp_siaquery(p,iff,proc,&tlvs);
			break;
		case 11: //siareply
			eigrp_siareply(p,iff,proc,&tlvs);
			break;
	}

	vector_free(&tlvs);
}

void handle_packet_ipv6(packet *p){

}

//TEST FUNCTIONS
void test(neighbour *n){

	route *test = malloc(sizeof(route));
	test->dest = 269090816; // 16.10.0.0
	test->prefix = 16;
	test->delay = EIGRP_UNREACHABLE;
	test->bandwidth = 20000000;
	test->mtu = 1500;
	test->hop = 1;
	test->reliability = 0;
	test->load = 0;
	test->route_tag = 0;
	test->sender = n;
	tlv_ip4_internal *test_tlv = create_interal_route_tlv(test,0);
	
	packetv4_param *packet1 = create_empty_packet(OPCODE_QUERY,0,n->sin);
	int byte_len = ((test->prefix -1)/8)+1;
	//tlv assumes destination is 4 byte so we subtract it and add the correct
	addtlv(packet1, test_tlv,sizeof(tlv_ip4_internal)-4+byte_len-3); //-3 is struct?
	printf("tlv length:%d\n.",sizeof(tlv_ip4_internal));
	//Add it to the list so it get send orderly

	linkedlist_addtail(&n->packet_queue,packet1);
}
