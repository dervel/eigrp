#include <stdlib.h>
#include <string.h>
#include <stdio.h>


#include "config.h"
#include "eigrp_structs.h"
#include "packet_factory.h"
#include "collection.h"

unsigned long classic_unscale_bandwidth(unsigned long scaled_bw){
	return (unsigned long)(((double)EIGRP_BANDWIDTH / (double)scaled_bw) * (double)EIGRP_CLASSIC_SCALE);
}

unsigned long classic_unscale_delay(unsigned long scaled_microseconds){
	if(scaled_microseconds == EIGRP_UNREACHABLE)return EIGRP_UNREACHABLE;
	return scaled_microseconds * 10 / (EIGRP_CLASSIC_SCALE ) ;
}

unsigned long classic_scale_bandwidth(unsigned long bw){
	if(bw == 0)return 0;
	return (unsigned long)EIGRP_CLASSIC_SCALE * EIGRP_BANDWIDTH / bw;
}

unsigned long classic_scale_delay(unsigned long microseconds){
	if(microseconds == EIGRP_UNREACHABLE)return EIGRP_UNREACHABLE;
	return (unsigned long)EIGRP_CLASSIC_SCALE  * microseconds / 10;
}

int fill_sequence_tlv(char *buffer, struct eigrp_proccess *proc){
	int len = 4;
	hash_collection *col;
	neighbour *n;

	col = prepare(proc->neighbours);
	while( (n = next(col)) != NULL){
		if(!linkedlist_isempty(&n->packet_queue)){
			buffer[len++] = 4;
			memcpy(&buffer[len],&n->address,sizeof(n->address));
			len += 4;
		}
	}
	


	//tlv type and lenght
	buffer[0] = 0x00;
	buffer[1] = 0x03;
	buffer[2] = (len >> 8)	& 0xFF; 
	buffer[3] = len 	& 0xFF;
	
	return len;
}

tlv_ip4_internal *create_interal_route_tlv(route *r, int flags){

	int byte_len = ((r->prefix -1)/8)+1;
	tlv_ip4_internal *tlv = malloc(sizeof(tlv_ip4_internal));
	memset(tlv,0,sizeof(tlv_ip4_internal));
	tlv->type = htons(0x0102);
	tlv->length = htons(25 + byte_len);
	tlv->nexthop = htonl(0x00000000);
	tlv->scaled_delay = htonl(classic_scale_delay(r->delay));
	tlv->scaled_bw = htonl(classic_scale_bandwidth(r->bandwidth));

	tlv->mtu_3 = r->sender->interface->mtu & 0xFF;
	tlv->mtu_2 = (r->sender->interface->mtu >> 8) & 0xFF;
	tlv->mtu_1 = (r->sender->interface->mtu >> 16) & 0xFF;

	tlv->hop_count = r->hop;
	tlv->reliability = r->reliability;
	tlv->load = r->load;
	tlv->route_tag = r->route_tag;
	tlv->flags = flags;
	tlv->prefix = r->prefix;
	if(byte_len>=1)tlv->pnt_var_addr1= r->dest & 0xFF;
	if(byte_len>=2)tlv->pnt_var_addr2= (r->dest >>8) & 0xFF;
	if(byte_len>=3)tlv->pnt_var_addr3= (r->dest >>16) & 0xFF;
	if(byte_len>=4)tlv->pnt_var_addr4= (r->dest >>24) & 0xFF;
	
	return tlv;
}

void addtlv(packetv4_param *packet, void* tlv,int len){
	if(packet->buffer_len + len > PACKET_LENGTH)
		return;
	memcpy(&packet->buffer[packet->buffer_len],tlv,len);	
	packet->buffer_len += len;
}

void auto_packet_split(neighbour *n,linkedlist *tlvs,int opcode,int flags){
	int mtu = n->interface->mtu;
	mtu *= 0.8;

	if(mtu < LEAST_MTU)
		mtu = LEAST_MTU;
	
	while(!linkedlist_isempty(tlvs)){
		packetv4_param *packet = create_empty_packet(opcode,flags, n->sin);

		while(!linkedlist_isempty(tlvs)){
			char *index = linkedlist_getfirst(tlvs);
			int type = index[1] | index[0] << 8;
			if(type == 0x0102){
				if(packet->buffer_len + sizeof(tlv_ip4_internal) > mtu) break;
				tlv_ip4_internal *param = (tlv_ip4_internal *)index;
				int byte_len = ((param->prefix -1)/8)+1;
				//tlv assumes destination is 1 byte so we subtract it and add the correct
				addtlv(packet,param,sizeof(tlv_ip4_internal)-4+byte_len-3); //-3 is struct?
			}
		}

		linkedlist_addtail(&n->packet_queue,packet);
	}
}

packetv4_param *create_empty_packet(int opcode,int flags, struct sockaddr_in sin){
	//The packet is gonna be empty since the header is created at the end and we have no tlvs
	int packet_len = sizeof(struct eigrphdr);
	char *buffer = malloc(PACKET_LENGTH);
	memset(buffer,0,PACKET_LENGTH);

	packetv4_param *packet = malloc(sizeof(packetv4_param));
	packet->buffer = buffer;
	packet->buffer_len = packet_len;
	packet->flags = flags;
	packet->sin = sin;
	packet->opcode = opcode;
	packet->seq_num = 0;

	return packet;
}

void create_eigrp_header(char* buffer, int packet_len, int opcode, int auto_sys_number, int seqnum, int acknum, int flags){
	struct eigrphdr *eigrphd = (struct eigrphdr*)buffer;
	eigrphd->version = VERSION;
	eigrphd->opcode = opcode;
	eigrphd->checksum = 0;
	eigrphd->flags = htonl(flags);
	eigrphd->seqnum = htonl(seqnum);
	eigrphd->acknum = htonl(acknum);
	eigrphd->router_id = 0;
	eigrphd->autonomous_sys_number = htons(auto_sys_number);

	//Now that the packet is filled we should override the checksum
	eigrphd->checksum =  htons(checksum(buffer,packet_len));
}

char *create_hello_packet(int* packet_len, struct eigrp_proccess *proc){
	*packet_len = sizeof(struct eigrphdr) + sizeof(struct tlv_parameter_type) + sizeof(struct tlv_version_type);
	char *buffer = malloc((*packet_len));
		
	struct tlv_parameter_type *param_type =  (struct tlv_parameter_type*)(buffer + sizeof(struct eigrphdr));
	param_type->type = htons(0x0001);
	param_type->length = htons(0x000C);
	param_type->k1 = proc->k1;
	param_type->k2 = proc->k2;
	param_type->k3 = proc->k3;
	param_type->k4 = proc->k4;
	param_type->k5 = proc->k5;	
	param_type->k6 = proc->k6;
	param_type->holdtime = htons(proc->holdtime);
	
	struct tlv_version_type *version_type = (struct tlv_version_type*)(buffer + sizeof(struct eigrphdr) + sizeof(struct tlv_parameter_type));
	version_type->type = htons(0x0004);
	version_type->length = htons(0x0008);
	version_type->os_version = htons(OS_VERSION);
	version_type->eigrp_version = htons(EIGRP_VERSION);

	create_eigrp_header(buffer, *packet_len, OPCODE_HELLO, proc->proccess_id, 0 , 0, 0);

	return buffer;
}

//At the function below the route structure has the values from the tlv received which means that when passing them further
//we have to find the values that will be passed based on the interface the route was found (not the one we will be sending
//the packet). E.x. acc_delay,min_bw, etc. If we DONT do it we will be adevertizing the route as our eigrp DOESN'T exists

void queue_sended_multicast_packet(struct eigrp_proccess *proc, packetv4_param *packet){
	hash_collection *col;
	neighbour *n;

	printf("Queueing Multicast Packet to neighbours\n");

	col = prepare(proc->neighbours);
	while( (n = next(col)) != NULL){

		if(n->is_active == false){
			printf("Inactive Neighbour skipping\n");
			continue;
		}

		packetv4_param *new_packet = malloc(sizeof(packetv4_param));
		new_packet->buffer = malloc(sizeof(PACKET_LEN));
		memcpy(new_packet->buffer,packet->buffer,packet->buffer_len);
		new_packet->buffer_len = packet->buffer_len;
		new_packet->flags = packet->flags;
		new_packet->seq_num = packet->seq_num;
		new_packet->opcode = packet->opcode;
		new_packet->sin =  n->sin;
	}
}

void add_query_tlv_multicast(struct eigrp_proccess *proc, route *r, int flags){
	printf("Adding query tvl to multicast queue.\n");
	tlv_ip4_internal *tvl = create_interal_route_tlv(r, flags);
	linkedlist_addtail(&proc->query_tlv_queue,tvl);
}

void add_update_tlv_multicast(struct eigrp_proccess *proc, route *r, int flags){
	printf("Adding update tvl to multicast queue.\n");
	tlv_ip4_internal *tvl = create_interal_route_tlv(r, flags);
	linkedlist_addtail(&proc->update_tlv_queue,tvl);
}

void add_reply_tlv_neighbour(neighbour *n,route *r, int flags){
	printf("Adding reply n\n");
	tlv_ip4_internal *tvl = create_interal_route_tlv(r, flags);
	linkedlist_addtail(&n->reply_tlv_queue,tvl);
}

void add_query_tlv_neighbour(neighbour *n,route *r, int flags){
	printf("Adding query n\n");
	tlv_ip4_internal *tvl = create_interal_route_tlv(r, flags);
	linkedlist_addtail(&n->query_tlv_queue,tvl);
}

void send_siaquery_neighbour(neighbour *n,route *r, int packet_flag, int route_flag){
	printf("Sending siaquery.\n");
	packetv4_param *packet = create_empty_packet(OPCODE_SIAQUERY,packet_flag, n->sin);
	tlv_ip4_internal *tlv = create_interal_route_tlv(r, route_flag);
	int byte_len = ((tlv->prefix -1)/8)+1;
	addtlv(packet,tlv,sizeof(tlv_ip4_internal)-4+byte_len-3);
	linkedlist_addtail(&n->packet_queue,packet);
	printf("Siaquery added to packet queue.\n");
}

void send_siareply_neighbour(neighbour *n,route *r, int packet_flag, int route_flag){
	printf("ERROR:Not Implemented\n");
}

void create_mutlticast_packet(struct eigrp_proccess *proc,linkedlist *tlvs,int opcode,int flags){
	printf("Creating Multicast Packet.\n");
	if(linkedlist_isempty(tlvs))return;

	printf("test1\n");
	
	struct sockaddr_in sin;
	
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = inet_addr("224.0.0.10");

	packetv4_param *packet = create_empty_packet(opcode,flags, sin);
	printf("test2\n");

	while(!linkedlist_isempty(tlvs)){
		char *index = linkedlist_getfirst(tlvs);
		int type = index[1] | index[0] << 8;
		printf("TLVType:%d\n",type);
		if(type == 0x0102){
			printf("k\n");
			tlv_ip4_internal *param = (tlv_ip4_internal *)index;
			int byte_len = ((param->prefix -1)/8)+1;
			//tlv assumes destination is 1 byte so we subtract it and add the correct
			addtlv(packet,param,sizeof(tlv_ip4_internal)-4+byte_len-3); //-3 is struct?
		}
	}

	printf("test3\n");

	linkedlist_addtail(&proc->multicast_queue,packet);

	printf("test4\n");
}

void create_packets_from_queues(struct eigrp_proccess *proc){
	hash_collection *col;
	neighbour *n;

	create_mutlticast_packet(proc,&proc->query_tlv_queue,OPCODE_QUERY,0);
	create_mutlticast_packet(proc,&proc->update_tlv_queue,OPCODE_UPDATE,0);

	col = prepare(proc->neighbours);
	while( (n = next(col)) != NULL){
		auto_packet_split(n,&n->reply_tlv_queue,OPCODE_REPLY,n->reply_flag);
		auto_packet_split(n,&n->query_tlv_queue,OPCODE_QUERY,n->query_flag);
		auto_packet_split(n,&n->update_tlv_queue,OPCODE_UPDATE,n->update_flag);
		//Reset them after use
		n->reply_flag = 0;
		n->query_flag = 0;
		n->update_flag = 0;
	}
}

void create_packets_for_neighbour(neighbour *n){
	auto_packet_split(n,&n->reply_tlv_queue,OPCODE_REPLY,n->reply_flag);
	auto_packet_split(n,&n->query_tlv_queue,OPCODE_QUERY,n->query_flag);
	auto_packet_split(n,&n->update_tlv_queue,OPCODE_UPDATE,n->update_flag);
}
