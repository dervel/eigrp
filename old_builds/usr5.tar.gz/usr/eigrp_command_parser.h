
extern int parse_commands(char *buff, int len);
