#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <pthread.h>
#include <poll.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

#include "config.h"
#include "telnet.h"
#include "eigrp_structs.h"
#include "utils.h"
#include "eigrp_base.h"
#include "packet_factory.h"

static bool running;
static pthread_t telnet;
static telnet_client *telnet_c;
static bool authed;

//Line Preparing
void options_help(char *token, char options[][20],int option_size){
	
	char last = token[strlen(token)-1];
	if(last == '?'){
		int k;
		char *search = strsep(&token,"?");
		sbuffer *b = malloc(sizeof(sbuffer));
		b->len =0;
		for(k=0;k<option_size;k++){
			if(compare(search,options[k])){
				int i = sprintf(b->s, "%s   ",options[k]);
				bwrite(b,b->s,i);
			}
		}
		bwrite(b,"\r\n",4);
		telnet_printf(telnet_c->client,b->buffer,b->len);
	}
}

void show_ip_eigrp_interfaces_print(sbuffer *buffer, struct eigrp_proccess *proc){
	int n = sprintf(buffer->s,"IP-EIGRP Interfaces for process %d\r\n\r\n\t\t\tXmit Queue\tMean\tPacing Time\tMulticast\tPending\r\nInterfaces\tPeers\tUn/Reeliable\tSRTT\tUn/Reliable\tFlow Timer\tRoutes\r\n", proc->proccess_id);
	bwrite(buffer,buffer->s,n);
	hash_collection *col = get_interfaces();
	interface *iff;
	while( (iff=next(col)) != NULL){
		//Finding peers
		int peers =0;
		hash_collection *col1 = prepare(proc->neighbours);
		neighbour *n;
		while( (n = next(col1)) != NULL){
			if(iff->index == n->interface->index)peers++;
		}
		//Xmit Queues
		int reliable_packets = proc->multicast_queue.size;
		int k = sprintf(buffer->s,"%s\t\t%d\t\t%d/%d\t%d\t\t%d/%d\t%d\t\t%d\r\n",iff->name,peers,0,reliable_packets,1234,0,10,0,0);
		bwrite(buffer,buffer->s,k);
	}
}

void show_ip_eigrp_neighbors_print(sbuffer *buffer, struct eigrp_proccess *proc){
	int i = sprintf(buffer->s,"IP-EIGRP Neighbors for process %d\r\n\r\nAddress\t\tInterface\tHoldtime\tUptime\tQ\tSeq\tSRTT\tRTO\r\n\t\t\t\t(secs)\t\t(h:m:s)\tCount\tNum\t(ms)\t(ms)\r\n",proc->proccess_id);
	bwrite(buffer,buffer->s,i);
	hash_collection *col = prepare(proc->neighbours);
	neighbour *n;
	while( (n=next(col)) != NULL){
		char *time = time_format(current_timestamp()-n->discovery_time);
		int k = sprintf(buffer->s,"%s\t%s\t\t%lld\t\t%s\t%d\t%d\t%lld\t%d\r\n",ip4_tochar(n->address),n->interface->name,n->holdtime/1000,time,n->packet_queue.size,n->pending_ack,n->srtt%1000,0);
		bwrite(buffer,buffer->s,k);
	}
}

void show_ip_eigrp_traffic_print(sbuffer *buffer, struct eigrp_proccess *proc){
	int i = sprintf(buffer->s,"IP-EIGRP Traffic Statistics for process %d\r\n\tHellos sent/received: %d/%d\r\n\tUpdates sent/received: %d/%d\r\n\tQueries sent/received: %d/%d\r\n\tReplies sent/received: %d/%d\r\n\tAcks sent/received: %d/%d\r\n\tSIA-Queries sent/received: %d/%d\r\n\tSIA-Replies sent/received: %d/%d\r\n"
		,proc->proccess_id,
		proc->stats.packets_sent[OPCODE_HELLO],proc->stats.packets_received[OPCODE_HELLO],
		proc->stats.packets_sent[OPCODE_UPDATE],proc->stats.packets_received[OPCODE_UPDATE],
		proc->stats.packets_sent[OPCODE_QUERY],proc->stats.packets_received[OPCODE_QUERY],
		proc->stats.packets_sent[OPCODE_REPLY],proc->stats.packets_received[OPCODE_REPLY],
		proc->stats.acks_sent,proc->stats.acks_received,
		proc->stats.packets_sent[OPCODE_SIAQUERY],proc->stats.packets_received[OPCODE_SIAQUERY],
		proc->stats.packets_sent[OPCODE_SIAREPLY],proc->stats.packets_received[OPCODE_SIAREPLY]
			);
	bwrite(buffer,buffer->s,i);
	
}

void show_ip_eigrp_topology_print(sbuffer *buffer, struct eigrp_proccess *proc){
	int i = sprintf(buffer->s,
	"IP-EIGRP Topology Table for process %d\r\n\r\n"
	"Codes: P - Passive, A - Active, U - Update, Q - Query, R - Reply,\r\n"
	"\tr - Reply status\r\n\r\n",proc->proccess_id);
	bwrite(buffer,buffer->s,i);

	//Network
	hash_collection *col = prepare(proc->topology_support);
	struct topology_support* support;
	while((support=next(col)) != NULL){
		//Prefix
		struct topology_route *tr;
		hash_collection *col2 = prepare(support->topology_route);

		while((tr=next(col2)) != NULL){
			char *code = (tr->route_state == PASSIVE_STATE ? "P" : "A");
			int successors = count_feasible_successors(tr);
			int k = sprintf(buffer->s,"%s %s\\%d, %d successors, FD is %d\r\n", code, ip4_tochar(tr->dest), tr->prefix, successors, tr->feasible_distance);
			bwrite(buffer,buffer->s,k);
			for(i=0;i<tr->routes.size;i++){
				route *r = vector_get(&tr->routes,i);
				if(r->delay == EIGRP_UNREACHABLE) continue;
				if(r->is_proccess_generated){
					k = sprintf(buffer->s,"\tvia Connected, %s\r\n", r->sender->interface->name);
					bwrite(buffer,buffer->s,k);
				}else{
					k = sprintf(buffer->s,"\tvia %s (%d/%d), %s\r\n", ip4_tochar(r->sender->address), r->feasible_distance, r->reported_distance, r->sender->interface->name);
					bwrite(buffer,buffer->s,k);
				}
			}
		}
	}
}

void show_key_chain_print(sbuffer *buffer, key_chain *chain){
	int i = sprintf(buffer->s, "Key-chain %s:\r\n",chain->name);
	bwrite(buffer,buffer->s,i);

	hash_collection *col = prepare(chain->keys);
	key *k;
	while( (k=next(col)) != NULL){
		i = sprintf(buffer->s, "\tkey %ld -- text \"%s\"\r\n"
		"\t\taccept lifetime (always valid) - (always valid) [valid now]\r\n"
		"\t\tsend lifetime (always valid) - (always valid) [valid now]\r\n"
		, k->indentifier,k->password);
		bwrite(buffer,buffer->s,i);
	}
}

//Command Parsing
void show_ip_eigrp_topology_command(char *line){
	char *token;
	printf("topology:%s\n",line);
	token = strsep(&line," ");

	if(token == NULL){
		sbuffer *buffer = malloc(sizeof(sbuffer));
		buffer->len = 0;
		hash_collection *col = get_proccesses();
		struct eigrp_proccess *proc;
		while( (proc=next(col)) != NULL){
			show_ip_eigrp_topology_print(buffer,proc);
		}
		telnet_printf(telnet_c->client,buffer->buffer,buffer->len);
	}
	if(token){
		//Show topology for specific proccess
		int ret = strtol(token,0,10);
		if(ret != 0){
			struct eigrp_proccess *proc = get_eigrp_proccess(ret);
			if(proc != NULL){
				sbuffer *buffer = malloc(sizeof(sbuffer));
				buffer->len = 0;
				show_ip_eigrp_topology_print(buffer,proc);
				telnet_printf(telnet_c->client,buffer->buffer,buffer->len);
			}
		}
	}
}

void show_ip_eigrp_neighbors_command(char *line){
	char *token;
	printf("neighbors:%s\n",line);
	token = strsep(&line," ");

	if(token == NULL){
		sbuffer *buffer = malloc(sizeof(sbuffer));
		buffer->len = 0;
		hash_collection *col = get_proccesses();
		struct eigrp_proccess *proc;
		while( (proc=next(col)) != NULL){
			show_ip_eigrp_neighbors_print(buffer,proc);
		}
		telnet_printf(telnet_c->client,buffer->buffer,buffer->len);
	}
	if(token){
		//Show neighbors for specific proccess
		int ret = strtol(token,0,10);
		if(ret != 0){
			struct eigrp_proccess *proc = get_eigrp_proccess(ret);
			if(proc != NULL){
				sbuffer *buffer = malloc(sizeof(sbuffer));
				buffer->len = 0;
				show_ip_eigrp_neighbors_print(buffer,proc);
				telnet_printf(telnet_c->client,buffer->buffer,buffer->len);
			}
		}
	}
}

void show_ip_eigrp_interfaces_command(char *line){
	char *token;
	printf("interfaces:%s\n",line);
	token = strsep(&line," ");

	if(token == NULL){
		sbuffer *buffer = malloc(sizeof(sbuffer));
		buffer->len = 0;
		hash_collection *col = get_proccesses();
		struct eigrp_proccess *proc;
		while( (proc=next(col)) != NULL){
			show_ip_eigrp_interfaces_print(buffer,proc);
		}
		telnet_printf(telnet_c->client,buffer->buffer,buffer->len);
	}
	if(token){
		//Show interfaces for specific proccess
		int ret = strtol(token,0,10);
		if(ret != 0){
			struct eigrp_proccess *proc = get_eigrp_proccess(ret);
			if(proc != NULL){
				sbuffer *buffer = malloc(sizeof(sbuffer));
				buffer->len = 0;
				show_ip_eigrp_interfaces_print(buffer,proc);
				telnet_printf(telnet_c->client,buffer->buffer,buffer->len);
			}
		}
	}
}

void show_ip_eigrp_traffic_command(char *line){
	char *token;
	printf("traffic:%s\n",line);
	token = strsep(&line," ");

	if(token == NULL){
		sbuffer *buffer = malloc(sizeof(sbuffer));
		buffer->len = 0;
		hash_collection *col = get_proccesses();
		struct eigrp_proccess *proc;
		while( (proc=next(col)) != NULL){
			show_ip_eigrp_traffic_print(buffer,proc);
		}
		telnet_printf(telnet_c->client,buffer->buffer,buffer->len);
	}
	if(token){
		//Show traffic for specific proccess
		int ret = strtol(token,0,10);
		if(ret != 0){
			struct eigrp_proccess *proc = get_eigrp_proccess(ret);
			if(proc != NULL){
				sbuffer *buffer = malloc(sizeof(sbuffer));
				buffer->len = 0;
				show_ip_eigrp_traffic_print(buffer,proc);
				telnet_printf(telnet_c->client,buffer->buffer,buffer->len);
			}
		}
	}
}

void show_ip_eigrp_command(char *line){
	char *token;
	printf("eigrp:%s\n",line);
	token = strsep(&line," ");

	char options[][20] = {"interfaces","neighbors","topology","traffic"};
	options_help(token,options,4);

	if(equals(token,"interfaces")){
		show_ip_eigrp_interfaces_command(line);
	}
	if(equals(token,"neighbors")){
		show_ip_eigrp_neighbors_command(line);
	}
	if(equals(token,"topology")){
		show_ip_eigrp_topology_command(line);
	}
	if(equals(token,"traffic")){
		show_ip_eigrp_traffic_command(line);
	}
}

void show_ip_command(char *line){
	char *token;
	printf("ip:%s\n",line);
	token = strsep(&line," ");

	char options[][20] = {"eigrp"};
	options_help(token,options,2);

	if(equals(token,"eigrp")){
		show_ip_eigrp_command(line);
	}
}

void show_ipv6_command(char *line){

	printf("ipv6:%s\n",line);

	
}

void show_key_chain_command(char *line){
	char *token;
	printf("chain:%s\n",line);
	token = strsep(&line," ");

	if(token == NULL){
		sbuffer *buffer = malloc(sizeof(sbuffer));
		buffer->len = 0;
		hash_collection *col = prepare(get_global_vars()->key_chains);
		key_chain *chain;
		while( (chain=next(col)) != NULL){
			show_key_chain_print(buffer,chain);
		}
		telnet_printf(telnet_c->client,buffer->buffer,buffer->len);
	}
	if(token){
		key_chain *chain = get_key_chain(token);
		//Show key chain for specific proccess
		if(chain != NULL){
			sbuffer *buffer = malloc(sizeof(sbuffer));
			buffer->len = 0;
			show_key_chain_print(buffer,chain);
			telnet_printf(telnet_c->client,buffer->buffer,buffer->len);
		}
	}
}

void show_key_command(char *line){
	char *token;
	printf("key:%s\n",line);
	token = strsep(&line," ");

	char options[][20] = {"chain"};
	options_help(token,options,1);

	if(equals(token,"chain")){
		show_key_chain_command(line);
	}
}

void show_command(char *line){
	char *token;
	printf("show:%s\n",line);
	token = strsep(&line," ");

	char options[][20] = {"ip","ipv6","key"};
	options_help(token,options,3);

	if(equals(token,"ip")){
		show_ip_command(line);
	}
	if(equals(token,"ipv6")){
		show_ipv6_command(line);
	}
	if(equals(token,"key")){
		show_key_command(line);
	}
}

void handle_command(const char *buffer, int len){
	char *token;
	//Do not copy the last 2 character as they are part of telnet and not the actual command
	char *line = malloc(len-2);
	memcpy(line,buffer,len-2);
	line[len-2] = 0;
	token = strsep(&line," ");

	char options[][20] = {"show","enable"};
	options_help(token,options,2);

	if(equals(token,"show")){
		show_command(line);
	}
	if(equals(token,"enable")){
		authed = true;
	}



	sbuffer *b = malloc(sizeof(sbuffer));
	b->len = 0;
	char *hostname = get_global_vars()->hostname;
	bwrite(b, hostname,strlen(hostname));
	authed ? bwrite(b,"#",1) : bwrite(b,">",1);
	telnet_printf(telnet_c->client,b->buffer,b->len);
	free(b);
}


//Telnet Functions

void stop_telnet(){
	running = false;
}

static void _send(int sock, const char *buffer, size_t size){
	int rs;
	while(size > 0){
		if((rs = send(sock,buffer,size,0)) == -1){
			if(errno != EINTR && errno != ECONNRESET){
				printf("send() failed:%s\n",strerror(errno));
			} else{
				return;
			}
		}else if(rs==0){
			printf("send() unexpectedly returned 0\n");
		}
		buffer += rs;
		size -= rs;
	}
}

void telnet_event_handler(telnet_t *telnet, telnet_event_t *ev, void *user_data){
	//telnet_client *user = (telnet_client*)user_data;

	switch(ev->type){
		case TELNET_EV_DATA:
			handle_command(ev->data.buffer, ev->data.size);
			break;
		case TELNET_EV_SEND:
			_send(telnet_c->sock, ev->data.buffer, ev->data.size);
			break;
		case TELNET_EV_IAC:
		case TELNET_EV_WILL:
		case TELNET_EV_WONT:
		case TELNET_EV_DO:
		case TELNET_EV_DONT:
		case TELNET_EV_SUBNEGOTIATION:
		case TELNET_EV_COMPRESS:
		case TELNET_EV_ZMP:
		case TELNET_EV_TTYPE:
		case TELNET_EV_ENVIRON:
		case TELNET_EV_MSSP:
		case TELNET_EV_WARNING:
		case TELNET_EV_ERROR:
			break;
		
	}
}

int init_telnet_server(){
	int ret;

	ret = pthread_create(&telnet,NULL ,telnet_thread ,NULL);
	if(ret){
		printf("ERROR:Error starting telnet.\n");
	}

	return 0;
}

void *telnet_thread(void *ptr){

	int rs;
	int listen_sock;
	char buffer[512];
	socklen_t addrlen;
	struct sockaddr_in addr;
	struct pollfd pfd[1];

	running = true;

	telnet_c = malloc(sizeof(telnet_client));

	static const telnet_telopt_t my_telopts[] = {
		{ TELNET_TELOPT_ECHO,      TELNET_WILL, TELNET_DO },
		{ -1, 0, 0 }
	};

	while(running){

		authed = false;		
		if((listen_sock = socket(AF_INET, SOCK_STREAM, 0)) == -1){
			printf("Error creating telnet.\n");
			return NULL;
		}

		rs = 1;
		setsockopt(listen_sock, SOL_SOCKET, SO_REUSEADDR, (void*)&rs, sizeof(rs));

		memset(&addr, 0, sizeof(addr));
		addr.sin_family = AF_INET;
		addr.sin_addr.s_addr = INADDR_ANY;
		addr.sin_port = htons(11203);

		if(bind(listen_sock, (struct sockaddr*)&addr, sizeof(addr)) == -1){
			printf("Error binding telnet socket.\n");
			return NULL;
		}

		if(listen(listen_sock, 1) == -1){
			printf("Error listening.\n");
			return NULL;
		}

		addrlen = sizeof(addr);
		if((telnet_c->sock = accept(listen_sock, (struct sockaddr*)&addr, &addrlen)) == -1){
			printf("Error accept().\n");
			return NULL;
		}

		printf("TELNET CONNECTION RECEIVED.\n");
		close(listen_sock);

		telnet_c->client = telnet_init(my_telopts,telnet_event_handler,0,telnet_c);
		
		sbuffer *b = malloc(sizeof(sbuffer));
		b->len = 0;
		char *hostname = get_global_vars()->hostname;
		bwrite(b, hostname,strlen(hostname));
		authed ? bwrite(b,"#",1) : bwrite(b,">",1);
		telnet_printf(telnet_c->client,b->buffer,b->len);
		free(b);

		memset(pfd, 0,sizeof(pfd));
		pfd[0].fd = telnet_c->sock;
		pfd[0].events = POLLIN;

		while(poll(pfd,1,-1) != -1 && running){
			if(pfd[0].revents & POLLIN){
				if((rs =recv(telnet_c->sock, buffer, sizeof(buffer),0)) > 0){
					telnet_recv(telnet_c->client, buffer, rs);
				}
			} else if (rs == 0){
				printf("TELNET CLIENT DISCONNECTED\n");
				break;
			}
		}

	}

	telnet_free(telnet_c->client);
	close(telnet_c->sock);
	free(telnet_c);

	return NULL;

}
