#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>

#include "collection.h"
#include "hashtable.h"

void *next(hash_collection* collection){

	if(collection->current != NULL && collection->current->next != NULL){
		collection->current = collection->current->next;
		return collection->current->value;
	}

	int i;	
	for(i=collection->table_index;i<collection->table->size;i++){
		if(collection->table->table[i] == NULL)
			continue;

		collection->current = collection->table->table[i];
		collection->table_index = i+1;
		return collection->current->value;

		
	}
	free(collection);
	return NULL;
}

hash_collection *prepare(hash_table_t *table){
	hash_collection *col = malloc(sizeof(hash_collection));
	col->table = table;
	col->table_index = 0;
	col->current = NULL;
	return col;
}
