#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include "linkedlist.h"

void linkedlist_addtail(linkedlist *list ,void* data){
	
	node *new_node;
	new_node = malloc(sizeof(node));
	new_node->data = data;
	new_node->next = NULL;

	if(list->first == NULL){
		list->first = new_node;
		list->last = new_node;
	}else{
		list->last->next = new_node;
		list->last = new_node;
	}
	list->size++;

}

void linkedlist_init(linkedlist *list){
	list->first = NULL;
	list->last = NULL;
	list->size =0;
}

void *linkedlist_getfirst(linkedlist *list){
	if(list->first == NULL){
		return NULL;
	}

	node *ret = list->first;
	list->first = ret->next;
	if(list->first==NULL)
		list->last = NULL;

	void* data = ret->data;
	free(ret);
	list->size--;
	return data;
}

void *linkedlist_peekfirst(linkedlist *list){
	if(list->first == NULL){
		return NULL;
	}

	return list->first->data;
}

bool linkedlist_isempty(linkedlist *list){
	return (list->first == NULL);
}

void linkedlist_free(linkedlist *list){
	
	node *current;
	current = list->first;

	while(current!=NULL){
		node *temp = current;
		current=current->next;
		free(temp);
	}
}
