#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <string.h>

#include "eigrp_command_parser.h"
#include "eigrp_base.h"
#include "config.h"
#include "netlink.h"
#include "utils.h"

int main(){
	
	printf("Starting Eigrp.\n");

	//Clean old routes
	printf("Cleaning old routes.\n");
	remove_routes_by_protocol(RTPROT_EIGRP);

	//LOAD CONFIGURATION
	printf("Loading configuration file.\n");
	FILE *fp = fopen("./conf", "r");
	fseek(fp, 0, SEEK_END);
	long fsize = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	
	char *buf = malloc(fsize+1);
	fread(buf, fsize, 1 ,fp);
	fclose(fp);

	pre_init();
	parse_commands(buf, sizeof(buf));
	post_init();

	start_interface_state_listener();

	char p[40];
	scanf("%s",p);
	while(!compare("exit",p)){
		if(compare(p,"rm"))
			send_query();

		scanf("%s",p);
	}

	
	shutdown_eigrp();
	free_array();
	return 0;
}
