#define _GNU_SOURCE
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <ifaddrs.h>
#include <net/if.h>
#include <netdb.h>
#include <limits.h>

#include "eigrp_structs.h"
#include "eigrp_command_parser.h"
#include "eigrp_base.h"
#include "utils.h"
#include "hashtable.h"
#include "vector.h"
#include "collection.h"

static int active_proccess_id = -1; //A negative value means no eigrp proccess is selected for configuration
static int active_interface_index = -1; //A negative value mean no interface is selected for configuration

static int proccesses=0,max_id=0;
static keychain_info *active_chain= NULL;
static key_info *active_key = NULL;

static hash_table_t *proccess_list;
static hash_table_t *interface_list;
static hash_table_t *keychain_list;

int change_active_interface(char *line_token){
	char *token;
	token = strsep(&line_token," ");
	if(token == NULL){
		printf("Could not find inteface name.\n");
		return -1;
	}
	
	char *name = token;
	int index = if_nametoindex(name);
	if(index == 0){
			printf("Error getting the index of the interface %s.\n",name);
			return -1;
	}

	iff_info *info = hashtable_getitem(interface_list, index);
	if(info == NULL){
		iff_info *new_iff = malloc(sizeof(iff_info));

		new_iff->index = index;
		new_iff->name = name;
		new_iff->delay = 100000;
		new_iff->bandwidth = 100000;
		new_iff->eigrp_encryption = create_hash_table(10);

		hashtable_additem(interface_list,new_iff,index);
		info = new_iff;
		printf("Interface %s registered for initialization.\n",name);
	}

	active_interface_index = index;

	/*
	//If the interface was initialized again just set the active index and we ok
	interface *active_if = get_interface(index);
	if(active_if != NULL){
		active_interface_index = index;
		return 0;
	}

	//If it's not initialized we will have to initialize it and add it to the interface list

	struct ifaddrs *addrs, *tmp, *next;	
	char host[NI_MAXHOST];
	int ret;

	interface *new_if = malloc(sizeof(interface));
	new_if->name = name;
	new_if->ip4_init = false;
	new_if->ip6_init = false;
	new_if->ifa_addr_ip4 = NULL;
	new_if->ifa_addr_ip6 = NULL;

	getifaddrs(&addrs);
	next = addrs;

	while(next){
		tmp = next;
		next = next->ifa_next;

		if(!compare(tmp->ifa_name, name)){
			continue;
		}

		int family = tmp->ifa_addr->sa_family;

		//If it is NOT one of the follow families then continue
		if(!(family == AF_INET || family == AF_INET6))
			continue;

		if(family == AF_INET){
			//Address
			struct sockaddr *temp = malloc(sizeof(struct sockaddr));
			memcpy(temp,tmp->ifa_addr,sizeof(struct sockaddr));
			new_if->ifa_addr_ip4 = (struct sockaddr_in*)temp;
			
			//Mask
			struct sockaddr *temp1 = malloc(sizeof(struct sockaddr));
			memcpy(temp1,tmp->ifa_netmask,sizeof(struct sockaddr));
			new_if->ifa_netmask_ip4 = (struct sockaddr_in*)temp1;
		}else if(family == AF_INET6){
			//Address
			struct sockaddr *temp = malloc(sizeof(struct sockaddr));
			memcpy(temp,tmp->ifa_addr,sizeof(struct sockaddr));
			new_if->ifa_addr_ip6 = (struct sockaddr_in6*)temp;
			//Mask
			struct sockaddr *temp1 = malloc(sizeof(struct sockaddr));
			memcpy(temp1,tmp->ifa_netmask,sizeof(struct sockaddr));
			new_if->ifa_netmask_ip6 = (struct sockaddr_in6*)temp1;
		}

		new_if->delay = 100000;
		new_if->bandwidth = 100000;

		new_if->index = index;
		if(new_if->index == 0){
			printf("Error getting the index of the interface %s.\n",name);
		}
	}

	init_interface(new_if);
	printf("Interface %s is ready for use.\n",new_if->name);
	active_interface_index = index;
	
	freeifaddrs(addrs);
	*/

	return 0;
}

int get_eigrp_id(char *line_token){
	char *token;
	//We expect eigrp next if not throw a message.
	token = strsep(&line_token," ");
	if(token == NULL || !compare(token, "eigrp")){
		printf("Error parsing router command.\n");
		return -1; //Negative return means smth went wrong
	}

	//Token will now have the number of the eigrp proccess
	token = strsep(&line_token," ");
	if(token == NULL){
		printf("Could not find eigrp id.\n");
		return -1;
	}
	int ret = strtol(token,0,10); //ret is the eigrp id
	if(ret == 0){
		printf("Could not convert id to number.\n");
		return -1;
	}


	proccess *proc = hashtable_getitem(proccess_list,ret);
	if(proc == NULL){

		proccess *new_proc = malloc(sizeof(proccess));
		new_proc->id = ret;
		new_proc->k1 = 1;
		new_proc->k2 = 0;
		new_proc->k3 = 1;
		new_proc->k4 = 0;
		new_proc->k5 = 0;
		new_proc->k6 = 0;

		vector_init(&new_proc->passive_ifs);
		vector_init(&new_proc->advertised_networks);

		hashtable_additem(proccess_list,new_proc,ret);
		printf("Eigrp proccess %d registered.\n",ret);

		if(ret > 0) proccesses++;
		if(ret > max_id) max_id = ret;
	}

	active_proccess_id = ret;
	
	return ret;
}

//The command to parse the work of the line cuts it from the string so we have to pass the initial command
//or we will be missing the first word from the line
int parse_proccess_commands(char *current, char *line_token){
	char *token;
	int ret;

	proccess *proc = hashtable_getitem(proccess_list,active_proccess_id);	
	if(proc == NULL){
		printf("Somehow you tryed to set options for a NULL proccess.\n");
		return -1;
	}

	if(compare(current,"network")){
		net_info *adv_net = malloc(sizeof(net_info));
		//Network Address
		token = strsep(&line_token," ");
		//char *temp = token;
		adv_net->network = ip4_toint(token);
		if(adv_net->network == -1){
			printf("Invalid network address %s.\n", token);
			free(adv_net);
			return -1;
		}
		//Mask
		token = strsep(&line_token," ");
		adv_net->prefix = wildcard_to_prefix(token);
		if(adv_net->prefix == -1){
			printf("Invalid subnet mask or wildcard %s.\n",token);
			free(adv_net);
			return -1;
		}
		vector_add(&proc->advertised_networks,adv_net);
	}

	if(compare(current,"passive-interface")){
		token = strsep(&line_token," ");
		if(token != NULL){
			vector_add(&proc->passive_ifs,token);
		}

	}

	if(compare(current,"metric")){
		token = strsep(&line_token," ");
		if(token != NULL && compare(current,"weights")){
			
			token = strsep(&line_token," ");
			ret = strtol(token,0,10); // tos
			if(ret != 0) return -1;
			token = strsep(&line_token," ");
			proc->k1 = strtol(token,0,10); // k1
			token = strsep(&line_token," ");
			proc->k2 = strtol(token,0,10); // k2
			token = strsep(&line_token," ");
			proc->k3 = strtol(token,0,10); // k3
			token = strsep(&line_token," ");
			proc->k4 = strtol(token,0,10); // k4
			token = strsep(&line_token," ");
			proc->k5 = strtol(token,0,10); // k5
			token = strsep(&line_token," ");
			proc->k6 = strtol(token,0,10); // k6
			
		}
	}

	return 0;
}

//The command to parse the work of the line cuts it from the string so we have to pass the initial command
//or we will be missing the first word from the line
int parse_interface_commands(char *current, char *line_token){

	iff_info *iff = hashtable_getitem(interface_list,active_interface_index);
	if(iff == NULL){
		printf("Somehow you tryed to set options for a NULL interface.\n");
		return -1;
	}

	char *token = strsep(&line_token," ");;
	int ret;

	if(compare(current,"bandwidth")){
		ret = strtol(token,0,10);
		iff->bandwidth = ret;
	}
	if(compare(current,"delay")){
		ret = strtol(token,0,10);
		iff->delay = ret;
	}
	if(compare(current,"ip")){
		if(equals(token,"authentication")){
			token = strsep(&line_token," ");
			if(equals(token,"mode")){
				token = strsep(&line_token," ");
				if(equals(token,"eigrp")){
					token = strsep(&line_token," ");
					int eigrp_id = strtol(token,0,10);
					token = strsep(&line_token," ");
					if(equals(token,"md5")){
						encrypt_info *encrypt = hashtable_getitem(iff->eigrp_encryption,eigrp_id);
						if(encrypt == NULL){
							encrypt = malloc(sizeof(encrypt_info));
							encrypt->keychain_name = "";
							hashtable_additem(iff->eigrp_encryption,encrypt,eigrp_id);
						}
						encrypt->eigrp_id = eigrp_id;
						encrypt->encryption = "md5";
					}
				}
			}
			if(equals(token,"key-chain")){
				token = strsep(&line_token," ");
				if(equals(token,"eigrp")){
					token = strsep(&line_token," ");
					int eigrp_id = strtol(token,0,10);
					token = strsep(&line_token," ");
					char *keychain_name = token;

					encrypt_info *encrypt = hashtable_getitem(iff->eigrp_encryption,eigrp_id);
					if(encrypt == NULL){
						encrypt = malloc(sizeof(encrypt_info));
						encrypt->encryption = "";
						hashtable_additem(iff->eigrp_encryption,encrypt,eigrp_id);
					}
					encrypt->eigrp_id = eigrp_id;
					encrypt->keychain_name = keychain_name;
				}
			}
		}
	}

	return 0;
	
}

int parse_key_commands(char *current, char *line_token){
	char *token;

	if(active_key == NULL){
		printf("Somehow you tryed to set options for a NULL key.\n");
		return -1;
	}

	if(compare(current,"key-string")){
		token = strsep(&line_token," ");
		char * p;
		long val = strtol(token,&p,10);
		char *password = strsep(&line_token," ");
		if(*p){
			active_key->password = token;
			active_key->encryption = 0;
		}else{
			if(val == 0){
				token = strsep(&line_token," ");
				active_key->password = password;
				active_key->encryption = 0;
			}
			if(val == 7){
				//TODO: this needs fixing
				//active_key->encryption = 7;
				printf("Not implemented.\n");
				return -1;
			}
		}
	}

	return 0;
}

int parse_chain_commands(char *current, char *line_token){
	char *token;	

	if(active_chain == NULL){
		printf("Somehow you tryed to set options for a NULL key chain.\n");
		return -1;
	}

	if(equals(current,"key")){
		token = strsep(&line_token," ");
		long val = strtol(token,0,10);
		if(val == LONG_MAX || val == LONG_MIN){
			printf("Could not parse indentifier for key:%s\n",token);
			return -1;
		}

		//If the key doesn't exits crate it and register it
		key_info *k = hashtable_getitem(active_chain->keys, val);
		if(k == NULL){
			key_info *new_key = malloc(sizeof(key_info));
			new_key->indentifier = val;
			new_key->encryption = 0;

			hashtable_additem(active_chain->keys,new_key,new_key->indentifier);
			k = new_key;
		}
		
		active_key = k;
	}else{
		parse_key_commands(current,line_token);
	}

	return 0;
}

int parse_commands(char *buff, int len){

	char *line_token, *token;
	//long id,ret;

	proccess_list = create_hash_table(200);
	interface_list = create_hash_table(200);
	keychain_list = create_hash_table(200);

	init_interfaces_hashtable();

	/*
	First we unscramble/order/unite the commands

	Root commands are router,interface and node refers to the commands that are used inside those,
	while 'exit' is not a root command it can be treated so because it does the same thing in all nodes

	*/
	printf("--Parsing Configuration File--\n");
	while((line_token = strsep(&buff,"\n")) != NULL){
		printf("+%s\n", line_token);

		if(strlen(line_token) == 0)
			continue;

		token = strsep(&line_token," ");
		if(token != NULL){

			//The commands router,interface,exit impact the node we have active and can be
			//used in both at the root or while in a node so we parse them indepented on that
			//we have active atm
			if(compare(token,"router")){
				active_proccess_id = get_eigrp_id(line_token);
				active_interface_index = -1;
				active_chain = NULL;
				continue;
			}

			if(compare(token,"interface")){
				change_active_interface(line_token);
				active_proccess_id = -1;
				active_chain = NULL;
				continue;
			}

			if(compare(token,"exit")){
				//Exit get you out the current node, since we can have 1 active node
				//setting both to -1 is the same as getting out of that node
				active_interface_index = -1;
				active_proccess_id = -1;
				active_chain = NULL;
				continue;
			}
			if(compare(token,"hostname")){
				char *name = strsep(&line_token," ");
				if(name != NULL) get_global_vars()->hostname = name;
				continue;
			}

			if(equals(token, "key")){
				token = strsep(&line_token," ");
				if(equals(token, "chain")){
					token = strsep(&line_token," ");
					keychain_info *chain = hashtable_getitem(keychain_list,hash(token));
					if(chain == NULL){
						keychain_info *new_chain = malloc(sizeof(keychain_info));
						new_chain->keys = create_hash_table(100);
						new_chain->name = token;
						hashtable_additem(keychain_list,new_chain,hash(token));
						chain = new_chain;
					}
					active_chain = chain;
					active_key = NULL;
					active_interface_index = -1;
					active_proccess_id = -1;
				}else{
					long val = strtol(token,0,10);
					key_info *key = hashtable_getitem(active_chain->keys,val);
					if(key == NULL){
						key_info *new_key = malloc(sizeof(key_info));
						new_key->indentifier = val;
						hashtable_additem(active_chain->keys,new_key,val);
						key = new_key;
					}
					active_key = key;
				}
				continue;
			}

			if(active_chain != NULL){
				parse_chain_commands(token,line_token);
				continue;
			}
			
			//Now based on what node we have active we send the line to the corresponded node
			if(active_proccess_id > 0){
				parse_proccess_commands(token,line_token);
				continue;
			}
			if(active_interface_index > 0){
				parse_interface_commands(token,line_token);
				continue;
			}

			//If we reached this point it means that we have not selected either a proccess or an interface
			//We will throw an error message and skip this line
			printf("Tried parse command line without having a node selected: %s\n",line_token);
			continue;

		}

	}


	printf("--Initializing Key Chains--\n");
	hash_collection *col = prepare(keychain_list);
	keychain_info *chain_info;
	while( (chain_info = next(col)) != NULL){
		init_keychain(chain_info);
		hashtable_free(chain_info->keys);
		free(chain_info);
	}

	printf("--Initializing Interfaces--\n");
	col = prepare(interface_list);
	iff_info *if_info;
	while( (if_info = next(col)) != NULL){
		init_interface(if_info);
	}

	//Initialize eigrp proccesses
	printf("--Initializing Proccesses--\n");
	//Create an optimal hashtable for eigrp usage
	if(proccesses < 50)
		proccesses = 50;
	else if(proccesses / max_id > 0.75)
		proccesses = max_id;

	printf("Eigrp proccess hashtable is of size %d.\n",proccesses);
	init_proccess_hashtable(proccesses);

	col = prepare(proccess_list);
	proccess *proc;
	while((proc=next(col))!= NULL){
		init_eigrp_proccess(proc);
	}

	//Split the commands by lines
	/*
	printf("Parsing Configuration File.\n");
	while((line_token = strsep(&buff,"\n")) != NULL){
		printf("%s\n", line_token);

		token = strsep(&line_token," ");
		if(token != NULL){
			if(compare(token,"router")){
				//We expect eigrp next if not throw a message.
				token = strsep(&line_token," ");
				if(token == NULL || !compare(token, "eigrp")){
					printf("Error parsing router command.\n");
					return -1; //Negative return means smth went wrong
				}

				//Token will now have the number of the eigrp proccess
				token = strsep(&line_token," ");
				if(token == NULL){
					printf("Could not find eigrp id.\n");
					return -1;
				}
				char *ptr;
				ret = strtol(token,0,10);
				if(ret == 0){
					printf("Could not convert id to number.\n");
					return -1;
				}
				active_proccess_id = (int)ret;
				if(!is_initialized_eigrp(ret)){
					init_eigrp_proccess(ret);
				}

			}else if(compare(token,"auto-summery")){

			}else if(compare(token,"distance")){

			}else if(compare(token,"exit")){
				
				//This command would have meaning at a real cisco router but here we will keep it only
				//for the sake of having the same commands.

				//It will just 'exit' the proccess so we wont be passing commands at a random eigrp proc
				
				active_proccess_id = -1;
			}else if(compare(token,"metric")){

			}else if(compare(token,"network")){

			}else if(compare(token,"no")){

			}else if(compare(token,"passive-interface")){
				//token will have the string description of the interface to remove
				token = strsep(&line_token," ");
				remove_interface(active_proccess_id, token);
			}else if(compare(token,"redistribute")){

			}else if(compare(token,"variance")){

			}
		}

	}*/

	hashtable_free(proccess_list);
	hashtable_free(interface_list);
	hashtable_free(keychain_list);

	return 0;
}
