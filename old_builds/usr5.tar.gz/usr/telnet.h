
#include "eigrp_structs.h"


void telnet_event_handler(telnet_t *telnet, telnet_event_t *ev, void *user_data);
int init_telnet_server();
void *telnet_thread(void *ptr);
void stop_telnet();
