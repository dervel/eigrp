#include <stdbool.h>
#include <sys/types.h>
#include <asm/byteorder.h>
#include <netinet/ip.h>

#include "linkedlist.h"
#include "eigrp_structs.h"

#ifndef PACKET_H_
#define PACKET_H_

typedef struct incoming_packet_{
	char *data;
	int length;
} packet;
#endif

packet *create_packet(char *buffer, int lenght);
void handle_packet_ipv4(packet *p, interface *iff);
void handle_packet_ipv6(packet *p);
void send_ip4_packet_multicast(packetv4_param *param, struct eigrp_proccess *proc);
void send_ip4_packet(packetv4_param *param, int socket);

//TEST FUNCTIONS
void test(neighbour *n);
