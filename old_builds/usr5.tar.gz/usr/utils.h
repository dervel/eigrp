#include <stdbool.h>
#include <linux/kernel.h>
#include <asm/byteorder.h>
#include <sys/types.h>

#define MIN(x,y) ((x<y) ? x : y)

#ifndef UTILS_H_
#define UTILS_H_

typedef struct simple_buffer{
	char buffer[1024];
	char s[512]; //support buffer, you can fill it with whatever you want
	int len;
}sbuffer;

#endif

bool compare(char *s1, char *s2);
bool equals(char *s1, char *s2);
long long current_timestamp();
int sleep_millis(long long milliseconds);
char *time_format(long long timestamp);
__u16 checksum(char *buffer,int len);
int subnet_to_prefix(unsigned int subnet_mask);
int wildcard_to_prefix(char *ch);
unsigned int ip4_toint(char *ip);
char *ip4_tochar(unsigned int ip);
void bwrite(sbuffer *buffer, char *append, int size);
bool flags_are_set(int flag_field, int flag);
