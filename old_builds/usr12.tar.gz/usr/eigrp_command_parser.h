#include "eigrp_structs.h"

#ifndef EIGRPPARSER_H_
#define EIGRPPARSER_H_
typedef enum command_node_{
	NONE,
	ROUTER,
	KEYCHAIN,
	KEY,
	INTERFACE,
	IPV6
}command_node;
#endif

proccess *get_proccess_info(int id, int family);
iff_info *get_interface_info(int index);
extern int parse_commands(char *buff, int len);
void free_lists();
