
#include <stdbool.h>

#ifndef HASHTABLE_H_
#define HASHTABLE_H_

typedef struct _list_t_ {
	int key;
	void** value;
	struct _list_t_ *next;
} list_t;

typedef struct _hash_table_t_ {
	int size;
	int real_size;
	list_t **table;
} hash_table_t;

#endif

hash_table_t *create_hash_table(int size);
void *hashtable_getitem(hash_table_t *hashtable, int key);
unsigned int inner_hash(hash_table_t *hashtable, int key);
bool hashtable_removeitem(hash_table_t *hashtable, int key);
int hashtable_additem(hash_table_t *hashtable, void* , int key);
void hashtable_free(hash_table_t *hashtable);
unsigned int hash(char *str);
unsigned int hash_unsigned(unsigned char *str);
