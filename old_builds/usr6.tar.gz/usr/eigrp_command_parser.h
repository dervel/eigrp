#include "eigrp_structs.h"

proccess *get_proccess_info(int id);
extern int parse_commands(char *buff, int len);
void free_lists();
