#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <sys/time.h>
#include <sys/types.h>
#include <asm/byteorder.h>

#define MIN(x,y) ((x<y) ? x : y)

bool compare(char *s1, char *s2){
	
	int result = strncmp(s1,s2,MIN(strlen(s1),strlen(s2)));
	if(result == 0)
		return true;
	else
		return false;
}

long long current_timestamp(){
	struct timeval te;
	gettimeofday(&te,NULL);
	long long mill = te.tv_sec*1000LL + te.tv_usec/1000;
	return mill;
}

int sleep_millis(long long milliseconds){
	struct timeval te;
	te.tv_sec = milliseconds / 1000;
	te.tv_usec = (milliseconds % 1000) * 1000000LL;
	return nanosleep(&te, NULL);
}

__u16 checksum(char *buffer,int len){
	__u32 sum = 0;
	__u16 word16;
	int i;
	for(i=0;i<len;i+=2){
		word16 = ((buffer[i]<<8)&0xFF00)+(buffer[i+1]&0xFF);
		sum = sum +(__u32)word16;
	}

	while(sum>>16){
		sum = (sum & 0xFFFF)+(sum >> 16);
	}

	sum= ~sum;

	return ((__u16)sum);
}
