
#include <stdio.h>
#include <sys/socket.h>
#include <asm/types.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#include "netlink.h"
#include "vector.h"
#include "config.h"

int main(){

	__u32 dest=inet_addr("13.0.0.0");
	__u32 gateway=inet_addr("192.168.1.1");
	__u32 metric=1234;
	//int status = route_add(&dest,&gateway,8,&metric);

	/*vector routes = get_routes_by_protocol(RTPROT_EIGRP);
	int i;
	for(i=0;i<routes.size; i++){
		struct netlink_route *route;
		route = vector_get(&routes,i);
		
		struct in_addr destination;
		struct in_addr gate;

		destination.s_addr = route->dest;
		gate.s_addr = route->gateway;

		char *dest1;
		dest1 = inet_ntoa(destination);
		char *gate1;
		gate1 = inet_ntoa(gate);

		printf("Dest:%-15s, Gateway:%-15s, Metric:%d\n",dest1,gate1,route->metric);
	}
	vector_free(&routes);*/
	
	
	//int removed = remove_routes_by_protocol(RTPROT_EIGRP);
	//printf("Routes Removed:%d\n",removed);
	

	return 0;

}
