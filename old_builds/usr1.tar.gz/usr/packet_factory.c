#include <stdlib.h>
#include <string.h>

#include "config.h"
#include "eigrp_structs.h"
#include "packet_factory.h"

void addtlv(packetv4_param *packet, void* tlv,int len){
	if(packet->buffer_len + len > PACKET_LENGTH)
		return;
	memcpy(&packet->buffer[packet->buffer_len],tlv,len);	
	packet->buffer_len += len;
}

void auto_packet_split(neighbour *n,vector *tlvs,int opcode,int flags){
	int mtu = n->interface->mtu;
	mtu *= 0.8;

	if(mtu < LEAST_MTU)
		mtu = LEAST_MTU;

	int i=0;
	
	while(i<tlvs->size){
		packetv4_param *packet = create_empty_packet(opcode,flags, n->sin);

		for(;i<tlvs->size;i++){
			char *index = vector_get(tlvs,i);
			int type = index[1] | index[0] << 8;
			if(type == 0x0102){
				if(packet->buffer_len + sizeof(tlv_ip4_internal) > mtu) break;
				tlv_ip4_internal *param = (tlv_ip4_internal *)index;
				int byte_len = ((param->prefix -1)/8)+1;
				//tlv assumes destination is 1 byte so we subtract it and add the correct
				addtlv(packet,param,sizeof(tlv_ip4_internal)-4+byte_len);
			}
		}

		linkedlist_addtail(&n->packet_queue,packet);
	}
}

packetv4_param *create_empty_packet(int opcode,int flags, struct sockaddr_in sin){
	//The packet is gonna be empty since the header is created at the end and we have no tlvs
	int packet_len = sizeof(struct eigrphdr);
	char *buffer = malloc(PACKET_LENGTH);
	memset(buffer,0,PACKET_LENGTH);

	packetv4_param *packet = malloc(sizeof(packetv4_param));
	packet->buffer = buffer;
	packet->buffer_len = packet_len;
	packet->flags = flags;
	packet->sin = sin;
	packet->opcode = opcode;
	packet->seq_num = 0;

	return packet;
}

void create_eigrp_header(char* buffer, int packet_len, int opcode, int auto_sys_number, int seqnum, int acknum, int flags){
	struct eigrphdr *eigrphd = (struct eigrphdr*)buffer;
	eigrphd->version = VERSION;
	eigrphd->opcode = opcode;
	eigrphd->checksum = 0;
	eigrphd->flags = htonl(flags);
	eigrphd->seqnum = htonl(seqnum);
	eigrphd->acknum = htonl(acknum);
	eigrphd->router_id = 0;
	eigrphd->autonomous_sys_number = htons(auto_sys_number);

	//Now that the packet is filled we should override the checksum
	eigrphd->checksum =  htons(checksum(buffer,packet_len));
}

char *create_hello_packet(int* packet_len, struct eigrp_proccess *proc){
	*packet_len = sizeof(struct eigrphdr) + sizeof(struct tlv_parameter_type) + sizeof(struct tlv_version_type);
	char *buffer = malloc((*packet_len));
		
	struct tlv_parameter_type *param_type =  (struct tlv_parameter_type*)(buffer + sizeof(struct eigrphdr));
	param_type->type = htons(0x0001);
	param_type->length = htons(0x000C);
	param_type->k1 = proc->k1;
	param_type->k2 = proc->k2;
	param_type->k3 = proc->k3;
	param_type->k4 = proc->k4;
	param_type->k5 = proc->k5;	
	param_type->k6 = proc->k6;
	param_type->holdtime = htons(proc->holdtime);
	
	struct tlv_version_type *version_type = (struct tlv_version_type*)(buffer + sizeof(struct eigrphdr) + sizeof(struct tlv_parameter_type));
	version_type->type = htons(0x0004);
	version_type->length = htons(0x0008);
	version_type->os_version = htons(OS_VERSION);
	version_type->eigrp_version = htons(EIGRP_VERSION);

	create_eigrp_header(buffer, *packet_len, OPCODE_HELLO, proc->proccess_id, 0 , 0, 0);

	return buffer;
}
